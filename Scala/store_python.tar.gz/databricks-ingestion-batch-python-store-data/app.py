from conf.spark_utilities import SparkUtilities
from src.main.store_data.divisional_re_status.DivisionalReStatusReport import DivisionalReStatusReport
from src.main.store_data import StoreArchive
import argparse

parser = argparse.ArgumentParser(description='Divisional Re status report ingestion')
parser.add_argument("--process", type=str, help='ingestion or archive')
args = parser.parse_args()
print(args.process)

spark_obj = SparkUtilities()
spark = spark_obj.sparksession()
spark.conf.set("spark.sql.execution.arrow.enabled", "true")

if __name__ == '__main__':
    if args.process == "divisional_re_ingestion":
        status = DivisionalReStatusReport(spark)
    elif args.process == "divisional_re_archive":
        divisional_re_archive = StoreArchive(dbutils, "NA_RE_Master", "/mnt/mainframe/incoming/",
                                         "/mnt/mainframe/archive/db70/")
