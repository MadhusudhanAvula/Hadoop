from pyspark.sql import SparkSession


class SparkUtilities(object):
    def sparksession(self):
        spark = SparkSession.builder.getOrCreate()
        return spark

    def sparkcontext(self, spark):
        sc = spark.sparkContext
        return sc

    def set_adls_auth(self, adlsscope, spark, dbutils):
        spark.conf.set("dfs.adls.oauth2.access.token.provider.type", "ClientCredential")
        spark.conf.set("dfs.adls.oauth2.client.id", dbutils.secrets.get(scope=adlsscope, key="client_id"))
        spark.conf.set("dfs.adls.oauth2.credential", dbutils.secrets.get(scope=adlsscope, key="credential"))
        spark.conf.set("dfs.adls.oauth2.refresh.url",
                       "https://login.microsoftonline.com/3698556c-48eb-4511-8a0e-5fb6b7ebb01f/oauth2/token".format(
                           dbutils.secrets.get(scope=adlsscope, key="directory_id")))

    def get_adls_url(self, adlsscope, dbutils):
        adls_url = dbutils.secrets.get(scope=adlsscope, key="adls_url")
        return adls_url
