from conf.spark_utilities import SparkUtilities


# from azure.storage.blob import BlockBlobService

class Conf(object):
    """
    Class will have all config which are going to use across other modules.
    Config will populated from air-flow variables which will pass through run.py files
    """

    def __init__(self, dbutils, **kwargs):
        self.spark_obj = SparkUtilities()
        self.spark = self.spark_obj.sparksession()
        self.sc = self.spark_obj.sparkcontext(self.spark)
        self.set_adls = self.spark_obj.set_adls_auth("data-lake-scope", self.spark, dbutils)
        self.adls_url = self.spark_obj.get_adls_url("data-lake-scope", dbutils)
