from pyspark.dbutils import DBUtils

from conf.spark_utilities import SparkUtilities


class DbutilsUtilities(object):
    """docstring for Dbutils_utilities"""

    def __init__(self, token):
        self.spark_obj = SparkUtilities()
        self.spark = self.spark_obj.sparksession()
        self.sc = self.spark_obj.sparkcontext(self.spark)
        self.dbutils = DBUtils(self.sc)
        self.dbutils.secrets.setToken(token)
