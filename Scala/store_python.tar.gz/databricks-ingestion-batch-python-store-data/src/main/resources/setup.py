from setuptools import setup, find_packages

requirements = [l.strip() for l in open('requirements.txt').readlines()]

setup(
    name='storedata_divisional_re_status_report',
    url='${source_url}',
    version='1.0.0',
    author="Madhusudhan Avula",
    author_email="madhusudhan.avula@footlocker.com",
    description="Ingesting xsls file from sharepoint location to azure blob",
    long_description=open('README.md').read().strip(),
    packages=find_packages(),
    install_requires=requirements,
    include_package_data=True,
    license='footlocker.com',
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
