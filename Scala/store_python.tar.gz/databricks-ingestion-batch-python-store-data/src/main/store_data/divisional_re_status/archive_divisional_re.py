class StoreArchive():
    def __init__(self, dbutils, file_prefix ,file_path, archive_path):
        self.dbutils = dbutils
        filelist = self.dbutils.fs.ls(file_path)
        for files in filelist:
            if files.name.startswith(file_prefix):
                dbutils.fs.mv(files.path, archive_path)
                print("{} file archived".format(files.path))
