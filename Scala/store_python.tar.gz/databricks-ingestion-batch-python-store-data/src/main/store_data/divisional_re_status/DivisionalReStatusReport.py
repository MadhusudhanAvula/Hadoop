import pandas as pd
from pyspark.sql.functions import current_date
from pyspark.sql.types import StructType, StringType, StructField


class DivisionalReStatusReport(object):
    def __init__(self, spark):
        re_schema = StructType(
            [StructField("store_number", StringType(), True),
             StructField("gross_sq_ft", StringType(), True),
             StructField("selling_sq_ft", StringType(), True),
             StructField("store_type", StringType(), True),
             StructField("design_type", StringType(), True),
             StructField("mpt_type", StringType(), True),
             StructField("mpt_style", StringType(), True),
             StructField("former_lfl", StringType(), True)]
        )
        # pd.set_option('display.max_columns', 500)
        column_names = ["store_number", "gross_sq_ft", "selling_sq_ft", "store_type", "design_type", "mpt_type",
                        "mpt_style",
                        "former_lfl"]
        pdf = pd.read_excel('/dbfs/mnt/mainframe/incoming/NA_RE_Master.xlsx', header=None, skiprows=11,
                            index_col=None).filter([4, 32, 33, 34, 35, 36, 37, 40])
        print(pdf.columns)
        pdf.columns = column_names
        print("Columns to be ingested into ADLS --> " + pdf.columns)
        df = spark.createDataFrame(pdf, re_schema).withColumn("load_date", current_date())
        df.repartition(1).write.format("delta").mode("overwrite").partitionBy("load_date").save(
            "dbfs:/mnt/refined/store/divisional_re/")
