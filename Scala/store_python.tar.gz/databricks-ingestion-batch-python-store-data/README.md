Store Data Divisional RE Status report file should be ingested into ADLS by configuring the MS Flow process to extract data from a Divisional RE Status Report that is an excel report that gets developed and shared out on a monthly basis.

Below's the content that we need to extract from the report:

Store Number
Gross Sq Ft
Selling Sq Ft
Store Type (i.e. core, power, high profile, or marketplace)
Design Type
MPT Type (i.e. Marketplace Transformation - e.g. House of Hoops, Puma Labs, or combos (refer MPT type tab))
MPT Style (i.e. Marketplace Transformation style - side by side or shop-in-shop.)
Former LFL (Binary Flag - Former Lady FL (1) or not (0).)

Used Pandas to read a semi structured Xsls file and selected only required columns from a xsls sheet later converted Pands DF to Pyspark DF and ingetsed selected columns into ADLS.

Columns selected from the Divisional RE status report xsls file are "store_number", "gross_sq_ft", "selling_sq_ft", "store_type", "design_type", "mpt_type","mpt_style","former_lfl"