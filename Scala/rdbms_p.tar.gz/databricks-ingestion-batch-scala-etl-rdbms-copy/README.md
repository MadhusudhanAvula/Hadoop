# Generic RDMS Ingestion Scala Package

## Overview

This package contain ingestion classes which help to ingest data
from RDMS to Data-Lake using Spark JDBC in full refresh or incremental manner.

It supports ingestion from SQLServer,MySQL,Oracle,and Netezza.

### Usage

Coming Soon