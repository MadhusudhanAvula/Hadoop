package com.footlocker.rdbmspull

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.footlocker.rdbmspull.sinks.AdlsHelper
import com.footlocker.rdbmspull.sources.{MySqlSource, NetezzaSource, OracleSource, RdbmsSource, SqlServerSource}
import com.footlocker.rdbmspull.utils.{Arguments, Logging, SparkSessionProvider, WinUtilsLoader}
import com.footlocker.rdbmspull.utils.{Arguments, Logging, SparkSessionProvider, WinUtilsLoader}
import com.footlocker.rdbmspull.sources._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._


object RdbmsExtractor extends SparkSessionProvider with Logging with Arguments {

  /** Usage --adlsgen "adlsgen1|adlsgen2"
    * --adlszone: mandatory choose one of these pii|npii
    *--adlsScope: mandatory data-lake-scope|pii-data-lake-scope
    *--adls: mandatory "fldapdev***|fldapprod***"
    *--piiCols: Conditional required only if adlszone is npii. Ex: "col1,col3,col6,col8"
    *--adlsLayer: mandatory "landing|application"
    *--adlsDatabase: mandatory "relate|customer360"
    *--adlsTableName: mandatory "tableName"
    *--saveMode: choose "overwrite|append". default overwrite
    *--numPartitions: default 200
    *--adlsSaveFormat: "delta|parquet" default delta
    *--outputPartitionSpec: Optional Ex: "col1,col2,col3"
    *--rdbmsType: mandatory. choose from "netezza|oracle|sqlserver|mysql"
    *--rdbmsServer: mandatory. Server name along with port Ex: "MLWBIN30:5480"
    *--rdbmsDatabase: mandatory. Ex: "QS_DW_DEV"
    *--rdbmsSchema: Optional Ex: "dbo"
    *--rdbmsUser: mandatory Ex: "user"
    *--rdbmsPassword: mandatory Ex: "password"
    *--rdbmsFetchMode: mandatory choose between "query|table"
    *--rdbmsQuery: Conditional - mandatory if rdbmsFetchMode is query. Ex: "SELECT * FROM TABLE1 join Table2 on table1.a = table2.b"
    *--rdbmsTable: Conditional - mandatory if rdbmsFetchMode is table. Ex: "DW_SLS_TXN_HEADER"
    *--splitBy: Optional - needed if you need to pull in parallel using spark. Ex: "src_id"
    *--boundaryQuery: Optional - but recommended to specify if rdbmsFetchMode is query. Ex: "Select max(dept_id), min(dept_id) from OrderHeader"
    *--jdbcOtherParams: - Optional. Any additional jdbc params that you wish to specify
    *--whereClause: Optional - works only if rdbmsFetchMode is table. Enables you to specify any filter on table before querying
    *--add_load_time: Optional - true if want to add Current load date and timestamp in UTC.
    *--extractmode: mandatory - 'full' if you want to do a full load else 'incremental' to get the incremental/updated data
    *--incremental_columns: Optional - specify the incrementing columns in coma seperated format.
    *--incremental_data_type: Optional - specify the data type of the incremental_columns
    *--adlsCloudDatabase: Optional -  specify the database to get incremental_columns from table
    *--adlsCloudTablename: Optional -  specify the table to get incremental_columns from table
    *--partitionWhereClause: Optional -  specify filter partitions so getting incremental operation run fast. ex updated_date > date_sub (current_date(),2)
    *--repairTable: Optional - specify true if repair table and refresh table command needed after ingestion.
    *--switchMysqlDriver: Optioanl - specify complete fully specified driver to override the default mysql driver class
    * @param args : Inputs Arguments
    */

  def getSource(args: Map[String, String]) = {

    // Get a dbService object that is specific to each database
    val source: RdbmsSource = args("rdbmsType") match {
      case "sqlServer" => SqlServerSource(args("rdbmsServer"), args("rdbmsDatabase"),
        args.getOrElse("jdbcOtherParams",""), args("rdbmsUsername"), args("rdbmsPassword"), args("adlauth").toLowerCase == "true")
      case "mysql" => MySqlSource(args("rdbmsServer"), args("rdbmsDatabase"),
        args.getOrElse("jdbcOtherParams",""), args("rdbmsUsername"), args("rdbmsPassword"), args.getOrElse("switchMysqlDriver",""))
      case "netezza" => NetezzaSource(args("rdbmsServer"), args("rdbmsDatabase"),
        args.getOrElse("jdbcOtherParams",""), args("rdbmsUsername"), args("rdbmsPassword"))
      case "oracle" => OracleSource(args("rdbmsServer"), args("rdbmsDatabase"),
        args.getOrElse("jdbcOtherParams",""), args("rdbmsUsername"), args("rdbmsPassword"))
    }
    source
  }


  def processPii(srcDF: DataFrame, args: Map[String, String])= {

    val stdPiiCols = List("email", "name", "address")
    val stdHashCols = List("phone")
    // Pii Specific
    val (dropColList, hashColList) = if (args("adlsZone").toLowerCase == "npii") {
      val piiCols = args.getOrElse("piiCols", "").split(",").toList
      val hashCols = args.getOrElse("hashCols", "").split(",").toList
      val piiColList = {stdPiiCols ++ piiCols}.filterNot(_.isEmpty)
      val hashColList = {stdHashCols ++ hashCols}.filterNot(_.isEmpty)
      // Get only those cols from piiColList that are not in hashColList
      val dropColList = piiColList.filter(colName => !hashColList.contains(colName))
      (dropColList, hashColList)
    } else (List[String](), List[String]())

    val tgtDF = if (args("adlsZone").toLowerCase == "npii") {
      // select all Cols that are not present in dropColList
      val npiiDF = srcDF.select(srcDF.columns.filter(colName => !dropColList.contains(colName)).map(colName => col(colName)): _*)
      // hash cols present in hashcollist and drop original column names
      val hashedDF = npiiDF.columns.filter(colName => hashColList.contains(colName)).foldLeft(npiiDF)((df, colName) => df.withColumn(colName, md5(trim(lower(col(colName))))))
      hashedDF
    } else srcDF
    tgtDF

  }

  /**
    * Main entry point for the application, it starts the SparkSession
    *
    * @param args program arguments
    */
  def main(args: Array[String]): Unit = {

    val arguments: Map[String, String] = argsToMap(args)
    val appName = arguments.getOrElse("appName", "rdbms_data_extractor")

    implicit val spark: SparkSession = if (System.getProperty("os.name").contains("Windows")) {
      WinUtilsLoader.loadWinUtils()
      createSparkSession("local[*]", appName)
    } else createSparkSession(appName = appName)

    val source = getSource(arguments)

    val adls = arguments("adlsgen") match {
      case "adlsgen1" => s"adl://${arguments("adls")}.azuredatalakestore.net/"
      case "adlsgen2" => s"abfss://${arguments("adls")}.dfs.core.windows.net/"
    }

    val adlsSaveFormat = arguments.getOrElse("adlsSaveFormat", "delta")


    val adlsPath = (if (adls.charAt(adls.length - 1) == '/') adls else adls + "/") +
      (if (arguments("adlsLayer") == "") "" else arguments("adlsLayer") + "/") +
      (if (arguments("adlsDatabase") == "") "" else arguments("adlsDatabase") + "/") +
      arguments("adlsTableName")

    println(adlsPath)

    val saveMode = arguments.getOrElse("saveMode", "overwrite")

    val numPartitions = arguments.getOrElse("numPartitions", "10")

    val outputPartitionSpec = arguments.getOrElse("outputPartitionSpec", "")

    val repartition = arguments.getOrElse("repartition", "true")


    if (saveMode == "overwrite" && outputPartitionSpec.isEmpty()) {
      try {
        dbutils.fs.rm(s"${adlsPath}", true)
        println("Cleaned Target Directory")
      } catch {
        case e: Exception => {
          println("Target doesn't exist")
        }
      }

    }
    val sink = AdlsHelper()

    val adlsSecrets = sink.getADLSSecrets(arguments("adlsScope"))
    if (arguments("adlsgen") == "adlsgen1") {
      sink.setAdlsGen1Conectivity(adlsSecrets._1, adlsSecrets._2, adlsSecrets._3)
    } else {
      sink.setAdlsGen2Conectivity(adlsSecrets._1, adlsSecrets._2, adlsSecrets._3)
    }

    require(arguments.getOrElse("rdbmsTable", "").isEmpty || arguments.getOrElse("rdbmsQuery", "").isEmpty, "Cannot mix table and query options. Use either table with where clause or query")

    val srcDF = {
      if (arguments("add_load_time").toLowerCase == "true")
        source.read(arguments).withColumn("load_date", current_date()).withColumn("load_timestamp", current_timestamp())
      else
        source.read(arguments)
    }

    val tgtDF = processPii(srcDF, arguments)

    spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

    if (repartition == "true") {
      sink.writerepartition(adlsPath, tgtDF, numPartitions, adlsSaveFormat, saveMode, if (outputPartitionSpec.length > 0) Some(outputPartitionSpec) else None)

    }
    else {

      sink.write(adlsPath, tgtDF, numPartitions, adlsSaveFormat, saveMode, if (outputPartitionSpec.length > 0) Some(outputPartitionSpec) else None)

    }

    // if repairTable is true then it will refresh and repair table
    // adlsCloudDatabase and adlsCloudTablename arguments are compulsory to use this feature
    if (arguments.getOrElse("repairTable","") == "true")
    {
      require(!arguments.getOrElse("adlsCloudDatabase","").isEmpty &&
              !arguments.getOrElse("adlsCloudTablename","").isEmpty,
              "You are missing adlsCloudDatabase or adlsCloudTablename while passing arguments")
      try
      {
        println("=============== Repair Table Command after Ingestion===============")

        if (arguments("adlsSaveFormat") == "delta")
        {
          println("=============== FSCK Table Command Running ===============")

          spark.sql(s"FSCK REPAIR TABLE ${arguments("adlsCloudDatabase")}.${arguments("adlsCloudTablename")}")
        }
        else {
          println("=============== MSCK Table Command Running ===============")

          spark.sql(s"MSCK REPAIR TABLE ${arguments("adlsCloudDatabase")}.${arguments("adlsCloudTablename")}")
        }
      }
      catch {
        // if table is not partitioned then it will skip it
        case e:Exception=> println("table is not partitioned so skipping repair command")
      }

      println("=============== Refreshing Table after Ingestion ===============")

      spark.sql(s"REFRESH TABLE ${arguments("adlsCloudDatabase")}.${arguments("adlsCloudTablename")}")
    }

  }

}