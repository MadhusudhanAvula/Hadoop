package com.footlocker.rdbmspull.sources

import org.apache.spark.sql.{DataFrame, SparkSession}

case class SqlServerSource(rdbmsServer: String,
                           rdbmsDatabase: String,
                           jdbcOtherParams: String,
                           rdbmsUsername: String,
                           rdbmsPassword: String,
                           adAuth: Boolean,
                           rdbmsType: String = "sqlServer"
                          ) extends RdbmsHelper with RdbmsSource {


  val url: String = if (adAuth) {
     s"""jdbc:jtds:sqlserver://$rdbmsServer/$rdbmsDatabase;$jdbcOtherParams""" //ex. jdbcOtherParams : ";domain=CORP"
  } else {
    s"""jdbc:sqlserver://$rdbmsServer;database=$rdbmsDatabase$jdbcOtherParams"""
  }

  val driverClass: String = if (adAuth) {
    "net.sourceforge.jtds.jdbc.Driver"
  } else {
    "com.microsoft.sqlserver.jdbc.SQLServerDriver"
  }


  def verifyJdbcParams(rdbmsServer: String,
                       rdbmsDatabase: String,
                       jdbcOtherParams: String,
                       rdbmsUsername: String,
                       rdbmsPassword: String
                      ): Unit = {
    assert(rdbmsType.length > 0, "Incorrect Argument: rdbmsType")
    assert(rdbmsServer.length > 0, "Incorrect Argument: rdbmsServer")
    assert(rdbmsDatabase.length > 0, "Incorrect Argument: rdbmsDatabase")
    assert(rdbmsUsername.length > 0, "Incorrect Argument: rdbmsUsername")
    assert(rdbmsPassword.length > 0, "Incorrect Argument: rdbmsPassword")
  }

  def read(args: Map[String, String])(implicit spark: SparkSession): DataFrame = {

    // Get Jdbc Url from dbService object
    val jdbcDriver = driverClass
    val jdbcUrl = url

    // Get sql query and bounds
    val sqlQuery = getSqlQuery(args)


    val df = if (!args("splitBy").isEmpty) {
      val boundaryQuery = getBoundaryQuery(args)
      val bounds = getBounds(boundaryQuery, jdbcUrl, jdbcDriver, args)

      spark.read.format("jdbc").options(
        Map("url" -> jdbcUrl,
          "user" -> args("rdbmsUsername"),
          "password" -> args("rdbmsPassword"),
          "driver" -> jdbcDriver,
          "dbtable" -> s"($sqlQuery) tmp",
          "partitionColumn" -> args("splitBy"),
          "numPartitions" -> args.getOrElse("numPartitions", "10"),
          "fetchsize" -> "10000",
          "lowerBound" -> bounds._1,
          "upperBound" -> bounds._2
        )).load()
    } else {
      spark.read.format("jdbc").options(
        Map("url" -> jdbcUrl,
          "user" -> args("rdbmsUsername"),
          "password" -> args("rdbmsPassword"),
          "driver" -> jdbcDriver,
          "dbtable" -> s"($sqlQuery) tmp",
          "fetchsize" -> "10000"
        )).load()
    }
    df
  }

}
