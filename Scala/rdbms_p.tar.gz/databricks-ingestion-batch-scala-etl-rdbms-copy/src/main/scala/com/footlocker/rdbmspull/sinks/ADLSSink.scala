package com.footlocker.rdbmspull.sinks

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * This Trait provides interface ADLS
  */
trait ADLSSink {

  // validate mandatory args for adls
  def verifyAdlsParams(args: Map[String, String]): Unit

  /**
    *
    * @param adlsPath         Path in which the files have to be written
    * @param df               dataframe which is to be written
    * @param numPartitions    number of partitions to be written
    * @param saveMode         save mode that should be used for write
    * @param partitionColumns columns used to partition
    */
  def write(adlsPath: String, df: DataFrame, numPartitions: String,
                     saveFormat: String, saveMode: String, partitionColumns: Option[String]): Unit



}
