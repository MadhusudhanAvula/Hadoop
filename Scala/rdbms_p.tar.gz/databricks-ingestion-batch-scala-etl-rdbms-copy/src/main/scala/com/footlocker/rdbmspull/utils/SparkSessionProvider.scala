package com.footlocker.rdbmspull.utils

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

/**
  * Trait that provides the management of a SparkSession
  */
trait SparkSessionProvider extends Logging {

  @transient private var _sparkSession: SparkSession = _

  /**
    *
    * @param master   Master for the spark job
    * @param appName  name of job
    * @return         Spark session
    */
  def createSparkSession(master: String = "local[*]",
                         appName: String
                        ): SparkSession = {

    _sparkSession = {
      val conf = new SparkConf()

      conf
        .setMaster(master)
        .setAppName(appName)

      logInfo("Starting Spark Session")

      SparkSession
        .builder()
        .config("spark.sql.warehouse.dir", "file:///tmp/spark-warehouse")
        .config(conf)
        .getOrCreate()
    }

    sparkSession
  }

  def sparkSession: SparkSession = _sparkSession
}
