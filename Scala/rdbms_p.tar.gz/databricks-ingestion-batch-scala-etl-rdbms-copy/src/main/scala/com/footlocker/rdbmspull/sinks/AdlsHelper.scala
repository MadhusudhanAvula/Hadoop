package com.footlocker.rdbmspull.sinks

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.col

case class AdlsHelper() extends ADLSSink{

  // validate mandatory args for adls non pii
  def verifyAdlsParams(args: Map[String, String]): Unit = {
    assert(args.contains("adlsScope"), "Missing Argument: adlsScope")
    assert(args.contains("adls"), "Missing Argument: adls")
    assert(args.contains("adlsLayer"), "Missing Argument: adlsLayer")
    assert(args.contains("adlsDatbase"), "Missing Argument: adlsDatbase")
    assert(args.contains("adlsTableName"), "Missing Argument: adlsTableName")
  }

  /** Function to retrive ADLS Connection details
    *
    * @param credentialScope Scope of obtaining the Secrets
    * @return tuple of client_id, credential, directory_id, adls_url
    */
  def getADLSSecrets(credentialScope: String): (String, String, String, String) =
    ( dbutils.secrets.get(scope = credentialScope, key = "client_id"),
      dbutils.secrets.get(scope = credentialScope, key = "credential"),
      dbutils.secrets.get(scope = credentialScope, key = "directory_id"),
      dbutils.secrets.get(scope = credentialScope, key = "adls_url")
    )


  /**
    * This functions sets the necessary ADLS details to SparkSession Config
    *
    * @param clientId    Client Id
    * @param credential  Credential
    * @param directoryId Directory Id
    */
  def setAdlsGen1Conectivity(clientId: String, credential: String, directoryId: String)
                        (implicit spark: SparkSession): Unit = {
    spark.conf.set("dfs.adls.oauth2.access.token.provider.type", "ClientCredential")
    spark.conf.set("dfs.adls.oauth2.client.id", clientId)
    spark.conf.set("dfs.adls.oauth2.credential", credential)
    spark.conf.set("dfs.adls.oauth2.refresh.url", s"https://login.microsoftonline.com/$directoryId/oauth2/token")
  }

  def setAdlsGen2Conectivity(clientId: String, credential: String, directoryId: String)
                        (implicit spark: SparkSession): Unit = {
    spark.conf.set("fs.azure.account.oauth.provider.type", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
    spark.conf.set("fs.azure.account.oauth2.client.id", clientId)
    spark.conf.set("fs.azure.account.oauth2.client.secret", credential)
    spark.conf.set("fs.azure.account.oauth2.client.endpoint", s"https://login.microsoftonline.com/$directoryId/oauth2/token")
    spark.conf.set("fs.azure.account.auth.type", "OAuth")
  }

  def writerepartition(adlsPath: String, df: DataFrame, numPartitions: String,
                     saveFormat: String, saveMode: String,partitionColumns: Option[String]): Unit = {


    partitionColumns match {
      case Some(cols) =>
        df.repartition(numPartitions.toInt, cols.split(",").toSeq.map(col): _*)
          .write
          .format(saveFormat)
          .mode(saveMode)
          .partitionBy(cols.split(",").toSeq: _*)
          .save(adlsPath)

      case None =>
        df.repartition(numPartitions.toInt)
          .write
          .format(saveFormat)
          .mode(saveMode)
          .save(adlsPath)
    }
  }

  def write(adlsPath: String, df: DataFrame, numPartitions: String,
                       saveFormat: String, saveMode: String,partitionColumns: Option[String]): Unit ={


        partitionColumns match {
          case Some(cols) =>
            df.write
              .format(saveFormat)
              .mode(saveMode)
              .partitionBy(cols.split(",").toSeq : _*)
              .save(adlsPath)

          case None =>
            df.write
              .format(saveFormat)
              .mode(saveMode)
              .save(adlsPath)
        }
  }

}
