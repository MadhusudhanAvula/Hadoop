package com.footlocker.rdbmspull.sources

import org.apache.spark.sql.{DataFrame, SparkSession}

case class NetezzaSource(rdbmsServer: String,
                         rdbmsDatabase: String,
                         jdbcOtherParams: String,
                         rdbmsUsername: String,
                         rdbmsPassword: String,
                         rdbmsType: String = "netezza"
                       ) extends RdbmsHelper with RdbmsSource {

  val driverClass: String = "org.netezza.Driver"

  val url: String = s"""jdbc:netezza://$rdbmsServer;database=$rdbmsDatabase"""

  def verifyJdbcParams(rdbmsServer: String,
                       rdbmsDatabase: String,
                       jdbcOtherParams: String,
                       rdbmsUsername: String,
                       rdbmsPassword: String
                      ): Unit = {
    assert(rdbmsType.length > 0, "Incorrect Argument: rdbmsType")
    assert(rdbmsServer.length > 0, "Incorrect Argument: rdbmsServer")
    assert(rdbmsDatabase.length > 0, "Incorrect Argument: rdbmsDatabase")
    assert(rdbmsUsername.length > 0, "Incorrect Argument: rdbmsUsername")
    assert(rdbmsPassword.length > 0, "Incorrect Argument: rdbmsPassword")
  }

  def read(args: Map[String, String])(implicit spark: SparkSession): DataFrame = {

    // Get Jdbc Url from dbService object
    val jdbcDriver = driverClass
    val jdbcUrl = url

    // Get sql query and bounds
    val sqlQuery = getSqlQuery(args)

    val df = if (!args("splitBy").isEmpty) {
      val boundaryQuery = getBoundaryQuery(args)
      val bounds = getBounds(boundaryQuery, jdbcUrl, jdbcDriver, args)

      spark.read.format("jdbc").options(
        Map("url" -> jdbcUrl,
          "user" -> args("rdbmsUsername"),
          "password" -> args("rdbmsPassword"),
          "driver" -> jdbcDriver,
          "dbtable" -> s"($sqlQuery) tmp",
          "partitionColumn" -> args("splitBy"),
          "numPartitions" -> args.getOrElse("numPartitions", "10"),
          "lowerBound" -> bounds._1,
          "upperBound" -> bounds._2
        )).load()
    } else {
      spark.read.format("jdbc").options(
        Map("url" -> jdbcUrl,
          "user" -> args("rdbmsUsername"),
          "password" -> args("rdbmsPassword"),
          "driver" -> jdbcDriver,
          "dbtable" -> s"($sqlQuery) tmp"
        )).load()
    }
    df
  }

}
