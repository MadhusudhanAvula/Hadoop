package com.footlocker.rdbmspull.sources

import com.footlocker.rdbmspull.utils.SparkSessionProvider
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.functions._


class RdbmsHelper{

  def getBounds(boundarySql: String, jdbcUrl: String, jdbcDriver: String, args: Map[String, String])
               (implicit spark: SparkSession): Tuple2[String, String] = {
    val bounds = spark.read.format("jdbc").options(
      Map("url" -> jdbcUrl,
        "user" -> args("rdbmsUsername"),
        "password" -> args("rdbmsPassword"),
        "driver" -> jdbcDriver,
        "dbtable" -> s"($boundarySql) tmp"
      )).load().collect()(0)
    (bounds.get(0).toString, bounds.get(1).toString)
  }

  def getBoundaryQuery(args: Map[String, String]):String = {
    val boundarySql = if (args.getOrElse("boundaryQuery", "").isEmpty) {
      args.getOrElse("rdbmsFetchMode", "").toLowerCase match {
        case "table" => {
          val table = if (!args("rdbmsSchema").isEmpty) {
            s"""${args("rdbmsSchema")}.${args("rdbmsTable")}"""
          } else args("rdbmsTable")

          s"""SELECT MIN(${args("splitBy")}) as min,
                MAX(${args("splitBy")}) as max
           FROM $table
          WHERE ${args.getOrElse("whereClause", "1 = 1")}"""
        }
        case "query" => {
          s"""SELECT MIN(${args("splitBy")}) as min,
                MAX(${args("splitBy")}) as max
           FROM (${args("rdbmsQuery")}) tmp
          WHERE ${args.getOrElse("whereClause", "1 = 1")}"""
        }
      }
    } else {
      args.get("boundaryQuery").toString
    }
    boundarySql
  }

  def getSqlQuery(args: Map[String, String])(implicit spark: SparkSession): String = {
    val finalsqlQuery =
      args.getOrElse("extractMode","") match{
        case "full" =>{
          args.getOrElse("rdbmsFetchMode", "").toLowerCase match {
            case "table" => {
              val table = if (!args("rdbmsSchema").isEmpty) {
                s"""${args("rdbmsSchema")}.${args("rdbmsTable")}"""
              } else args("rdbmsTable")

              val sql=new StringBuilder
              sql++=s"""SELECT * FROM $table WHERE ${args.getOrElse("whereClause", "1 = 1")}"""
              sql
            }
            case "query" => args("rdbmsQuery").toString
          }
        }
        case "incremental" => {
          val columns = args("incremental_columns") split (",").map { x => x }
          var values = new ListBuffer[String]()

          // to get incremental value if table is partition then use it
          var whereClause = ""
          if (! args.getOrElse("partitionWhereClause","").isEmpty) {
            whereClause ++= s""" and ${args("partitionWhereClause")} """
          }

          // repair table before query it if table is not partitioned then it skip it
          try
          {
            println("=============== Repair Table Command ===============")

            if (args("adlsSaveFormat") == "delta")
            {
              spark.sql(s"FSCK REPAIR TABLE ${args("adlsCloudDatabase")}.${args("adlsCloudTablename")}")
            }
            else {
              spark.sql(s"MSCK REPAIR TABLE ${args("adlsCloudDatabase")}.${args("adlsCloudTablename")}")
            }

          }
          catch {
            // if table is not partitioned then it will skip it
            case e:Exception=> println("table is not partitioned so skipping repair command")
          }

          for (column <- columns) {
            spark.sql(s"REFRESH TABLE ${args("adlsCloudDatabase")}.${args("adlsCloudTablename")}") //refresh table
            val value = spark.sql(s""" SELECT max($column) FROM ${args("adlsCloudDatabase")}.${args("adlsCloudTablename")} WHERE $column IS NOT null $whereClause """)
            var test_value = value.select(col(s"max($column)")).first.get(0)
            var chng_value = test_value.toString
            values += chng_value
          }

          var final_values = values.toList
          var query = new StringBuilder

          if(args("rdbmsFetchMode").equals("query")){
            query ++= s"""${args("rdbmsQuery")} where """
          }
          else {
            query ++= s"""select * from ${args("rdbmsTable")} where """
          }

          var c = 0
          var condition1 = ""
          var condition2 = ""
          for (a <- final_values) {
            if(args("rdbmsType").equals("oracle")){
              if(args("incremental_data_type").equals("timestamp")){
                if (c == final_values.length - 1) {
                  condition1 ++= columns(c) + s""" > to_timestamp('$a','yyyy-MM-dd HH24:MI:SS.FF3')"""
                  query ++= ' ' + condition1
                  println("appending condition1" + query)
                }
                else {
                  condition2 ++= ' ' + columns(c) + s""" > to_timestamp('$a','yyyy-MM-dd HH24:MI:SS.FF3') OR """
                  c= c + 1
                  query ++= ' ' + condition2
                  println("appending condition2" + query)
                }
              }
              else if(args("incremental_data_type").equals("number")){

                if (c == final_values.length - 1) {
                  condition1 ++= columns(c) + s""" > TO_NUMBER('$a')"""
                  query ++= ' ' + condition1
                  println("appending condition1" + query)
                }
                else {
                  condition2 ++=' ' + columns(c) + s""" > TO_NUMBER('$a') OR """
                  c = c + 1
                  query ++= ' ' + condition2
                  println("appending condition2" + query)
                }
              }
            }
            else if(args("rdbmsType").equals("sqlServer")){
              if(args("incremental_data_type").equals("int")){
                if (c == final_values.length - 1) {
                  condition1 ++= columns(c) + s""" > CAST('$a' as int)"""
                  query ++= ' ' + condition1
                  println("appending condition1" + query)
                }
                else {
                  condition2 ++= ' ' + columns(c) + s""" > CAST('$a' as int) OR """
                  c = c + 1
                  query ++= ' ' + condition2
                  println("appending condition2" + query)
                }
              }
              else if(args("incremental_data_type").equals("date")){

                if (c == final_values.length - 1) {
                  condition1 ++= columns(c) + s""" > CAST('$a' as date)"""
                  query ++= ' ' + condition1
                  println("appending condition1" + query)
                }
                else {
                  condition2 ++= ' ' + columns(c) + s""" > CAST('$a' as date) OR """
                  c = c + 1
                  query ++= ' ' + condition2
                  println("appending condition2" + query)
                }
              }
              else if(args("incremental_data_type").equals("datetime")){

                if (c == final_values.length - 1) {
                  condition1 ++= columns(c) + s""" > CAST('$a' as datetime)"""
                  query ++= ' ' + condition1
                  println("appending condition1" + query)
                }
                else {
                  condition2 ++= ' ' + columns(c) + s""" > CAST('$a' as datetime) OR """
                  c = c + 1
                  query ++= ' ' + condition2
                  println("appending condition2" + query)
                }
              }
            }
          }
          query
        }
      }
    val sqlQuery = finalsqlQuery.toString
    println(s"the query to get the data:\n${sqlQuery}")
    sqlQuery
  }

}