package com.footlocker.rdbmspull.sources

import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * This Trait provides helper functions to work with RDBMS Databases
  */
trait RdbmsSource {

  val driverClass: String

  val url: String

  def verifyJdbcParams(rdbmsServer: String,
                       rdbmsDatabase: String,
                       jdbcOtherParams: String,
                       rdbmsUsername: String,
                       rdbmsPassword: String
                      ): Unit

  def read(args: Map[String, String])(implicit spark: SparkSession): DataFrame
}
