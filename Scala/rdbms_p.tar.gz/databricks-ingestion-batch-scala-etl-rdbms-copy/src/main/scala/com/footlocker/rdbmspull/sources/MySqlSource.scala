package com.footlocker.rdbmspull.sources

import org.apache.spark.sql.{DataFrame, SparkSession}

case class MySqlSource(rdbmsServer: String,
                       rdbmsDatabase: String,
                       jdbcOtherParams: String,
                       rdbmsUsername: String,
                       rdbmsPassword: String,
                       switchMysqlDriver : String,
                       rdbmsType: String = "mysql"
                      ) extends RdbmsHelper with RdbmsSource {

  //val driverClass: String = "com.mysql.jdbc.Driver"

  val driverClass: String = if (!switchMysqlDriver.isEmpty) {
    s"""$switchMysqlDriver"""
  } else {
    "com.mysql.jdbc.Driver"
  }
  println(s"driver class --> $driverClass")

  val url: String = s"""jdbc:mysql://$rdbmsServer/$rdbmsDatabase$jdbcOtherParams"""

  def verifyJdbcParams(rdbmsServer: String,
                       rdbmsDatabase: String,
                       jdbcOtherParams: String,
                       rdbmsUsername: String,
                       rdbmsPassword: String
                      ): Unit = {
    assert(rdbmsType.length > 0, "Incorrect Argument: rdbmsType")
    assert(rdbmsServer.length > 0, "Incorrect Argument: rdbmsServer")
    assert(rdbmsDatabase.length > 0, "Incorrect Argument: rdbmsDatabase")
    assert(rdbmsUsername.length > 0, "Incorrect Argument: rdbmsUsername")
    assert(rdbmsPassword.length > 0, "Incorrect Argument: rdbmsPassword")
  }

  def read(args: Map[String, String])(implicit spark: SparkSession): DataFrame = {

    // Get Jdbc Url from dbService object
    val jdbcDriver = driverClass
    val jdbcUrl = url
    println(s"jdbcDriver --> $jdbcDriver")

    // Get sql query and bounds
    val sqlQuery = getSqlQuery(args)

    val df = if (!args("splitBy").isEmpty) {
      val boundaryQuery = getBoundaryQuery(args)
      val bounds = getBounds(boundaryQuery, jdbcUrl, jdbcDriver, args)

      spark.read.format("jdbc").options(
        Map("url" -> jdbcUrl,
          "user" -> args("rdbmsUsername"),
          "password" -> args("rdbmsPassword"),
          "driver" -> jdbcDriver,
          "dbtable" -> s"($sqlQuery) tmp",
          "partitionColumn" -> args("splitBy"),
          "numPartitions" -> args.getOrElse("numPartitions", "10"),
          "lowerBound" -> bounds._1,
          "upperBound" -> bounds._2
        )).load()
    } else {
      spark.read.format("jdbc").options(
        Map("url" -> jdbcUrl,
          "user" -> args("rdbmsUsername"),
          "password" -> args("rdbmsPassword"),
          "driver" -> jdbcDriver,
          "dbtable" -> s"($sqlQuery) tmp"
        )).load()
    }
    df
  }

}