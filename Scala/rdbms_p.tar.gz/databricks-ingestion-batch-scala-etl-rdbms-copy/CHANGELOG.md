# Changelog

All notable changes made to this project will be documented in this file.

## Fixed [1.5.1]

- Made jdbcOtherParams optional
- Removed Port from Nexus url

## Updated [1.5.0]

- Fix Camel case issue with Sql Server type DTE-1010 
- Handle partition column in where clause while getting incremental value DTE-1018
- Queryfetch parameter now will accept query in incremental logic DTE-1011
- Added doc in extract class 

## Added [1.3.0]

- Added the fetchsize and repartition option


## Updated [1.2.0]

- Add JDBC parameters to URL + add ETL load time feature


## Updated [1.1.0]

- Modified the delte based on the partition


## Initial Release [1.0.0]

- Sqoop Data from various RDBMS[Oracle,SqlServer,Netezza and Oracle]sources into DataLake 



