package com.footlocker.store

import com.footlocker.datamodel.StoreData
import com.footlocker.utils.{ADLSService, DatasetWriter}
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._


object StoreDataIngestionMain extends Logging {

  def main(args: Array[String]): Unit = {

    val runArgs = StoreDataArguments(args,
      storeInputDirectoryDefault = "in/store_data/",
      storeOutputDirectoryDefault = "out/store_data/",
      aldsScopeDefault = "data-lake-scope"
    )

    logWarning("Store Input directory: " + runArgs.storeInputDirectory)
    logWarning("Store Output directory: " + runArgs.storeOutputDirectory)
    logWarning("ADLSScopeDefault: " + runArgs.aldsScope)

    val spark = SparkSession
      .builder()
      .master(runArgs.sparkMaster)
      .appName("DB70-Processing")
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")
    if (!runArgs.isLocal) {
      //Setting and Retriving  ADLS Scope
      val piiadlsSecrets = ADLSService.getADLSSecrets(runArgs.aldsScope)
      ADLSService.setAdlsConectivity(spark, piiadlsSecrets._2, piiadlsSecrets._3, piiadlsSecrets._4)
    }

    val TC070001RawData = StoreData.load(spark, runArgs.isLocal, runArgs.storeInputDirectory)
//    TC070001RawData.show(false)

    val finalDF = TC070001RawData.withColumn("open_date", splitIntoDateFormat(col("open_date"))).withColumn("load_date",current_date())
    finalDF.show(false)

    DatasetWriter.write(
      finalDF,
      runArgs.isLocal,
      runArgs.storeOutputDirectory,
      1)


  }

   def splitIntoDateFormat =udf((date: String) =>

   date.grouped(2).toList.mkString("-")



  )
}