package com.footlocker.utils

import org.apache.spark.sql.{Dataset, SaveMode}

object DatasetWriter {

  def write[T](preparedData: Dataset[T], isLocalMode: Boolean, writePath: String, numberOfPartitions: Int, partitionColumns: String*): Unit = {

    write(preparedData, isLocalMode, writePath, numberOfPartitions, false, partitionColumns: _*)
  }

  def write[T](preparedData: Dataset[T], isLocalMode: Boolean, writePath: String, numberOfPartitions: Int, complexDataType: Boolean, partitionColumns: String*): Unit = {
    if (isLocalMode) {
      if (complexDataType) {
        preparedData
          .na.fill("")
          .coalesce(1)
          .write
          .partitionBy(partitionColumns: _*)
          .mode(SaveMode.Overwrite)
          .format("json")
          .save(writePath)
      }else{
        preparedData
          .coalesce(1)
          .write
          .partitionBy(partitionColumns: _*)
          .mode(SaveMode.Overwrite)
          .format("csv")
          .save(writePath)

      }
    } else {

      preparedData
        .repartition(numberOfPartitions)
        .write
        .partitionBy(partitionColumns: _*)
        .mode(SaveMode.Append)
        .format("delta")
        .save(writePath)
    }
  }

}