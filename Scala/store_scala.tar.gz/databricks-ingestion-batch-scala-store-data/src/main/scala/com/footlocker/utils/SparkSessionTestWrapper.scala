package com.footlocker.utils

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.internal.SQLConf.SHUFFLE_PARTITIONS

trait SparkSessionTestWrapper {

  lazy val spark : SparkSession = {

    val spark = SparkSession.builder()
      .config("spark.master", "local[*]")
      .appName("Store Data Feed Test")
      .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    spark.sessionState.conf.setConf(SHUFFLE_PARTITIONS, 1) //we do not want any shuffle in local mode
    spark.sparkContext.setCheckpointDir("/tmp/spark_checkpoint")
    spark
  }
}