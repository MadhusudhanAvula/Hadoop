package com.footlocker.store

case class StoreDataArguments(
  isLocal: Boolean,
  sparkMaster: String,
  storeInputDirectory: String,
  storeOutputDirectory: String,
  aldsScope: String
)

object StoreDataArguments {

  def apply(args: Array[String],
            storeInputDirectoryDefault: String,
            storeOutputDirectoryDefault: String,
            aldsScopeDefault: String): StoreDataArguments = {

    val isLocal = if (args.length == 0) true else false
    val sparkMaster = if (isLocal) "local[*]" else "yarn"
    val storeInputDirectory = if (isLocal) storeInputDirectoryDefault else args(0)
    val storeOutputDirectory = if (isLocal) storeOutputDirectoryDefault else args(1)
    val aldsScope = if (isLocal) aldsScopeDefault else args(2)

    StoreDataArguments(
      isLocal,
      sparkMaster,
      storeInputDirectory,
      storeOutputDirectory,
      aldsScope
    )
  }
}
