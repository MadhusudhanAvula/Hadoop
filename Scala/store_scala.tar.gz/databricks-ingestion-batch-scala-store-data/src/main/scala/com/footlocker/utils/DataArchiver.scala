package com.footlocker.utils

import java.text.SimpleDateFormat
import java.util.{Calendar, TimeZone}

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession

object DataArchiver extends Logging {

  def main(args: Array[String]): Unit = {
    val inputDir = args(0)
    val archivePath = args(1)
    val file_pattern = args(2)

    val spark = SparkSession
      .builder()
      .master("yarn")
      .appName("Data Archiver")
      .getOrCreate()

    val piiadlsSecrets = ADLSService.getADLSSecrets("data-lake-scope")
    ADLSService.setAdlsConectivity(spark, piiadlsSecrets._2, piiadlsSecrets._3, piiadlsSecrets._4)

    val calender = Calendar.getInstance()
    val sdf = new SimpleDateFormat("yyyyMMddHHmm")
    sdf.setTimeZone(TimeZone.getTimeZone("America/New_York"))
    val time_now = sdf.format(calender.getTime())

    // Reading files from blob folder to store it in archive
    val fileList = dbutils.fs.ls(inputDir)
    fileList foreach { file =>
      val splitfile_nm = file.name.toString().split("\\.")                //splitfile_nm: Array[String] = Array(StoreBTS_eur_201911042203, txt)
      val file_nm = splitfile_nm.take(splitfile_nm.length-1).mkString(".")       //file_nm: String = StoreBTS_eur_201911042203
      val newfileName = s"${archivePath}/${file_nm + "_" + time_now + "." + splitfile_nm(splitfile_nm.length-1)}"     //newfileName: String = abc/StoreBTS_eur_201911251537.txt

      if (file.name.endsWith(file_pattern) || file.name.startsWith(file_pattern)) {
        dbutils.fs.mv(file.path, newfileName)
        logInfo("File Archived" + newfileName)
      }
    }
  }
}

