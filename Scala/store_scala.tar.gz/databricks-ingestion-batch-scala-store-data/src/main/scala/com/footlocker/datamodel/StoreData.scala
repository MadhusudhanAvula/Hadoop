package com.footlocker.datamodel

import org.apache.spark.internal.Logging
import org.apache.spark.sql.catalyst.ScalaReflection.schemaFor
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{Dataset, SparkSession}

case class StoreData(
  store: String,
  div: String,
  geo: String,
  lge: String,
  acct_stat: String,
  retl_stat: String,
  name: String,
  `type`: String,
  city: String,
  state: String,
  zip: String,
  open_date: String,
  market: String
)

object StoreData extends Logging {

  def load(spark: SparkSession, isLocalMode: Boolean, dataFiles: String): Dataset[StoreData] = {

    logWarning("Reading TC070001 Data from : " + dataFiles)

    readFromTextFile(spark, dataFiles)

  }

  def readFromTextFile(spark: SparkSession, dataFiles: String): Dataset[StoreData] = {

    logWarning("Running in local mode , so reading TC070001 Data from csv file")

    import spark.implicits._
    spark
      .read
      .option("header", "false")
      .option("delimiter", "|")
      .option("inferSchema", "false")
      .schema(schemaFor[StoreData].dataType.asInstanceOf[StructType])
      .csv(dataFiles)
      .as[StoreData]

  }
}
