import com.footlocker.datamodel.StoreData
import com.footlocker.utils.SparkSessionTestWrapper
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.{BeforeAndAfterAll, FunSuite}

@RunWith(classOf[JUnitRunner])
class StoreDataTransformationTest extends FunSuite with BeforeAndAfterAll with SparkSessionTestWrapper {

  private var templateRowStoreData: StoreData = _

  override def afterAll() {
    spark.catalog.clearCache()
  }

  override def beforeAll() {

    spark.catalog.clearCache()
  }

  templateRowStoreData = StoreData(
    store = "06005",
    div = "03",
    geo = "18",
    lge = "697",
    acct_stat = "C",
    retl_stat = "C",
    name = "",
    `type` = "",
    city = "PHOENIX",
    state = "AZ",
    zip = "85032",
    open_date = "830601",
    market = "0219"
  )

  test("Test Record Count") {

    import spark.implicits._
    val StoreDataDS = Seq(templateRowStoreData.copy(store = "001"),
      templateRowStoreData.copy(store = "002"),
      templateRowStoreData.copy(state = "003")
    ).toDS()

   //val preparedData = StoreData.load(spark ,true, "")
  }
}