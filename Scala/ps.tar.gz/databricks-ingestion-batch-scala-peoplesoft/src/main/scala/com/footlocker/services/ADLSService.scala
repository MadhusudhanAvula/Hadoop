package com.footlocker.services

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.footlocker.spark.SparkContextProvider
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.SparkSession


/**
  * This Trait provides helper functions to work with ADLS and the trait requires SparkContextProvider to be inherited to extend this trait
  */
trait ADLSService {

  this: SparkContextProvider =>

  /** Function to retrive ADLS Connection details
    *
    * @param credentialScope Scope of obtaining the Secrets
    * @return tuple of client_id, credential, directory_id, adls_url
    */
  def getADLSSecrets(credentialScope: String): (String, String, String, String) =
    ( dbutils.secrets.get(scope = credentialScope, key = "client_id"),
      dbutils.secrets.get(scope = credentialScope, key = "credential"),
      dbutils.secrets.get(scope = credentialScope, key = "directory_id"),
      dbutils.secrets.get(scope = credentialScope, key = "adls_url")
    )

/**The function reads parquet files from the provided path
  *
  * @param adlsPath path where the data should be read from
  * @param saveFormat Format of the data in the adlsPath - delta|parquet
  * @param schema Schema of the data if saveFormat is parquet
  * @return dataframe created from the filepath read
  */
def readADLSFiles(adlsPath: String, saveFormat: String, schema: Option[StructType]): DataFrame = {
  val df = schema match {
      case Some(sch) => {
        saveFormat.toLowerCase match {
          case "delta" => sparkSession.read.format("delta").load(adlsPath)
          case "parquet" => sparkSession.read.schema(sch).format("parquet").load(adlsPath)
        }
      }
      case None => sparkSession.read.format(saveFormat).load(adlsPath)
    }
  df
  }


  /**
    * This functions sets the necessary ADLS details to SparkSession Config
    *
    * @param clientId    Client Id
    * @param credential  Credential
    * @param directoryId Directory Id
    */
  def setAdlsConectivity(clientId: String, credential: String, directoryId: String): Unit = {
    implicit val spark: SparkSession = sparkSession
    spark.sparkContext.hadoopConfiguration.set("fs.adl.oauth2.access.token.provider.type", "ClientCredential")
    spark.sparkContext.hadoopConfiguration.set("fs.adl.oauth2.client.id", clientId)
    spark.sparkContext.hadoopConfiguration.set("fs.adl.oauth2.credential", credential)
    spark.sparkContext.hadoopConfiguration.set("fs.adl.oauth2.refresh.url", s"https://login.microsoftonline.com/$directoryId/oauth2/token")
  }

//  def retry[T](n: Int, tableName:String)(fn: => T): T = {
//    println(s"ADLS scope function calls for $tableName: $n")
//    util.Try { fn } match {
//      case util.Success(x) => x
//      case _ if n > 1 => {Thread.sleep(90000); retry(n - 1, tableName)(fn)}
//      case util.Failure(e) => throw e
//    }
//  }
//  retry(3, s"${this.getClass.getSimpleName}: ${args("adlsTableName")}") {}

//  /** Takes a dataframe and transforms it by
//    *       replacing all non alpha-numeric characters in colnames
//    *       converts all colnames to snakecase
//    *       cast all cols to stringtype
//    *       trims all cols
//    * @param inputDF
//    * @return
//    */
//  def transformDF(inputDF: DataFrame): DataFrame = {
//    inputDF.columns.foldLeft(inputDF){ (df, colName) =>
//      val regex  = "[^A-Za-z0-9]".r
//      df.withColumn(colName,trim(col(colName).cast(StringType)))
//        .withColumnRenamed(colName,regex.replaceAllIn(colName, "_")
//                                        .toLowerCase()
//                                        .replaceAll("__", ""))
//    }
//  }

  /** The function reads csv files from the provided path
    *
    * @param path path where the sv files should be read from
    * @return dataframe created from the files read
    */
  def readCSV(path: String, delimiter: String): DataFrame = {
    sparkSession
      .read
      .format("csv")
      .option("delimiter", delimiter)
      .option("header", "false")
      .option("escape", "\"")
      .option("quote","\"")
      .load(path)
      .na.drop(minNonNulls = 1)
  }

  /**
    *
    * @param adlsPath             Path in which the files have to be written
    * @param df               dataframe which is to be written
    * @param numPartitions    number of partitions to be written
    * @param saveMode         save mode that should be used for write
    * @param partitionColumns columns used to partition
    */
  def writeADLSFiles(adlsPath: String, df: DataFrame, numPartitions: String,
                     saveFormat: String, saveMode: String, partitionColumns: Option[String]): Unit = {

    partitionColumns match {
      case Some(cols) =>
        df.repartition(numPartitions.toInt, cols.split(",").toSeq.map(col): _*)
          .write
          .option("mergeSchema", "true")
          .format(saveFormat)
          .mode(saveMode)
          .partitionBy(cols.split(",").toSeq : _*)
          .save(adlsPath)

      case None =>
        df.repartition(numPartitions.toInt)
          .write
          .option("mergeSchema", "true")
          .format(saveFormat)
          .mode(saveMode)
          .save(adlsPath)
    }
  }
}
