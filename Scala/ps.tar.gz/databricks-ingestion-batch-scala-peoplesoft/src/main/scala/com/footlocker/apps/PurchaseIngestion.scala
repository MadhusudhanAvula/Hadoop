package com.footlocker.apps

import java.net.URI

import com.footlocker.AbstractApp
import com.footlocker.services.ADLSService
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{col, current_date}

// case class to define the header table schema
case class purchase_header(record_type:String, business_unit:String, po_id:String, po_date:String, po_status:String, po_type:String, fo_ind:String, orig_prom_dt:String, due_date:String, cancel_date:String, vendor_id:String, vendor_name:String, po_purpose_cd:String, po_purp_descr:String, po_reference:String, last_updt_dttm:String, comment: String)
case class purchase_line(record_type:String, business_unit:String, po_id:String,po_line_number:String, po_line_status:String, cancel_reason:String, item_id:String, sku:String, size:String, due_date:String, qty_po:String, qty_received:String, qty_on_order:String, retail_price:String, total_retail:String, cost:String, total_cost:String, division:String, mmx_fob:String, ny_dept:String, ny_dept_descr:String, misc:String, espd:String, class_gender:String, sub_class_1:String, team:String, vendor_item_id:String, model:String, model_descr:String, vendor_item_descr:String)

object PurchaseIngestion extends AbstractApp with ADLSService {

  def testDirExist(hadoopfs: FileSystem, path: String): Boolean = {
    val p = new Path(path)
    hadoopfs.exists(p) && hadoopfs.getFileStatus(p).isDirectory
  }

  override def execute(args: Map[String, String]): Unit = {
    implicit val spark: SparkSession = sparkSession

    // validate mandatory args
    assert(args.contains("adlsScope"), "Missing Argument: adlsScope")
    assert(args.contains("filePath"), "Missing Argument: filePath")
    assert(args.contains("adls"), "Missing Argument: adls")
    assert(args.contains("adlsLayer"), "Missing Argument: adlsLayer")
    assert(args.contains("adlsDatabase"), "Missing Argument: adlsDatabase")
    assert(args.contains("adlsTableName"), "Missing Argument: adlsTableName")
    assert(args.contains("delimiter"), "Missing Argument: delimiter")

    // Set ADLS connectivity
    val piiAdlsSecrets = getADLSSecrets(args("adlsScope"))
    setAdlsConectivity(piiAdlsSecrets._1, piiAdlsSecrets._2, piiAdlsSecrets._3)

    // Variables
    val adls = s"adl://${args("adls")}.azuredatalakestore.net/"
    val saveMode = args.getOrElse("saveMode", "overwrite")
    val numPartitions = args.getOrElse("numPartitions", "200")
    val partitionColumns = args.get("partitionColumns")
    //    val columnToModify = args.getOrElse("columnToModify","")
    val modifyColumn = args.getOrElse("modifyColumn", "").toLowerCase == "true"
    //    val newPartitionColumn = args.get("newPartitionColumn")
    val saveFormat = args.getOrElse("saveFormat", "delta")
    val filePath = args("filePath")
    val addLoadDate = args.getOrElse("addLoadDate", "").toLowerCase == "true"
    val adlsPath = (if (adls.charAt(adls.length - 1) == '/') adls else adls + "/") +
      (if (args("adlsLayer") == "") "" else args("adlsLayer") + "/") +
      (if (args("adlsDatabase") == "") "" else args("adlsDatabase") + "/") +
      args("adlsTableName")
    val delimiter = args.get("delimiter")

    // Read source csv files
    //val filePath = "/FileStore/tables/WW_PO_DATATM.txt"

    //val first_row_is_header = "false"
    //val delimiter = "|"

    // The applied options are for CSV files. For other file types, these will be ignored.
    //val df = spark.read.format("csv").schema(schema).option("header", false).option("sep", args("delimiter")).load(filePath)
    //    val srcDf = readCSV(filePath, args("delimiter"))
    //    val headerDF = srcDf.filter("_c0 = 'H'")
    //    val lineDF = srcDf.filter("_c0 = 'L'")
    //    val trailerDF = srcDf.filter("_c0 = 'T'")
    //
    //    val blobQuery = args.getOrElse("blobQuery","")
    //    val queryDF =if (!blobQuery.isEmpty) {
    //      println(s"blobQuery == $blobQuery")
    //      srcDf.createOrReplaceTempView(s"${args("adlsTableName")}")
    //      spark.sql(s"${args("blobQuery")}")
    //    }
    //    else srcDf

    val sc = spark.sparkContext
    // Import spark implicits to convert wrappedArray to DF
    println(s"filePath --> $filePath")
    println(s"adlsFileName --> ${args("adlsTableName")}")
    val textFile = sc.textFile(filePath)
    val rdd_to_df = if (args("adlsTableName").toLowerCase == "peoplesoft_po_header")
    {
      // Reading the file form blob and splitting the purchase file into header and line segments to ingest into ADLS
      import spark.implicits._
      textFile.map(x => (x(0), x)).filter{case(key: Char, value:String) => key == 'H'}.map(_._2).map(x=>x.split("\\|")).map(y => purchase_header(y(0),y(1),y(2),y(3),y(4),y(5),y(6),y(7),y(8),y(9),y(10),y(11),y(12),y(13),y(14),y(15),y(16))).toDF()
    }
    else //if (args("adlsTableName").toLowerCase == "line")
    {
      import spark.implicits._
      textFile.map(x => (x(0), x)).filter{case(key: Char, value:String) => key == 'L'}.map(_._2).map(x=>x.split("\\|")).map(y => purchase_line(y(0),y(1),y(2),y(3),y(4),y(5),y(6),y(7),y(8),y(9),y(10),y(11),y(12),y(13),y(14),y(15),y(16),y(17),y(18),y(19),y(20),y(21),y(22),y(23),y(24),y(25),y(26),y(27),y(28),y(29))).toDF()
    }

    // create a new column that is used to partitionBy
    val withDF = if (addLoadDate) {
      rdd_to_df.withColumn("load_date",current_date())
    }
    else rdd_to_df

    val finalDf = if (modifyColumn) {
      rdd_to_df.withColumn(s"${args("newPartitionColumn")}", (col(s"${args("columnToModify")}").cast("date")))
    }
    else withDF

    // Read target Path and get list of columns
    val hadoopfs: FileSystem = FileSystem.get(new URI("adlsPath"), spark.sparkContext.hadoopConfiguration)

    // Ingest data into ADLS
    println(s"adlsPath --> $adlsPath")
      testDirExist(hadoopfs, adlsPath) match {
        case true => {
          writeADLSFiles(adlsPath, finalDf, numPartitions, saveFormat, saveMode, partitionColumns)
        }
        case _ => writeADLSFiles(adlsPath, finalDf, numPartitions, saveFormat, saveMode, partitionColumns)
      }
  }
}
