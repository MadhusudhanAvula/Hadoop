package com.footlocker

import com.footlocker.spark.{SparkContextProvider, SparkRegistrator}
import com.footlocker.utils.{Arguments, WinUtilsLoader}

/**
  * Base class for implementing Spark code. Manages the SparkSession at beginning and end of code
  */
abstract class AbstractApp extends SparkContextProvider with Arguments {

  /**
    * Main entry point for the application, it starts the SparkSession before execute()
    *
    * @param args program arguments
    */
  def main(args: Array[String]): Unit = {
    // Load Winutils for local running
    WinUtilsLoader.loadWinUtils()

    // Parse Arguments
    val arguments = argsToMap(args)

    // Start a sparkSession
    createSparkSession("local[*]", this.getClass.toString, classOf[SparkRegistrator])

    // call application code
    execute(arguments)
  }

  /**
    * Override this to add functionality to your application
    */

  def execute(args: Map[String, String])
}
