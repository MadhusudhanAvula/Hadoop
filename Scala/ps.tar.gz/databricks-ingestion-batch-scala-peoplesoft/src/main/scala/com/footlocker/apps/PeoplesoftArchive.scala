package com.footlocker.apps

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.footlocker.AbstractApp
import com.footlocker.services.ADLSService

object PeoplesoftArchive extends AbstractApp with ADLSService{
  /** Usage: --piiAdlsScope "data-lake-scope"
   * --sourcePath "dbfs://mnt/inmoment/***/***"
   * --archivePath "dbfs://mnt/inmoment/archive"
   * --file_pattern ".txt | .tsv | .gz"
   * @param args
   */
  override def execute(args: Map[String, String]): Unit = {
    // Set ADLS connectivity
    val piiAdlsSecrets = getADLSSecrets(args("adlsScope"))
    setAdlsConectivity(piiAdlsSecrets._1, piiAdlsSecrets._2, piiAdlsSecrets._3)

    // Reading files from blob folder to store it in archive
    println(s"filePattern --> ${args("file_pattern")}")
    println(s"archivePath --> ${args("archivePath")}")
    val fileList = dbutils.fs.ls(args("sourcePath"))
    fileList foreach { file =>
            println(file)
            println(file.path)
            println(file.name)
      val archiveFile = s"${args("archivePath")}/${file.name}"
      if (file.name.startsWith(s"${args("file_pattern")}")){
        println(s"Archiving File --> $archiveFile")
        dbutils.fs.mv(file.path, archiveFile)}
    }
  }
}