package com.footlocker.apps

import java.text.SimpleDateFormat
import java.util.Calendar

import com.footlocker.AbstractApp
import com.footlocker.services.ADLSService
import org.apache.spark.sql.SparkSession

object PurchaseValidation extends AbstractApp with ADLSService{
  override def execute(args: Map[String, String]): Unit = {

    // validate mandatory args
    assert(args.contains("adlsScope"), "Missing Argument: adlsScope")
    assert(args.contains("adls"), "Missing Argument: adls")
    assert(args.contains("adlsLayer"), "Missing Argument: adlsLayer")
    assert(args.contains("adlsDatabase"), "Missing Argument: adlsDatabase")
    assert(args.contains("adlsTableName"), "Missing Argument: adlsTableName")

    // Set ADLS connectivity
    println(s"adlsScope --> ${args("adlsScope")}")
    val piiAdlsSecrets = getADLSSecrets(args("adlsScope"))
    setAdlsConectivity(piiAdlsSecrets._1, piiAdlsSecrets._2, piiAdlsSecrets._3)

    val form = new SimpleDateFormat("yyyy-MM-dd");
    val now = Calendar.getInstance().getTime()
    val formattedDate = form.format(now);
    println(formattedDate)

    implicit val spark: SparkSession = sparkSession
    val sc = spark.sparkContext

    val filePath = args("filePath")
    val textFile = sc.textFile(filePath)
    val file_count = if (args("adlsTableName").toLowerCase == "peoplesoft_po_header") {
      textFile.map(x => (x(0), x)).filter { case (key: Char, value: String) => key == 'T' }.map(_._2).map(x => x.split("\\|")).map(x => x(1)).map(_.toInt).reduce(_+_)
    }
    else {
      textFile.map(x => (x(0), x)).filter { case (key: Char, value: String) => key == 'T' }.map(_._2).map(x => x.split("\\|")).map(x => x(2)).map(_.toInt).reduce(_+_)
    }

    println(s"${args("adlsTableName")} data count for $formattedDate is $file_count")

    val validationDF =sparkSession.read.format("delta").load(s"adl://${args("adls")}.azuredatalakestore.net/${args("adlsLayer")}/${args("adlsDatabase")}/${args("adlsTableName")}").where(s"load_date='${formattedDate}'")
    val validation_count = validationDF.count()
    println(s"${args("adlsTableName")}  ADLS data count for $formattedDate is $validation_count")

    if (s"$validation_count".equals(s"$file_count")){
      println(s"${args("adlsTableName")} file count $file_count is matching with ${args("adlsTableName")} adls ${formattedDate} partition count $validation_count")
    }
    else{
      throw new IllegalStateException(s"${args("adlsTableName")} file count $file_count is not matching with ${args("adlsTableName")} adls ${formattedDate} partition count $validation_count")
    }
  }
}
