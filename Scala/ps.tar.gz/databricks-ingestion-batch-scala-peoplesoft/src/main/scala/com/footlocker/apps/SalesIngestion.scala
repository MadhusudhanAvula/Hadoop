package com.footlocker.apps

import java.net.URI

import com.footlocker.AbstractApp
import com.footlocker.apps.PurchaseIngestion.testDirExist
import com.footlocker.services.ADLSService
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.functions.{col, current_date}
import org.apache.spark.sql.{DataFrame, SparkSession}

object SalesIngestion extends AbstractApp with ADLSService {

  override def execute(args: Map[String, String]): Unit = {
    implicit val spark: SparkSession = sparkSession

    // validate mandatory args
    assert(args.contains("adlsScope"), "Missing Argument: adlsScope")
    assert(args.contains("filePath"), "Missing Argument: filePath")
    assert(args.contains("adls"), "Missing Argument: adls")
    assert(args.contains("adlsLayer"), "Missing Argument: adlsLayer")
    assert(args.contains("adlsDatabase"), "Missing Argument: adlsDatabase")
    assert(args.contains("adlsTableName"), "Missing Argument: adlsTableName")
    assert(args.contains("delimiter"), "Missing Argument: delimiter")

    // Set ADLS connectivity
    val piiAdlsSecrets = getADLSSecrets(args("adlsScope"))
    setAdlsConectivity(piiAdlsSecrets._1, piiAdlsSecrets._2, piiAdlsSecrets._3)

    // Variables
    val adls = s"adl://${args("adls")}.azuredatalakestore.net/"
    val saveMode = args.getOrElse("saveMode", "overwrite")
    val numPartitions = args.getOrElse("numPartitions", "200")
    val partitionColumns = args.get("partitionColumns")
    //    val columnToModify = args.getOrElse("columnToModify","")
    val modifyColumn = args.getOrElse("modifyColumn", "").toLowerCase == "true"
    //    val newPartitionColumn = args.get("newPartitionColumn")
    val saveFormat = args.getOrElse("saveFormat", "delta")
    val filePath = args("filePath")
    val addLoadDate = args.getOrElse("addLoadDate", "").toLowerCase == "true"
    val adlsPath = (if (adls.charAt(adls.length - 1) == '/') adls else adls + "/") +
      (if (args("adlsLayer") == "") "" else args("adlsLayer") + "/") +
      (if (args("adlsDatabase") == "") "" else args("adlsDatabase") + "/") +
      args("adlsTableName")
    //val delimiter = args.get("delimiter")
//    val adlsPath = s"/mnt/refined/sales/${args("adlsTableName")}"

    // Read source files
    /** The function reads csv files from the provided path
     *
     * @param path path where the sv files should be read from
     * @return dataframe created from the files read
     */
    def readFile(path: String, delimiter: String): DataFrame = {
      sparkSession
        .read
        .format("csv")
        .option("delimiter", delimiter)
        .option("header", "true")
        .option("escape", "\"")
        .option("quote", "\"")
        .load(path)
        .na.drop(minNonNulls = 1)
    }

    /** Takes a dataframe and transforms it by
     * replacing all non alpha-numeric characters in colnames
     * converts all colnames to snakecase
     * cast all cols to stringtype
     * trims all cols
     *
     * @param inputDF
     * @return
     */
    def transformDF(inputDF: DataFrame): DataFrame = {
      inputDF.columns.foldLeft(inputDF) { (df, cols) =>
        df.withColumnRenamed(cols, cols.replaceAll("^\\s+|\\s+$|__", "").toLowerCase())
      }
    }

    val srcDf = transformDF(readFile(filePath, args("delimiter")))
    srcDf.printSchema()

    println(s"ADLS ingestion for ${args("adlsTableName")} in ADLS Path ${adlsPath}")
    val withDF = if (addLoadDate) {
      srcDf.withColumn("load_date", current_date())
    }
    else srcDf

    val finalDf = if (modifyColumn) {
      srcDf.withColumn(s"${args("newPartitionColumn")}", (col(s"${args("columnToModify")}").cast("date")))
    }
    else withDF

    // Read target Path and get list of columns
    val hadoopfs: FileSystem = FileSystem.get(new URI("adlsPath"), spark.sparkContext.hadoopConfiguration)

    // Read target Path and get list of columns
    testDirExist(hadoopfs, adlsPath) match {
      case true => {
        val existingDF = readADLSFiles(adlsPath, args.getOrElse("saveFormat", "delta"), None)
        writeADLSFiles(adlsPath, existingDF, numPartitions, saveFormat, saveMode, partitionColumns)
      }
      case _ => writeADLSFiles(adlsPath, finalDf, numPartitions, saveFormat, saveMode, partitionColumns)
    }
  }
}