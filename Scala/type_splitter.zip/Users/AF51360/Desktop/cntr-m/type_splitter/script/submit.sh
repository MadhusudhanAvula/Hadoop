#!/bin/bash

SPARK_SUBMIT=/usr/bin/spark2-submit
SPARK_SVR=${1:-local}
FILE=$2
OUT=$3
QUEUE=${4:-default}
KEYTAB=ameet.keytab
CWD=`pwd`

if [ "$#" -lt 3 ]; then
    echo "Illegal number of arguments. <spark svr> <source file> <output dir> [optional:Queue name]"
    exit 1
fi

CLASS="com.anthem.bdf.TypeSplitterApp"
APP_JAR=../target/scala-2.11/type_splitter-assembly-0.1.jar
PRINCIPAL=af55267@DEVAD.WELLPOINT.COM
UPLOAD_FILES="../wellpoint.cacerts#wellpoint.cacerts,./log4j.properties#log4j.properties"
VM_OPTIONS="-Dlog4j.properties=log4j.properties"

# modes cluster, client
MODE=cluster
#   --conf "spark.executor.extraClassPath=/home/af54706/guava-16.0.1.jar" \
#   --driver-java-options "-Djavax.net.debug=all -Dlog4j.properties=./log4j.properties" \
#   --conf "spark.executor.extraJavaOptions=-Djavax.net.debug=all -Dlog4j.properties=./log4j.properties" \

# For SSL DEBUG add -Djavax.net.debug=all to driver and executor java options.

echo -e "Running TypeSplitter-> \n\tsource:${FILE} \n\tout:${OUT}"
if [ "$SPARK_SVR" == "yarn" ]
then
    $SPARK_SUBMIT \
    --master ${SPARK_SVR} \
    --queue ${QUEUE} \
    --keytab ${KEYTAB} \
    --principal ${PRINCIPAL} \
    --conf "spark.driver.port=39200" \
    --files ${UPLOAD_FILES} \
    --executor-cores 4 --num-executors 4 \
    --num-executors 3 \
    --driver-memory 1g --executor-memory 1g \
    --driver-class-path /home/af54706/guava-16.0.1.jar \
    --driver-java-options "-Dlog4j.properties=file://${CWD}/log4j.properties" \
    --conf "spark.driver.extraJavaOptions=-Dlog4j.configuration=file://${CWD}/log4j.properties" \
    --conf "spark.executor.extraJavaOptions=${VM_OPTIONS}" \
    --conf spark.network.timeout=10000000 \
    --conf spark.ui.port=44100 \
    --class ${CLASS} ${APP_JAR} $FILE $OUT
else
    $SPARK_SUBMIT \
    --master ${SPARK_SVR} \
    --conf "spark.driver.port=39200" \
    --executor-cores 4 --num-executors 4 \
    --num-executors 3 \
    --driver-memory 1g --executor-memory 1g \
    --driver-class-path /home/af54706/guava-16.0.1.jar \
    --driver-java-options "-Dlog4j.properties=file://${CWD}/log4j.properties" \
    --conf "spark.driver.extraJavaOptions=-Dlog4j.configuration=file://${CWD}/log4j.properties" \
    --conf "spark.executor.extraJavaOptions=${VM_OPTIONS}" \
    --conf spark.network.timeout=10000000 \
    --conf spark.ui.port=44100 \
    --class ${CLASS} ${APP_JAR} $FILE $OUT
fi