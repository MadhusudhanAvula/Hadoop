package com.anthem.bdf.parser

object EDI_461K_CLL_PAT_CNDTN extends BaseParser {
  override val FILE_TYPE: String = "461K"

  override def FIELD_LENGTHS() =
    Array(
      14, 3, 3, 1, 3, 2, 1, 3, 3, 3, 3, 3, 2, 1, 3, 3, 3, 3, 3, 2, 1, 3, 3, 3, 3, 3, 2, 1, 3, 3, 3, 3, 3, 2, 1, 3, 3,
      3, 3, 3, 2, 1, 3, 3, 3, 3, 3, 2, 1, 3, 3, 3, 3, 3, 2, 1, 3, 3, 3, 3, 3, 682, 10
    )
}