package com.anthem.bdf.parser

object EDI_461D_CLM_SPCL_DT extends BaseParser {
  override val FILE_TYPE: String = "461D"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 3, 8, 8, 4, 481, 10)
}
