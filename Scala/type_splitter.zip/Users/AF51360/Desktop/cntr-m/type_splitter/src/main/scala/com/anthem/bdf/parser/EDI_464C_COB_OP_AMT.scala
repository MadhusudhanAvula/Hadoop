package com.anthem.bdf.parser

object EDI_464C_COB_OP_AMT extends BaseParser {
  override val FILE_TYPE: String = "464C"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 10, 3, 10, 3, 10, 56, 7, 7, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 7, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 398, 10)
}
