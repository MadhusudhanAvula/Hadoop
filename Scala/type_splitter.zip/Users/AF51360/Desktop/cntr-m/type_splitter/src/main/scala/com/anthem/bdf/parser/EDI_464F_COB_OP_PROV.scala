package com.anthem.bdf.parser

object EDI_464F_COB_OP_PROV extends BaseParser {
  override val FILE_TYPE: String = "464F"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 1, 3, 50, 3, 50, 3, 50, 3, 50, 610, 10)
}
