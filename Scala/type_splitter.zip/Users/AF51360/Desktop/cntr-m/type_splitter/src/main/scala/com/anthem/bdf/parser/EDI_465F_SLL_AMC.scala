package com.anthem.bdf.parser

object EDI_465F_SLL_AMC extends BaseParser {
  override val FILE_TYPE: String = "465F"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 10, 1, 2, 7, 80, 80, 644, 10)
}