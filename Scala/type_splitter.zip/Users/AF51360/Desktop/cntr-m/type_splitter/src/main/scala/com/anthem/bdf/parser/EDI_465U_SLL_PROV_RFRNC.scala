package com.anthem.bdf.parser

object EDI_465U_SLL_PROV_RFRNC extends BaseParser {
  override val FILE_TYPE: String = "465U"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 3, 50, 3, 50, 3, 50, 3, 50, 3, 50, 3, 50, 3, 50, 3, 50, 3, 50, 3, 50, 293, 10)
}