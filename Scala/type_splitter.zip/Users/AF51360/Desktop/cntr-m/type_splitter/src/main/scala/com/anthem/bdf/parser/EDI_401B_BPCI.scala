package com.anthem.bdf.parser

object EDI_401B_BPCI extends BaseParser {
  override val FILE_TYPE: String = "401B"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 60, 2, 256, 508, 10)
}
