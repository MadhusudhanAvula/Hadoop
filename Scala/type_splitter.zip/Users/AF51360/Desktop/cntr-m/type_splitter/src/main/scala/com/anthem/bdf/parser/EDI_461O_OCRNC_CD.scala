package com.anthem.bdf.parser

object EDI_461O_OCRNC_CD extends BaseParser {
  override val FILE_TYPE: String = "461O"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 4, 8, 3, 4, 8, 3, 4, 8, 3, 4, 8, 3, 4, 8, 3, 4, 8, 3, 4, 8, 3, 4, 8, 706, 10)
}
