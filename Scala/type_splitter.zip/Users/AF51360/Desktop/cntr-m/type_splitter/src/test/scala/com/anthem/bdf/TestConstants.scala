package com.anthem.bdf

import com.anthem.bdf.config.TypeConstants

object TestConstants {
  val CLM_HDR_LINE = "8201910523222A40000AA00AANTHEM         PCA20025N       EP401DCA       005010X222A1                       20190415RPPB01E41 46DIVERSIFIED DATA DESIGN CORP            2DIVERSIFIED DATA DESIGN CORP                                                                                            47198                                    CP19105073541374359                                        797582533201904150719EST              "
  val EXT_CLM: String = TypeConstants.JUSTIFIED_LINE_FORMAT.format(CLM_HDR_LINE)+TypeConstants.EXT_FORMAT.format("808")
}
