package com.anthem.bdf.parser

object EDI_461G_CLM_LVL_RMRK extends BaseParser {
  override val FILE_TYPE: String = "461G"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 80, 3, 80, 660, 10)
}
