package com.anthem.bdf.parser

object EDI_461Z_EMRGNCY_DATA extends BaseParser {
  override val FILE_TYPE: String = "461Z"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 80, 746, 10)
}
