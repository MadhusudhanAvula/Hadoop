package com.anthem.bdf.parser

object EDI_461H_CLL_AMC extends BaseParser {
  override val FILE_TYPE: String = "461H"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 10, 1, 2, 7, 80, 80, 644, 10)
}
