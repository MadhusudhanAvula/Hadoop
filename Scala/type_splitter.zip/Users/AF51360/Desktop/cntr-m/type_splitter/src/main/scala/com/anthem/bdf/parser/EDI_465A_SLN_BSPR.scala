package com.anthem.bdf.parser

object EDI_465A_SLN_BSPR extends BaseParser {
  override val FILE_TYPE: String = "465A1"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 10, 2, 2, 2, 2, 80, 10, 2, 11, 2, 2, 2, 2, 2, 1, 1, 1, 1, 2, 10, 2, 7, 10, 10, 1, 1, 2, 7, 3, 8, 8, 2, 10, 6, 25, 6, 15, 3, 10, 3, 10, 25, 10, 493, 10)
}
