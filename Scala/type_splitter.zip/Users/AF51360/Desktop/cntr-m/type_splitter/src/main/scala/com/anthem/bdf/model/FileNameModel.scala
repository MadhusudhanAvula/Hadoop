package com.anthem.bdf.model

case class FileNameModel(
                          name: String, sorCd: String,
                          sorExtPadded: String,
                          sourceName: String,
                          timestamp: String,var isSuccess: Boolean = true) {
  override def toString: String = {
    s"${this.getClass.getSimpleName}:{\n\t\tname:$name,\n\t\tsorCd:$sorCd,\n\t\tsorExtPadded:$sorExtPadded," +
      s"\n\t\tsourceName:$sourceName\n\t\ttimestamp:$timestamp,\n\t\tisSuccess:$isSuccess" +
      s" \n}"
  }
}

