package com.anthem.bdf.parser

object EDI_465L_SLL_SPCL_RFRNC extends BaseParser {
  override val FILE_TYPE: String = "465L"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 50, 3, 50, 3, 50, 3, 50, 614, 10)
}