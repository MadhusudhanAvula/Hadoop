package com.anthem.bdf.parser

object EDI_465Q_SLL_DRUG_IDFCTN extends BaseParser {
  override val FILE_TYPE: String = "465Q"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 14, 11, 2, 3, 50, 744, 10)
}