package com.anthem.bdf.parser

object EDI_461E_CLL_ATCHMNT extends BaseParser {
  override val FILE_TYPE: String = "461E"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 2, 2, 50, 770, 10)
}
