package com.anthem.bdf.model

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

case class ArgsModel(file: String, output: String, spark: SparkSession, appId: String, startTime: Long,
                     trailerRDD: RDD[String], singleOutputDir: String) extends Serializable {
  override def toString: String = {
    s"CommandLineArgs:{\n\t\t\tfile:$file,\n\t\t\toutputDirectory:$output,\n\t\t\tappId:$appId," +
      s"\n\t\t\tsingleOutputDir:$singleOutputDir \n}"
  }
}
