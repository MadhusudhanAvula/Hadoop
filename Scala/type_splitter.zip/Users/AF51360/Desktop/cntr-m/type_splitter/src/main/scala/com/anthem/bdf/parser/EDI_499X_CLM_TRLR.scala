package com.anthem.bdf.parser

object EDI_499X_CLM_TRLR extends BaseParser {
  override val FILE_TYPE: String = "499X"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 7, 3, 11, 805, 10)
}