package com.anthem.bdf.parser

import org.apache.log4j.Logger

/**
  * pick the appropriate parser with field lengths based on file name key
  */
object ParserFactory extends Serializable {
  @transient lazy val LOGGER: Logger = Logger.getLogger(this.getClass.getCanonicalName)
  val EDI_400A_CLM_HDR_Parser: BaseParser = EDI_400A_CLM_HDR
  val EDI_400B_SCI_Parser: BaseParser = EDI_400B_SCI
  val EDI_401A_BILLG_PROV_Parser: BaseParser = EDI_401A_BILLG_PROV
  val EDI_401B_BPCI_Parser: BaseParser = EDI_401B_BPCI
  val EDI_402A_PAY_TO_PROV_Parser: BaseParser = EDI_402A_PAY_TO_PROV
  val EDI_410A_PAY_TO_PLAN_Parser: BaseParser = EDI_410A_PAY_TO_PLAN
  val EDI_421A_SBSCRBR_Parser: BaseParser = EDI_421A_SBSCRBR
  val EDI_422A_PAYER_Parser: BaseParser = EDI_422A_PAYER
  val EDI_441A_PAT_Parser: BaseParser = EDI_441A_PAT

  val EDI_461A_CLM_BSIC_Parser: BaseParser = EDI_461A_CLM_BSIC
  //  val EDI_461C_CLM_ITS_Parser: BaseParser = EDI_461C_CLM_ITS
  val EDI_461D_CLM_SPCL_DT_Parser: BaseParser = EDI_461D_CLM_SPCL_DT
  val EDI_461E_CLL_ATCHMNT_Parser: BaseParser = EDI_461E_CLL_ATCHMNT
  val EDI_461F_CLL_SPCL_RFRNC_Parser: BaseParser = EDI_461F_CLL_SPCL_RFRNC
  val EDI_461G_CLM_LVL_RMRK_Parser: BaseParser = EDI_461G_CLM_LVL_RMRK
  val EDI_461H_CLL_AMC_Parser: BaseParser = EDI_461H_CLL_AMC
  val EDI_461I_CLL_CHC_Parser: BaseParser = EDI_461I_CLL_CHC
  val EDI_461K_CLL_PAT_CNDTN_Parser: BaseParser = EDI_461K_CLL_PAT_CNDTN
  val EDI_461L_DIAG_CD_Parser: BaseParser = EDI_461L_DIAG_CD
  val EDI_461M_PROC_CD_Parser: BaseParser = EDI_461M_PROC_CD
  val EDI_461N_OCRNC_SPAN_Parser: BaseParser = EDI_461N_OCRNC_SPAN
  val EDI_461O_OCRNC_CD_Parser: BaseParser = EDI_461O_OCRNC_CD
  val EDI_461P_VAL_CD_Parser: BaseParser = EDI_461P_VAL_CD
  val EDI_461Q_CNDTN_CD_Parser: BaseParser = EDI_461Q_CNDTN_CD
  val EDI_461R_TRTMNT_CD_Parser: BaseParser = EDI_461R_TRTMNT_CD
  val EDI_461U_CLL_PRCG_Parser: BaseParser = EDI_461U_CLL_PRCG
  val EDI_461Z_EMRGNCY_DATA_Parser: BaseParser = EDI_461Z_EMRGNCY_DATA
  val EDI_463A_CLM_PROV_Parser: BaseParser = EDI_463A_CLM_PROV
  val EDI_463B_CPCI_Parser: BaseParser = EDI_463B_CPCI
  val EDI_464A_COB_SBSCRBR_Parser: BaseParser = EDI_464A_COB_SBSCRBR
  val EDI_464B_COB_ADJSTMNT_Parser: BaseParser = EDI_464B_COB_ADJSTMNT
  val EDI_464C_COB_OP_AMT_Parser: BaseParser = EDI_464C_COB_OP_AMT
  val EDI_464D_COB_OP_Parser: BaseParser = EDI_464D_COB_OP
  //  val EDI_464E_COB_OP_PAT_Parser: BaseParser = EDI_464E_COB_OP_PAT
  val EDI_464F_COB_OP_PROV_Parser: BaseParser = EDI_464F_COB_OP_PROV
  //  val EDI_465A_SLN_Parser: BaseParser = EDI_465A_SLN
  val EDI_465A_SLN_BSPR_Parser: BaseParser = EDI_465A_SLN_BSPR
  val EDI_465A_SLN_BSIN_Parser: BaseParser = EDI_465A_SLN_BSIN
  val EDI_465A_SLN_BSIS_DNTL_Parser: BaseParser = EDI_465A_SLN_BSIS_DNTL
  //  val EDI_465C_SLN_ITS_Parser: BaseParser = EDI_465C_SLN_ITS
  val EDI_465D_SLL_ATCHMNT_Parser: BaseParser = EDI_465D_SLL_ATCHMNT
  val EDI_465E_SLL_TOOTH_INFO_Parser: BaseParser = EDI_465E_SLL_TOOTH_INFO
  val EDI_465F_SLL_AMC_Parser: BaseParser = EDI_465F_SLL_AMC
  val EDI_465H_SLL_CNDTN_Parser: BaseParser = EDI_465H_SLL_CNDTN
  val EDI_465I_SLL_SPCL_DT_Parser: BaseParser = EDI_465I_SLL_SPCL_DT
  val EDI_465J_SLL_ITEM_CNT_Parser: BaseParser = EDI_465J_SLL_ITEM_CNT
  val EDI_465K_SLL_MSRMNT_Parser: BaseParser = EDI_465K_SLL_MSRMNT
  val EDI_465L_SLL_SPCL_RFRNC_Parser: BaseParser = EDI_465L_SLL_SPCL_RFRNC
  val EDI_465M_SLL_RMRK_Parser: BaseParser = EDI_465M_SLL_RMRK
  val EDI_465N_SLL_PRCG_Parser: BaseParser = EDI_465N_SLL_PRCG
  val EDI_465Q_SLL_DRUG_IDFCTN_Parser: BaseParser = EDI_465Q_SLL_DRUG_IDFCTN
  val EDI_465T_SLL_PROV_Parser: BaseParser = EDI_465T_SLL_PROV
  val EDI_465U_SLL_PROV_RFRNC_Parser: BaseParser = EDI_465U_SLL_PROV_RFRNC
  val EDI_465V_SLL_PROV_CNTCT_Parser: BaseParser = EDI_465V_SLL_PROV_CNTCT
  val EDI_465W_SLL_COB_LAI_Parser: BaseParser = EDI_465W_SLL_COB_LAI
  val EDI_465X_SLL_FORMID_Parser: BaseParser = EDI_465X_SLL_FORMID
  val EDI_465Z_EMRGNCY_DATA_Parser: BaseParser = EDI_465Z_EMRGNCY_DATA
  //  val EDI_499C_IMPRT_LCL_DATA_Parser: BaseParser = EDI_499C_IMPRT_LCL_DATA
  val EDI_499X_CLM_TRLR_Parser: BaseParser = EDI_499X_CLM_TRLR


  def get(fileType: String): BaseParser = {
    LOGGER.info(s">> In map Partitions, getting parser for:$fileType")

    fileType match {
      case "400A" => EDI_400A_CLM_HDR_Parser
      case "400B" => EDI_400B_SCI_Parser
      case "401A" => EDI_401A_BILLG_PROV_Parser
      case "401B" => EDI_401B_BPCI_Parser
      case "402A" => EDI_402A_PAY_TO_PROV_Parser
      case "410A" => EDI_410A_PAY_TO_PLAN_Parser
      case "421A" => EDI_421A_SBSCRBR_Parser
      case "422A" => EDI_422A_PAYER_Parser
      case "441A" => EDI_441A_PAT_Parser
      case "461A" => EDI_461A_CLM_BSIC_Parser
      //      case "461C" => EDI_461C_CLM_ITS_Parser
      case "461D" => EDI_461D_CLM_SPCL_DT_Parser
      case "461E" => EDI_461E_CLL_ATCHMNT_Parser
      case "461F" => EDI_461F_CLL_SPCL_RFRNC_Parser
      case "461G" => EDI_461G_CLM_LVL_RMRK_Parser
      case "461H" => EDI_461H_CLL_AMC_Parser
      case "461I" => EDI_461I_CLL_CHC_Parser
      case "461K" => EDI_461K_CLL_PAT_CNDTN_Parser
      case "461L" => EDI_461L_DIAG_CD_Parser
      case "461M" => EDI_461M_PROC_CD_Parser
      case "461N" => EDI_461N_OCRNC_SPAN_Parser
      case "461O" => EDI_461O_OCRNC_CD_Parser
      case "461P" => EDI_461P_VAL_CD_Parser
      case "461Q" => EDI_461Q_CNDTN_CD_Parser
      case "461R" => EDI_461R_TRTMNT_CD_Parser
      case "461U" => EDI_461U_CLL_PRCG_Parser
      case "461Z" => EDI_461Z_EMRGNCY_DATA_Parser
      case "463A" => EDI_463A_CLM_PROV_Parser
      case "463B" => EDI_463B_CPCI_Parser
      case "464A" => EDI_464A_COB_SBSCRBR_Parser
      case "464B" => EDI_464B_COB_ADJSTMNT_Parser
      case "464C" => EDI_464C_COB_OP_AMT_Parser
      case "464D" => EDI_464D_COB_OP_Parser
      //case "464E" => EDI_464E_COB_OP_PAT_Parser
      case "464F" => EDI_464F_COB_OP_PROV_Parser
      //case "465A" => EDI_465A_SLN_Parser
      case "465A1" => EDI_465A_SLN_BSPR_Parser
      case "465A2" => EDI_465A_SLN_BSIN_Parser
      case "465A3" => EDI_465A_SLN_BSIS_DNTL_Parser
      //case "465C" => EDI_465C_SLN_ITS_Parser
      case "465D" => EDI_465D_SLL_ATCHMNT_Parser
      case "465E" => EDI_465E_SLL_TOOTH_INFO_Parser
      case "465F" => EDI_465F_SLL_AMC_Parser
      case "465H" => EDI_465H_SLL_CNDTN_Parser
      case "465I" => EDI_465I_SLL_SPCL_DT_Parser
      case "465J" => EDI_465J_SLL_ITEM_CNT_Parser
      case "465K" => EDI_465K_SLL_MSRMNT_Parser
      case "465L" => EDI_465L_SLL_SPCL_RFRNC_Parser
      case "465M" => EDI_465M_SLL_RMRK_Parser
      case "465N" => EDI_465N_SLL_PRCG_Parser
      case "465Q" => EDI_465Q_SLL_DRUG_IDFCTN_Parser
      case "465T" => EDI_465T_SLL_PROV_Parser
      case "465U" => EDI_465U_SLL_PROV_RFRNC_Parser
      case "465V" => EDI_465V_SLL_PROV_CNTCT_Parser
      case "465W" => EDI_465W_SLL_COB_LAI_Parser
      case "465X" => EDI_465X_SLL_FORMID_Parser
      case "465Z" => EDI_465Z_EMRGNCY_DATA_Parser
      //      case "499C" => EDI_499C_IMPRT_LCL_DATA_Parser
      case "499X" => EDI_499X_CLM_TRLR_Parser
    }
  }
  def getReverse(fileType:String) : BaseParser={
    fileType match {
      case "EDI_400A_CLM_HDR" => EDI_400A_CLM_HDR_Parser
      case "EDI_400B_SCI" => EDI_400B_SCI_Parser
      case "EDI_401A_BILLG_PROV" => EDI_401A_BILLG_PROV_Parser
      case "EDI_401B_BPCI" => EDI_401B_BPCI_Parser
      case "EDI_402A_PAY_TO_PROV" => EDI_402A_PAY_TO_PROV_Parser
      case "EDI_410A_PAY_TO_PLAN" => EDI_410A_PAY_TO_PLAN_Parser
      case "EDI_421A_SBSCRBR" => EDI_421A_SBSCRBR_Parser
      case "EDI_422A_PAYER" => EDI_422A_PAYER_Parser
      case "EDI_441A_PAT" => EDI_441A_PAT_Parser
      case "EDI_461A_CLM_BSIC" => EDI_461A_CLM_BSIC_Parser
      //      case "EDI_461C_CLM_ITS" => EDI_461C_CLM_ITS_Parser
      case "EDI_461D_CLM_SPCL_DT" => EDI_461D_CLM_SPCL_DT_Parser
      case "EDI_461E_CLL_ATCHMNT" => EDI_461E_CLL_ATCHMNT_Parser
      case "EDI_461F_CLL_SPCL_RFRNC" => EDI_461F_CLL_SPCL_RFRNC_Parser
      case "EDI_461G_CLM_LVL_RMRK" => EDI_461G_CLM_LVL_RMRK_Parser
      case "EDI_461H_CLL_AMC" => EDI_461H_CLL_AMC_Parser
      case "EDI_461I_CLL_CHC" => EDI_461I_CLL_CHC_Parser
      case "EDI_461K_CLL_PAT_CNDTN" => EDI_461K_CLL_PAT_CNDTN_Parser
      case "EDI_461L_DIAG_CD" => EDI_461L_DIAG_CD_Parser
      case "EDI_461M_PROC_CD" => EDI_461M_PROC_CD_Parser
      case "EDI_461N_OCRNC_SPAN" => EDI_461N_OCRNC_SPAN_Parser
      case "EDI_461O_OCRNC_CD" => EDI_461O_OCRNC_CD_Parser
      case "EDI_461P_VAL_CD" => EDI_461P_VAL_CD_Parser
      case "EDI_461Q_CNDTN_CD" => EDI_461Q_CNDTN_CD_Parser
      case "EDI_461R_TRTMNT_CD" => EDI_461R_TRTMNT_CD_Parser
      case "EDI_461U_CLL_PRCG" => EDI_461U_CLL_PRCG_Parser
      case "EDI_461Z_EMRGNCY_DATA" => EDI_461Z_EMRGNCY_DATA_Parser
      case "EDI_463A_CLM_PROV" => EDI_463A_CLM_PROV_Parser
      case "EDI_463B_CPCI" => EDI_463B_CPCI_Parser
      case "EDI_464A_COB_SBSCRBR" => EDI_464A_COB_SBSCRBR_Parser
      case "EDI_464B_COB_ADJSTMNT" => EDI_464B_COB_ADJSTMNT_Parser
      case "EDI_464C_COB_OP_AMT" => EDI_464C_COB_OP_AMT_Parser
      case "EDI_464D_COB_OP" => EDI_464D_COB_OP_Parser
      //case "EDI_464E_COB_OP_PAT" => EDI_464E_COB_OP_PAT_Parser
      case "EDI_464F_COB_OP_PROV" => EDI_464F_COB_OP_PROV_Parser
      //case "EDI_465A_SLN" => EDI_465A_SLN_Parser
      case "EDI_465A_SLN_BSPR" => EDI_465A_SLN_BSPR_Parser
      case "EDI_465A_SLN_BSIN" => EDI_465A_SLN_BSIN_Parser
      case "EDI_465A_SLN_BSIS_DNTL" => EDI_465A_SLN_BSIS_DNTL_Parser
      //case "EDI_465C_SLN_ITS" => EDI_465C_SLN_ITS_Parser
      case "EDI_465D_SLL_ATCHMNT" => EDI_465D_SLL_ATCHMNT_Parser
      case "EDI_465E_SLL_TOOTH_INFO" => EDI_465E_SLL_TOOTH_INFO_Parser
      case "EDI_465F_SLL_AMC" => EDI_465F_SLL_AMC_Parser
      case "EDI_465H_SLL_CNDTN" => EDI_465H_SLL_CNDTN_Parser
      case "EDI_465I_SLL_SPCL_DT" => EDI_465I_SLL_SPCL_DT_Parser
      case "EDI_465J_SLL_ITEM_CNT" => EDI_465J_SLL_ITEM_CNT_Parser
      case "EDI_465K_SLL_MSRMNT" => EDI_465K_SLL_MSRMNT_Parser
      case "EDI_465L_SLL_SPCL_RFRNC" => EDI_465L_SLL_SPCL_RFRNC_Parser
      case "EDI_465M_SLL_RMRK" => EDI_465M_SLL_RMRK_Parser
      case "EDI_465N_SLL_PRCG" => EDI_465N_SLL_PRCG_Parser
      case "EDI_465Q_SLL_DRUG_IDFCTN" => EDI_465Q_SLL_DRUG_IDFCTN_Parser
      case "EDI_465T_SLL_PROV" => EDI_465T_SLL_PROV_Parser
      case "EDI_465U_SLL_PROV_RFRNC" => EDI_465U_SLL_PROV_RFRNC_Parser
      case "EDI_465V_SLL_PROV_CNTCT" => EDI_465V_SLL_PROV_CNTCT_Parser
      case "EDI_465W_SLL_COB_LAI" => EDI_465W_SLL_COB_LAI_Parser
      case "EDI_465X_SLL_FORMID" => EDI_465X_SLL_FORMID_Parser
      case "EDI_465Z_EMRGNCY_DATA" => EDI_465Z_EMRGNCY_DATA_Parser
      //      case "EDI_499C_IMPRT_LCL_DATA" => EDI_499C_IMPRT_LCL_DATA_Parser
      case "EDI_499X_CLM_TRLR" => EDI_499X_CLM_TRLR_Parser
    }
  }
}
