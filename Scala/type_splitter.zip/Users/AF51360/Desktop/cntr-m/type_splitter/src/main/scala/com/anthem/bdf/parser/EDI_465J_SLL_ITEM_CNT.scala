package com.anthem.bdf.parser

object EDI_465J_SLL_ITEM_CNT extends BaseParser {
  override val FILE_TYPE: String = "465J"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 11, 2, 11, 800, 10)
}