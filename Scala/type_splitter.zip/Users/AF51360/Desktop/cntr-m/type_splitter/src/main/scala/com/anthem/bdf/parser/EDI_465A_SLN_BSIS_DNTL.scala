package com.anthem.bdf.parser

object EDI_465A_SLN_BSIS_DNTL extends BaseParser {
  override val FILE_TYPE: String = "465A3"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 10, 2, 2, 2, 2, 80, 10, 2, 3, 3, 3, 3, 3, 1, 11, 2, 2, 2, 2, 3, 8, 8, 2, 10, 6, 25, 6, 15, 3, 10, 583, 10)
}
