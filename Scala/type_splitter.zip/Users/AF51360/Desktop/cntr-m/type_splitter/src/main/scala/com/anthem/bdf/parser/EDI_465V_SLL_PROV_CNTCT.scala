package com.anthem.bdf.parser

object EDI_465V_SLL_PROV_CNTCT extends BaseParser {
  override val FILE_TYPE: String = "465V"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 60, 2, 200, 2, 200, 2, 200, 157, 10)
}