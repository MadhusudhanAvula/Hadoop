package com.anthem.bdf

import com.anthem.bdf.config.TypeConstants
import com.anthem.bdf.parser.{EDI_400A_CLM_HDR, EDI_410A_PAY_TO_PLAN, EDI_461K_CLL_PAT_CNDTN, ParserFactory}
import com.anthem.bdf.service.FixedWidthParser
import org.apache.log4j.{LogManager, Logger}
import org.scalatest.{FlatSpec, Matchers}

import scala.util.matching.Regex

class TestParser extends FlatSpec with Matchers {
  @transient lazy val LOGGER: Logger = LogManager.getLogger(this.getClass.getCanonicalName)
  val CLM_HDR_LINE = "8201910523222A40000AA00AANTHEM         PCA20025N       EP401DCA       005010X222A1                       20190415RPPB01E41 46DIVERSIFIED DATA DESIGN CORP            2DIVERSIFIED DATA DESIGN CORP                                                                                            47198                                    CP19105073541374359                                        797582533201904150719EST              "
  val EXT_CLM: String = TypeConstants.JUSTIFIED_LINE_FORMAT.format(CLM_HDR_LINE)+TypeConstants.EXT_FORMAT.format("808")
  val K_461_LINE = "8201910518057B46100AK00A07Y06             07N07                                                  " +
    "                                                                                                                " +
    "                                                                                                                " +
    "                                                                                                                " +
    "                                                                                                                " +
    "                                                                                                                " +
    "                                                                                                                " +
    "                                                                                 808       "
  val BSIN_LINE: String = "6201908800537B46500AL00A6R 398997-1                                                               " +
    "                                                                                                                " +
    "                                                  "

  "461K" should "parse" in {
    println(s"Len of line:${K_461_LINE.length}")
//    val matchOption: Option[Regex.Match] = EDI_461K_CLL_PAT_CNDTN.MY_REGEX.findFirstMatchIn(K_461_LINE)
    val delimLine = EDI_461K_CLL_PAT_CNDTN.toRegexDelim(K_461_LINE)
    println(s"# of fields = ${delimLine.split("\\|#").length}")
    println(delimLine)
  }
  "substring 400A" should "parse" in {
    val delimLine= EDI_400A_CLM_HDR.toDelim(EXT_CLM)
    println(s"# of fields = ${delimLine.split("\\|#").length}")
    println(delimLine)
  }
  "parse 400 A" should "parse" in {
    val fields: Array[String] = EDI_400A_CLM_HDR.getParser.parseLine(EXT_CLM)
    println(s">> Number of fields in line: ${fields.length}")
    println(fields.map(f=>f.trim).mkString("\\|#"))
  }
  "parse BSIN" should "parse" in {
    val fields: Array[String] = ParserFactory.get("465A2").getParser.parseLine(BSIN_LINE)
    println(s">> Number of fields in line: ${fields.length}")
    println(fields.mkString(","))
  }
  "pad" should "add space" in {
    val a = "amm"
    val pad = 10
    val padded = f"$a%10s"
    val p1 = "%-10s".format(a)
    println(a+"|")
    println(f"$a%-10s")
    print(s"With padding:=> $p1 |||")
  }
  "461M" should "parse" in {
    val line = "8201910581882C46100AM00ABP 52260"
    val paddedLine = s"%-${TypeConstants.TOTAL_LINE_LEN}s".format(line)
    val finStr = ParserFactory.get("461M").getParser.parseLine(line).mkString(TypeConstants.OUTPUT_DELIM)
    print(finStr)
  }
  "pad plus ext" should "parse" in {
    val line = "8201910581882C46100AM00ABP 52260"
    val paddedLine = "%-850s".format(line)
    val ext = TypeConstants.EXT_FORMAT.format("808")
    val finlin = paddedLine+ext
    println(s">>$finlin X")
    print(s"[$finlin X]")
  }
  "Pro line" should "parse" in {
    val line="8201910519082I46100AA00A247113P41713-P1                       000001750{111BPYAYY                      " +
      "                                                          000000{000000{                                      " +
      "                                                                                                              " +
      "                                                                                                              " +
      "                                                                                                   " +
      "000000000{00000{                         00000{                  000000000{                         "+
    " "*39
    val filename="file:///home/af55267/app/type_splitter/script/WGS_EDI_CLM_PRO_20225515076252.dat"
    val lineNonNull = line.trim
    val (filenameKey, fileType) = FixedWidthParser.fileType(lineNonNull)

    val paddedLine = TypeConstants.JUSTIFIED_LINE_FORMAT.format(lineNonNull)
    val filenameModel = FixedWidthParser.nameToModel(filename)
    val enhancedLine =   paddedLine + filenameModel.sorExtPadded

    println("enhanced:["+enhancedLine.length+"]"+enhancedLine)
    println("padded:["+paddedLine.length+"]"+paddedLine)
  }

  "length regex" should "parse" in {
    val line = "aaaXXXX88YYY"
    val pattern = "^(.{3})(.{4})(.{2})(.{3})$".r
    pattern.findAllIn(line).matchData foreach{
      m=>
        println(m.groupCount)
        for (a<-1 to m.groupCount){
          println(s"\t ${m.group(a)}")
        }
    }

  }
}
