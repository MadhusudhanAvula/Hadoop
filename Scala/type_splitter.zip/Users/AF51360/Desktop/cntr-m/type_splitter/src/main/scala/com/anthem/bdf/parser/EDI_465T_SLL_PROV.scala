package com.anthem.bdf.parser

object EDI_465T_SLL_PROV extends BaseParser {
  override val FILE_TYPE: String = "465T"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 1, 60, 35, 25, 10, 2, 40, 55, 55, 30, 2, 15, 3, 3, 3, 25, 459, 10)
}