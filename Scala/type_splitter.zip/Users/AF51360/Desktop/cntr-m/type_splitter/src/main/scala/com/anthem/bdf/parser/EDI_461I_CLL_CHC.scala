package com.anthem.bdf.parser

object EDI_461I_CLL_CHC extends BaseParser {
  override val FILE_TYPE: String = "461I"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 1, 80, 80, 665, 10)
}
