package com.anthem.bdf.service

import com.anthem.bdf.config.{SplitterConfig, TypeConstants}
import com.anthem.bdf.model.FileNameModel
import com.anthem.bdf.util.TypeUtils
import org.apache.commons.io.FilenameUtils
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger

import scala.util.{Failure, Success, Try}

object FixedWidthParser extends Serializable {
  @transient lazy val LOGGER: Logger = Logger.getLogger(this.getClass.getCanonicalName)
  val punchMap = Map('}' -> "-0", 'J' -> "-1", 'K' -> "-2", 'L' -> "-3", 'M' -> "-4",
    'N' -> "-5", 'O' -> "-6", 'P' -> "-7", 'Q' -> "-8", 'R' -> "-9", '{' -> "+0", 'A' -> "+1",
    'B' -> "+2", 'C' -> "+3", 'D' -> "+4", 'E' -> "+5", 'F' -> "+6", 'G' -> "+7", 'H' -> "+8", 'I' -> "+9")

  val TWNTYETH = 20

  /**
    * for the NCPDP fields, 2 is the number of decimals as default
    *
    * @param num the original string
    * @return modified string
    */
  def convertOverpunch(num: String): String = {
    convertOverpunch(num, 2)
  }

  /**
    * check to ensure that string is not just zeroes
    * we also remove the leading zeroes.
    *
    * @param num string to convert
    * @return converted string with overpunch translated
    */
  def convertOverpunch(num: String, decimal: Int): String = {
    if (num.matches("^0+$")) {
      return "0." + "0" * decimal
    }
    // remove leading zeroes with negative lookahead regex
    var main: String = num.dropRight(1)
    val lastChar = num.takeRight(1)(0)
    val replacement = punchMap.get(lastChar)
    if (replacement.isEmpty) {
      return num
    }

    if (decimal > 1) {
      main = main.replaceFirst("^0+(?!$)", "0")
      replacement.get(0) + main.dropRight(decimal - 1).replaceAll("0([0-9]+)", "$1") + '.' +
        main.takeRight(decimal - 1) + replacement.get(1)
    } else {
      replacement.get(0) + main + replacement.get(1)
    }
  }

  def fileType(line: String): (String, String) = {
    val twentyth = line.charAt(TWNTYETH)
    val lineType = line.substring(14, 17)
    var filenameKey = lineType + twentyth

    var filenameVal = SplitterConfig.get(filenameKey)

    if (twentyth == 'A' && lineType == "465") {
      val init = line.charAt(0)
      val suffix = init match {
        case '8' | '2' =>
          filenameKey = filenameKey + "1"
          "_BSPR"
        case '6' | '3' =>
          filenameKey = filenameKey + "1"
          "_BSIN"
        case '7' | '4' =>
          filenameKey = filenameKey + "3"
          "_BSIS_DNTL"
      }
      filenameVal = filenameVal + suffix
    }
    (filenameKey, filenameVal)
  }

  /**
    * based on the file name create a model which has extension, sor etc and whether we were able to do this mapping
    * successfully or not
    *
    * @param absPath of file
    * @return
    */
  def nameToModel(absPath: String): FileNameModel = {
    var status = true

    val name = FilenameUtils.getName(absPath)
    if (name == null || name.length == 0) {
      LOGGER.info("!!! file NAME is null for:" + absPath)
    }
    //    LOGGER.info(s">> abs path: $absPath name:$name")
    val sor = Try(name.substring(0, name.indexOf('_'))) match {
      case Success(sorResult) => sorResult
      case Failure(throwable) =>
        LOGGER.error("Err: No underscore in filename")
        ""
    }

    val srcNameStartIndex = StringUtils.ordinalIndexOf(name, "_", 3) + 1
    val srcName = name.substring(srcNameStartIndex, srcNameStartIndex + TypeConstants.SOURCE_NAME_LEN)

    val paddedExt = TypeUtils.paddedSorExt(sor)

    val fileTimeStamp = TypeUtils.regexMatch(name, TypeConstants.TIME_STAMP_PATTERN)
    if (sor.length == 0 || fileTimeStamp.length == 0 || sor.length == 0) {
      status = false
    }
    FileNameModel(name, sor, paddedExt, srcName, fileTimeStamp, status)
  }
}
