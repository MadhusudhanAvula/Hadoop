package com.anthem.bdf.parser

object EDI_465A_SLN_BSIN extends BaseParser {
  override val FILE_TYPE: String = "465A2"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 8, 2, 10, 2, 2, 2, 2, 80, 10, 2, 11, 10, 3, 8, 8, 3, 10, 3, 10,
    640, 10)
}
