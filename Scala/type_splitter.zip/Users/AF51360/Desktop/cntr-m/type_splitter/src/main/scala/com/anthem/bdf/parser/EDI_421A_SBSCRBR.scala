package com.anthem.bdf.parser

object EDI_421A_SBSCRBR extends BaseParser {
  override val FILE_TYPE: String = "421A"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 1, 2, 50, 60, 3, 2, 1, 60, 35, 25, 10, 2, 40, 55, 55, 30,
    2, 15, 3, 3, 8, 1, 3, 50, 3, 50, 2, 1, 251, 10)
}
