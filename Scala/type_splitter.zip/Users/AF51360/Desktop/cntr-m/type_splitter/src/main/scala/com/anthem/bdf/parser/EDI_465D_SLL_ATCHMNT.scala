package com.anthem.bdf.parser

object EDI_465D_SLL_ATCHMNT extends BaseParser {
  override val FILE_TYPE: String = "465D"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 2, 2, 50, 770, 10)
}