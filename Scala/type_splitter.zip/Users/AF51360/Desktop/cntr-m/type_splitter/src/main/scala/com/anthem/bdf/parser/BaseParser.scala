package com.anthem.bdf.parser

import com.anthem.bdf.config.TypeConstants
import com.univocity.parsers.fixed.{FixedWidthFields, FixedWidthParser, FixedWidthParserSettings}
import org.apache.log4j.Logger

import scala.util.matching.Regex

/**
  * we define the univocity fixed width parser here. Important note is that, we do not want to modify the original
  * line. Rather after the parsing to field, we will perform all space related modifications.
  * that's why we do not want to ignore spaces at the moment.
  */
trait BaseParser extends Serializable {
  @transient lazy val LOGGER: Logger = Logger.getLogger(this.getClass.getCanonicalName)
  val FILE_TYPE: String
  val PAD_CHAR = '\u0000'
  val getParser: FixedWidthParser = new FixedWidthParser(settings)
  val FIELD_BOUNDARIES: Array[(Int, Int)] = {
    var init = 0
    for (w <- FIELD_LENGTHS()) yield {
      val start = init
      val end = init + w
      init = end
      (start, end)
    }
  }
  val MY_REGEX: Regex = {
    val stringBuilder = new StringBuilder("^")
    FIELD_LENGTHS().foreach {
      l =>
        stringBuilder.append(s"(.{$l})")
    }
    stringBuilder.append("$")
    stringBuilder.toString().r
  }

  def toRegexDelim(line: String): String = {
    val matchOption: Option[Regex.Match] = MY_REGEX.findFirstMatchIn(line)
    matchOption match {
      case Some(pMatch) => pMatch.subgroups.map(f => f.trim).mkString(TypeConstants.OUTPUT_DELIM)
      case None =>
        LOGGER.error(s"ERR: [$FILE_TYPE] Could not parse line:$line ")
        ""
    }
  }

  def FIELD_LENGTHS(): Array[Int]

  def settings: FixedWidthParserSettings = {
    val settings = new FixedWidthParserSettings(new FixedWidthFields(FIELD_LENGTHS(): _*))
    settings.getFormat.setPadding(PAD_CHAR)
    settings.setSkipEmptyLines(false)
    settings.setMaxColumns(FIELD_LENGTHS().length)
    settings.setIgnoreTrailingWhitespaces(false)
    settings.setIgnoreLeadingWhitespaces(false)
    //    settings.getFormat.setLineSeparator("\n")
    settings.setNullValue("")
    settings
  }

  @Deprecated
  def toDelim(line: String): String = {
    val fields = for ((s, e) <- FIELD_BOUNDARIES) yield {
      line.substring(s, e).trim
    }
    fields.mkString(TypeConstants.OUTPUT_DELIM)
  }
}
