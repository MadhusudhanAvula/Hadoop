package com.anthem.bdf.parser

object EDI_422A_PAYER extends BaseParser {
  override val FILE_TYPE: String = "422A"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 1, 60, 2, 40, 55, 55, 30, 2, 15, 3, 3, 3, 50, 3, 50, 3, 50, 3, 50, 3, 50, 292, 10)
}
