package com.anthem.bdf.service

import java.io.IOException

import com.anthem.bdf.config.TypeConstants
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.io.IOUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

import scala.util.Try

/**
  * for interacting with hdfs
  */
class HDFSInteract(spark: SparkSession) {
  @transient lazy val LOGGER: Logger = Logger.getLogger(this.getClass.getCanonicalName)
  val conf: Configuration = spark.sparkContext.hadoopConfiguration
  val fs: FileSystem = FileSystem.get(conf)

  /**
    * merge all directories into single files
    *
    * @param srcDir          output with multiple dirs
    * @param singleOutputDir final dir with single files
    */
  def mergeAll(srcDir: String, singleOutputDir: String): Unit = {
    val srcPath = new Path(srcDir)
    val singleOutputPath = new Path(singleOutputDir)
    LOGGER.info(s">>Deleting singleOutput dir:$singleOutputDir = ${fs.delete(singleOutputPath, true)}")
    fs.mkdirs(singleOutputPath)
    var allStatus = true
    Try {
      fs.listStatus(srcPath).collect {
        case myDir if myDir.isDirectory =>
          val singleFileName = singleOutputDir + Path.SEPARATOR + myDir.getPath.getName + TypeConstants.FINAL_EXT
          val dstPath = new Path(singleFileName)
          LOGGER.info(s">>Collapsing directory:${myDir.getPath.getName} =>  $singleFileName")
          if (!copyMerge(myDir.getPath, dstPath, deleteSource = true)) allStatus = false
      }
    }
    if (allStatus) LOGGER.info(s"\tDeleting intermediate spark job top level dir:${fs.delete(srcPath, true)}")
  }

  /**
    * merge files in a dir with part- prefix in ascending order
    *
    * @param srcDir       Path of source dir
    * @param dstFile      Path of dest single file
    * @param deleteSource y/n delete source dir
    * @return
    */
  def copyMerge(srcDir: Path, dstFile: Path, deleteSource: Boolean): Boolean = {
    if (fs.exists(dstFile))
      throw new IOException(s"Target $dstFile already exists")

    if (fs.getFileStatus(srcDir).isDirectory) {
      val outputFile = fs.create(dstFile)
      var count = 0
      Try {
        fs
          .listStatus(srcDir)
          .sortBy(_.getPath.getName)
          .collect {
            case status if status.isFile && status.getPath.getName.startsWith("part") =>
              //              LOGGER.debug(s"\t\t>>Merging file: ${status.getPath.getName}")
              val inputFile = fs.open(status.getPath)
              Try(IOUtils.copyBytes(inputFile, outputFile, conf, false))
              inputFile.close()
              count = count + 1
          }
      }
      outputFile.close()
      LOGGER.info(s"\t\t>>Merged Directory with # files: $count")
      if (deleteSource) fs.delete(srcDir, true) else true
    }
    else false
  }
}

object HDFSInteract {
  def apply(spark: SparkSession): HDFSInteract = new HDFSInteract(spark)
}