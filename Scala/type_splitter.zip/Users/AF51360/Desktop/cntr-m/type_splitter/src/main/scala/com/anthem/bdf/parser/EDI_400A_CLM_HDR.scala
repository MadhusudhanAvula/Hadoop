package com.anthem.bdf.parser

object EDI_400A_CLM_HDR extends BaseParser {
  override val FILE_TYPE: String = "400A"

  override def FIELD_LENGTHS() =
    Array(14, 3, 3, 1, 3, 15, 1, 15, 15, 35, 8, 2, 1, 1, 2, 1, 3, 2, 40, 1, 60, 35, 25, 40, 1, 19, 20, 20, 9, 455, 10)
}
