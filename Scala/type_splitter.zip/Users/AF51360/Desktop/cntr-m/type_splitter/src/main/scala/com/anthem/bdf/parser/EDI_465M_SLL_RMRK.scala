package com.anthem.bdf.parser

object EDI_465M_SLL_RMRK extends BaseParser {
  override val FILE_TYPE: String = "465M"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 80, 743, 10)
}