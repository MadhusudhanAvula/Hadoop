package com.anthem.bdf.parser

object EDI_464D_COB_OP extends BaseParser {
  override val FILE_TYPE: String = "464D"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 1, 60, 2, 40, 55, 55, 30, 2, 15, 3, 3, 3, 8, 3, 50, 3, 50, 3, 50, 3, 50, 3, 50, 3, 50, 3, 50, 3, 50, 1, 121, 10)
}
