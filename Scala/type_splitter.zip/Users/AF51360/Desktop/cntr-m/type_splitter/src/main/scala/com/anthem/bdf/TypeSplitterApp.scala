package com.anthem.bdf

import com.anthem.bdf.config.{ArgProcessor, TypeConstants}
import com.anthem.bdf.service.{HDFSInteract, PartitionProcessor}
import com.anthem.bdf.util.TypeUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.{col, input_file_name}

/**
  * we wait to extract fields from line until filtering based on file types isnce we cannot have variegated RDD
  * columns in a single RDD. after filtering, we know the specific file type and then we can do the conversion to
  * delimited.
  * get Uniq file types from this RDD and iterate over it.
  */
object TypeSplitterApp extends App with Serializable {
  @transient lazy val LOGGER: Logger = Logger.getLogger(this.getClass.getCanonicalName)
  LOGGER.info(
    s"\n\t\t${TypeConstants.VERSION}\n\n>> Starting ${this.getClass.getSimpleName} w/ Command line args:${args.length}"
  )
  // STEP - 1
  val model = ArgProcessor.get(args)
  LOGGER.info(model)

  // STEP - 2
  val fileRDDALL = model.spark.read.text(model.file).
    select(col("value"), input_file_name).rdd.
    map(
      r => {
        PartitionProcessor.selectValidLine(r)
      }
    ).filter(f => f._4).map(f => (f._1, f._2, f._3, f._5, f._6, f._7))

  // STEP - 3
  val uniqFileTypes: Array[(String, String, String, String)] = fileRDDALL.map {
    case (line, filenameKey, fileType, sorCd, timestamp, sourceName) => (fileType,sorCd,timestamp,sourceName)
  }.filter(f => f._1 != TypeConstants.UNKNOWN_FILE).distinct().collect()
  LOGGER.info(s"\n>> Total # of files to be generated: ${uniqFileTypes.length}\n")

  // remove sorCd, timestamp, sourcename
  val fileRDD = fileRDDALL.map(f=>(f._1,f._2,f._3))
  // STEP - 4
  PartitionProcessor.exec(fileRDD, model, uniqFileTypes, model.trailerRDD)

  LOGGER.info("\t>>Post processing, collapsing multiple files into single")
  val postStart = System.nanoTime()

  // STEP - 5
  HDFSInteract(model.spark).mergeAll(model.output, model.singleOutputDir)
  LOGGER.info(s"\t>>PostProcessing done in:${TypeUtils.elapsedSecs(postStart)} sec.")

  LOGGER.info(s"\n${TypeConstants.HEADER}\n${TypeConstants.SEP}\n Completed " +
    s"${uniqFileTypes.length} " + s"files in " + s"${TypeUtils.elapsedMinutes(model.startTime)} " +
    s"min.\n${TypeConstants.HEADER}\n")
}
