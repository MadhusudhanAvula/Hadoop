package com.anthem.bdf.parser

object EDI_464B_COB_ADJSTMNT extends BaseParser {
  override val FILE_TYPE: String = "464B"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 668, 10)
}
