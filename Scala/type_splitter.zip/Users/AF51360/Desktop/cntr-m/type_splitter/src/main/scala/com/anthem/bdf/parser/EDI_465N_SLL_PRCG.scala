package com.anthem.bdf.parser

object EDI_465N_SLL_PRCG extends BaseParser {
  override val FILE_TYPE: String = "465N"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 10, 10, 25, 9, 30, 10, 8, 2, 10, 2, 11, 2, 2, 2, 691, 10)
}