package com.anthem.bdf.parser

object EDI_461P_VAL_CD extends BaseParser {
  override val FILE_TYPE: String = "461P"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 4, 10, 3, 4, 10, 3, 4, 10, 3, 4, 10, 3, 4, 10, 3, 4, 10, 3, 4, 10, 3, 4, 10, 690, 10)
}
