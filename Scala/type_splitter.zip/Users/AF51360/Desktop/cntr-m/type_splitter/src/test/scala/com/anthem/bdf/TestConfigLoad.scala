package com.anthem.bdf

import com.anthem.bdf.config.{SplitterConfig, TypeConstants}
import com.anthem.bdf.model.FileNameModel
import com.anthem.bdf.service.FixedWidthParser
import com.anthem.bdf.util.TypeUtils
import org.apache.commons.io.FilenameUtils
import org.apache.log4j.{LogManager, Logger}
import org.scalatest.{FlatSpec, Matchers}

import scala.collection.mutable

class TestConfigLoad extends FlatSpec with Matchers {
  @transient lazy val LOGGER: Logger = LogManager.getLogger(this.getClass.getCanonicalName)
  val absPath = "hdfs://nameservicedvts2/user/af55267/WGS_EDI_CLM_PROF_20190415074242.dat"

  "Load config" should "parse to case" in {
    val filenameMap: mutable.Map[String, String] = SplitterConfig.filenameMap
    LOGGER.info(s">> # of properties loaded: ${filenameMap.size}")
    filenameMap foreach { case (k, v) => println(s"$k => $v") }
  }
  "Basename" should "extract filename" in {
    println(s"name : ${FilenameUtils.getName(absPath)}")
    println(FilenameUtils.getBaseName(absPath))
  }
  "Parts" should "extract from filename" in {
    val name = FilenameUtils.getName(absPath)
    val sor = name.substring(0, name.indexOf('_'))
    println(s"sor:$sor")

    // timestamp
    val tsPattern =
      """.*?(\d{14}).*"""
    val timeStampPattern = tsPattern.r
    val fileTimeStamp = name match {
      case timeStampPattern(fileTs) => fileTs
    }
    println(s"fileTime: $fileTimeStamp")
  }
  "Ts exception" should "catch regex error" in {
    var name = FilenameUtils.getName(absPath)
    var fileTimeStamp: String = extractTs(name)
    println(s">>TS: $fileTimeStamp")
    name = "asddddddddddddd"
    fileTimeStamp = extractTs(name)
    println(s">>Err TS: $fileTimeStamp")
  }

  "sor cd and ext" should "extract" in {
    var name = FilenameUtils.getName(absPath)
    val sor = name.substring(0, name.indexOf('_'))
    val sorExt = SplitterConfig.get(sor)
    println(s"SOR:$sor => Ext: $sorExt")
    val ext = TypeUtils.regexMatch(sorExt, TypeConstants.SOR_EXT_PATTERN)
    println(s"EXT Cleansed:$ext")
    val paddedExt = f"$ext%-10s"
    println(s"$paddedExt|")
  }
  "sor cd" should "fetch using model" in {
    val nameModel: FileNameModel = FixedWidthParser.nameToModel(absPath)
    println(nameModel)
  }

  private def extractTs(name: String) = {
    val fileTimeStamp: String = TypeUtils.regexMatch(name, TypeConstants.TIME_STAMP_PATTERN)
    fileTimeStamp
  }


}
