package com.anthem.bdf.parser

object EDI_401A_BILLG_PROV extends BaseParser {
  override val FILE_TYPE: String = "401A"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 1, 60, 35, 25, 10, 2, 40, 55, 55, 30, 2, 15, 3, 3, 3, 50,
    3, 50, 3, 50, 3, 25, 3, 297, 10)
}
