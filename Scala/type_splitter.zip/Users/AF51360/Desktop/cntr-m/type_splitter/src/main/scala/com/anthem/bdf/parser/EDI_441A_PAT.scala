package com.anthem.bdf.parser

object EDI_441A_PAT extends BaseParser {
  override val FILE_TYPE: String = "441A"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 8, 2, 10, 1, 2, 3, 1, 60, 35, 25, 10, 55, 55, 30, 2, 15, 3, 3, 8, 1, 2, 1, 494, 10)
}
