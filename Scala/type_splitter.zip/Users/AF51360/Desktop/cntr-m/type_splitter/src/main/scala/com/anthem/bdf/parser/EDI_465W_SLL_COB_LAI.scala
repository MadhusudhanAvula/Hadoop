package com.anthem.bdf.parser

object EDI_465W_SLL_COB_LAI extends BaseParser {
  override val FILE_TYPE: String = "465W"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 40, 10, 2, 10, 2, 2, 2, 2, 80, 8, 11, 6, 2, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 5, 10, 11, 8, 3, 10, 238, 10)
}