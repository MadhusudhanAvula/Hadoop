package com.anthem.bdf.parser

object EDI_461M_PROC_CD extends BaseParser {
  override val FILE_TYPE: String = "461M"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 14, 8, 3, 14, 8, 3, 14, 8, 3, 14, 8, 3, 14, 8, 3, 14, 8, 3, 14, 8, 3, 14, 8, 3, 14, 8, 3, 14, 8, 576, 10)
}
