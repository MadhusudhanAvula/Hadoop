package com.anthem.bdf.parser

object EDI_465X_SLL_FORMID extends BaseParser {
  override val FILE_TYPE: String = "465X"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 30, 20, 1, 50, 8, 6, 20, 1, 50, 8, 6, 20, 1, 50, 8, 6, 20, 1, 50, 8, 6, 20, 1, 50, 8, 6, 368, 10)
}