package com.anthem.bdf.parser

object EDI_461U_CLL_PRCG extends BaseParser {
  override val FILE_TYPE: String = "461U"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 10, 10, 25, 10, 30, 10, 8, 2, 11, 2, 2, 2, 702, 10)
}
