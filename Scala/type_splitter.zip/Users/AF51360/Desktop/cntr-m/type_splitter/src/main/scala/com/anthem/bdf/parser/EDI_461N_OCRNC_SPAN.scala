package com.anthem.bdf.parser

object EDI_461N_OCRNC_SPAN extends BaseParser {
  override val FILE_TYPE: String = "461N"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 4, 8, 8, 3, 4, 8, 8, 3, 4, 8, 8, 3, 4, 8, 8, 3, 4, 8, 8, 3, 4, 8, 8, 3, 4, 8, 8, 3, 4, 8, 8, 642, 10)
}
