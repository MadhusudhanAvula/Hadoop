package com.anthem.bdf.parser

object EDI_465K_SLL_MSRMNT extends BaseParser {
  override val FILE_TYPE: String = "465K"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 2, 3, 11, 2, 3, 11, 2, 3, 11, 2, 3, 11, 2, 3, 11, 746, 10)
}