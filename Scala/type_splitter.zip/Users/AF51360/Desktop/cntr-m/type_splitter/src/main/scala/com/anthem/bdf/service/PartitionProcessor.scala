package com.anthem.bdf.service

import com.anthem.bdf.TypeSplitterApp.LOGGER
import com.anthem.bdf.config.TypeConstants
import com.anthem.bdf.model.{ArgsModel, FileNameModel}
import com.anthem.bdf.parser.{BaseParser, ParserFactory}
import com.anthem.bdf.util.TypeUtils
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.Row

import scala.util.{Failure, Success, Try}

/**
  * Iterate over all filetypes and match the lines for each.
  * once each type is segregated, save to file.
  */
object PartitionProcessor extends Serializable {
  /**
    * after parsing the line into fields, we still have spaces,
    * let's trim them AFTER parsing, not BEFORE
    *
    * @param fileRDD       RDD of line, filename Key and file type- to be used for filtering
    * @param model         filename model
    * @param uniqFileTypes which file type are we operating upon
    */
  def exec(fileRDD: RDD[(String, String, String)], model: ArgsModel,
           uniqFileTypes: Array[(String, String, String, String)], trailerRDD: RDD[String]): Unit = {
    uniqFileTypes.zipWithIndex.foreach {
      case (v, index) =>
        val outputPath = TypeUtils.getOutputPath(v, model)
        LOGGER.info(s">>[$index]: Checking for type: $v to output: $outputPath")
        val valRDD = fileRDD.filter { case (line, filenameKey, fileType) => fileType == v._1 }.
          mapPartitionsWithIndex {
            (index, iterator) => {
              if (iterator.isEmpty) {
                iterator
              } else {
                val parserKey = v._1
                LOGGER.info(s">>Mapping partition[$index] for key:$parserKey")
                val lineParserOptions: Try[BaseParser] = Try(ParserFactory.getReverse(parserKey))
                lineParserOptions match {
                  case Success(lineParser) =>
                    iterator.map{
                      case (line, _, fileType) =>
                        lineParser.toRegexDelim(line)
                    }
                  case Failure(e) =>
                    LOGGER.error(s"ERR: No valid parser found for $v", e)
                    iterator.map { case (line, _, _) => line }
                }
              }
            }
          }.map(f => f.toString)

        val valRDDTrailer = addTrailer(valRDD, v._1, trailerRDD)
        valRDDTrailer.saveAsTextFile(outputPath)
    }
  }

  def addTrailer(rdd: RDD[String], fileType: String, trailerRDD: RDD[String]): RDD[String] = {
    val count = rdd.count()
    LOGGER.info(s">>Records in $fileType = $count. Adding trailer...")

    rdd.union(trailerRDD.map(f => f + count))
  }

  /**
    * this is mainly for debugging
    * @param fileRDD main compr rdd
    * @param model input command argument
    * @param uniqFileTypes all types present
    */
  def splitWrite(fileRDD: RDD[(String, String, String)], model: ArgsModel,
                 uniqFileTypes: Array[(String, String, String, String)]): Unit = {
    uniqFileTypes.zipWithIndex.foreach {
      case (v, index) =>
        LOGGER.info(s">>splitting/writing file:$v")
        val outputPath = TypeUtils.getOutputPath(v, model)
        val valRDD = fileRDD.filter { case (line, filenameKey, fileType) => fileType == v._1 }.map(f => f._1)
        valRDD.saveAsTextFile(outputPath)
    }
  }

  /**
    * from RDD of Row get the actual line and validate it, trim it and after parsing return a tuple of
    * (valid/sorEnhanced line, filename Key, file type, status success T/F)
    *
    * @param r Row
    * @return tuple (enahanced line, filename key, file type, success/failure, sorcd[WGS], timestamp,
    *         sourcename[PROF/INST/DENT]
    */
  def selectValidLine(r: Row): (String, String, String, Boolean, String, String, String) = {
    if (r.isNullAt(0)) {
      ("", "", "", false, "", "", "")
    } else {
      val lineNonNull = r.getString(0).trim
      val (filenameKey, fileType) = FixedWidthParser.fileType(lineNonNull)
      val filenameModel: FileNameModel = FixedWidthParser.nameToModel(r.getString(1))
      val paddedLine = TypeConstants.JUSTIFIED_LINE_FORMAT.format(lineNonNull)

      if (lineNonNull.length == 0) {
        filenameModel.isSuccess = false
      }
      val enhancedLine = if (filenameModel.isSuccess) {
        paddedLine + filenameModel.sorExtPadded
      } else {
        ""
      }
      (enhancedLine, filenameKey, fileType, filenameModel.isSuccess, filenameModel.sorCd, filenameModel.timestamp,
        filenameModel.sourceName)
    }
  }
}
