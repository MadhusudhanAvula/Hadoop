package com.anthem.bdf.parser

object EDI_402A_PAY_TO_PROV extends BaseParser {
  override val FILE_TYPE: String = "402A"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 1, 55, 55, 30, 2, 15, 3, 3, 659, 10)
}
