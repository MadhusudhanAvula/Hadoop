package com.anthem.bdf.config

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.log4j.{LogManager, Logger}

import scala.collection.mutable

object SplitterConfig extends Serializable {
  @transient lazy val LOGGER: Logger = LogManager.getLogger(this.getClass.getCanonicalName)
  private val ROOTNAME: String = "filenames"
  val rootConf: Config = ConfigFactory.load().getConfig(ROOTNAME)


  import scala.collection.JavaConversions._
  var filenameMap: mutable.Map[String, String] = scala.collection.mutable.Map[String, String]()
  for (entry <- rootConf.entrySet) {
    filenameMap += (entry.getKey -> entry.getValue.unwrapped().toString)
  }

  /**
    * get the read in configuration as key/value pair
    *
    * @return
    */
  def get(key: String): String = {
    filenameMap.getOrElse(key,TypeConstants.UNKNOWN_FILE)
  }

}
