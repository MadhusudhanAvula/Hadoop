package com.anthem.bdf

import com.anthem.bdf.parser.EDI_400A_CLM_HDR
import org.apache.log4j.{LogManager, Logger}
import org.scalatest.{FlatSpec, Matchers}

import scala.util.matching.Regex

class TestRegex extends FlatSpec with Matchers {
  @transient lazy val LOGGER: Logger = LogManager.getLogger(this.getClass.getCanonicalName)
  val absPath = "hdfs://nameservicedvts2/user/af55267/WGS_EDI_CLM_PROF_20190415074242.dat"

  "child Regex" should "prepare pattern" in {
    val patStr = EDI_400A_CLM_HDR.MY_REGEX
    println(patStr)
  }

  "parse regex" should "create arr" in {
    val pattern = EDI_400A_CLM_HDR.MY_REGEX
    val matchOption: Option[Regex.Match] = pattern.findFirstMatchIn(TestConstants.EXT_CLM)
    if (matchOption.isDefined) {
      val delim = matchOption.get.subgroups.map(f => f.trim).mkString("|#")
      println(delim)
    }

  }

  "option" should "filter remove" in {
    var optVal: Option[String] = Some("hi")
   var value: String = optVal.filter(! _.isEmpty).get
    println(s">>Some:$value")
     optVal= None
    if (optVal.isDefined){
      println(s"for None: optVal is defined:${optVal.isDefined}")
    } else {
      println(s"optVal is NOT defined: ${optVal.isDefined}")
    }

     if (optVal.exists(!_.isEmpty)){
       println("Something is there")
     } else {
       println("NADA")
     }

  }


}
