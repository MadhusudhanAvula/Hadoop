package com.anthem.bdf.parser

object EDI_465Z_EMRGNCY_DATA extends BaseParser {
  override val FILE_TYPE: String = "465Z"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 80, 746, 10)
}