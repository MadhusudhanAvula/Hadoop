package com.anthem.bdf.util

import java.util.concurrent.TimeUnit

import com.anthem.bdf.config.{SplitterConfig, TypeConstants}
import com.anthem.bdf.model.ArgsModel
import org.apache.log4j.Logger

import scala.util.matching.Regex
import scala.util.{Failure, Success, Try}

object TypeUtils {
  @transient lazy val LOGGER: Logger = Logger.getLogger(this.getClass.getCanonicalName)
  /**
    * cleansed removing _ and .out .
    * get mapping and pad with spaces
    *
    * @param sor original sor such as WGS
    * @return sor cd 802
    */
  def paddedSorExt(sor: String): String = {
    val sorExt = SplitterConfig.get(sor)
    val ext = TypeUtils.regexMatch(sorExt, TypeConstants.SOR_EXT_PATTERN)
    s"$ext       "
  }

  def regexMatch(name: String, pattern: Regex): String = {
    val matchedResult = Try(name match {
      case pattern(fileTs) => fileTs
    }
    ) match {
      case Success(result) => result
      case Failure(throwable) =>
        LOGGER.error(s">>Err: Could not extract timestamp:${throwable.getMessage}")
        ""
    }
    matchedResult
  }

  /**
    *
    * @param v     (fileType,sorCd,timestamp,sourceName)
    * @param model argsmode
    * @return complete name with dir for output
    */
  def getOutputPath(v: (String, String, String, String), model: ArgsModel): String = {
    val outDirName = v._2 + "_" + v._1 + "_" + v._4 + "_" + v._3
    model.output + "/" + outDirName
  }

  def elapsedMinutes(startNano: Long): Long = {
    TimeUnit.NANOSECONDS.toMinutes(System.nanoTime() - startNano)
  }

  def elapsedSecs(startNano: Long): Long = {
    TimeUnit.NANOSECONDS.toSeconds(System.nanoTime() - startNano)
  }
}
