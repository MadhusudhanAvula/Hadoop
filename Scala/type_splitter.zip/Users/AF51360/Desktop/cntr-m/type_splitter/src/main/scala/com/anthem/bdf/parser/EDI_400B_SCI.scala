package com.anthem.bdf.parser

object EDI_400B_SCI extends BaseParser {
  override val FILE_TYPE: String = "400B"

  override def FIELD_LENGTHS() = Array(14,3,3,1,3,60,2,256,508,10)
}
