package com.anthem.bdf.parser

object EDI_463B_CPCI extends BaseParser {
  override val FILE_TYPE: String = "463B"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 60, 2, 256, 505, 10)
}
