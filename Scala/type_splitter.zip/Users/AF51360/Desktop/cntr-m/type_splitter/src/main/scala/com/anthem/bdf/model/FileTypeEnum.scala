package com.anthem.bdf.model

import com.anthem.bdf.model

object FileTypeEnum extends Enumeration {
  type FileTypeEnum = Value
  val EDI_465A_SLN_BSPR, EDI_465A_SLN_BSIN, EDI_465A_SLN_BSIS_DNTL, OTHER: model.FileTypeEnum.Value = Value

  def withNameOpt(s: String): Option[Value] = values.find(_.toString == s)
}
