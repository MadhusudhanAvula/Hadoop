package com.anthem.bdf.parser

object EDI_461L_DIAG_CD extends BaseParser {
  override val FILE_TYPE: String = "461L"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 14, 1, 3, 6, 547, 10)
}
