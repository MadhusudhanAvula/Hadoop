package com.anthem.bdf.parser

object EDI_461R_TRTMNT_CD extends BaseParser {
  override val FILE_TYPE: String = "461R"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 610, 10)
}
