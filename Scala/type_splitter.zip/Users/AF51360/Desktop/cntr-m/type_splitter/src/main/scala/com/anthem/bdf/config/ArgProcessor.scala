package com.anthem.bdf.config

import com.anthem.bdf.TypeSplitterApp
import com.anthem.bdf.model.ArgsModel
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ArgProcessor extends Serializable {
  def get(args: Array[String]): ArgsModel = {
    if (args.length != 2) {
      throw new IllegalArgumentException("Err: <absolute path to file> <output dir>")
    }
    val spark: SparkSession = SparkSession
      .builder()
      .appName(TypeSplitterApp.getClass.getSimpleName)
      .getOrCreate()

    val trailerRDD: RDD[String] = spark.sparkContext.parallelize(Seq(TypeConstants.TRAILER_ROW))
    val singleOutputDir = if (args(1).endsWith("/"))
      args(1).substring(0, args(1).length - 1) + TypeConstants.SINGLE_DIR_SUFFIX
    else args(1) + TypeConstants.SINGLE_DIR_SUFFIX
    ArgsModel(args(0), args(1), spark, spark.sparkContext.applicationId, System.nanoTime(), trailerRDD, singleOutputDir)
  }
}
