package com.anthem.bdf.parser

object EDI_465E_SLL_TOOTH_INFO extends BaseParser {
  override val FILE_TYPE: String = "465E"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 714, 10)
}