package com.anthem.bdf.parser

object EDI_461Q_CNDTN_CD extends BaseParser {
  override val FILE_TYPE: String = "461Q"

  override def FIELD_LENGTHS() = Array(14, 3, 3, 1, 3, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 658, 10)
}
