package com.anthem.bdf.config

import java.text.SimpleDateFormat
import java.util.Date

import scala.util.matching.Regex

object TypeConstants {
  val versionTimeFMT = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss")
  val VERSION: String = "v:1.1 -> CodeDate:" + versionTimeFMT.format(new Date())
  val UNKNOWN_FILE = "UNKNOWN"
  val TIME_STAMP_PATTERN: Regex =""".*?(\d{14}).*""".r
  val SOR_EXT_PATTERN: Regex ="""_(\d{3}).out""".r
  val SEP: String = "-" * 30
  val OUTPUT_DELIM = "#|"
  val TOTAL_LINE_LEN = 860
  val JUSTIFIED_LINE_FORMAT = "%-850s"
  val EXT_FORMAT = "%-10s"
  val TRAILER_ROW = s"T$OUTPUT_DELIM"
  val FINAL_EXT = ".out"
  val SINGLE_DIR_SUFFIX = "__SINGLE"
  val HEADER: String = "*" * 50
  val SOURCE_NAME_LEN = 4
}
