package com.anthem.bdf.zonemovement.Model.SparkJsonConfig

final case class PropsConfig(
                        size: String,
                        execProps: ExecPropsConfig
                      )
