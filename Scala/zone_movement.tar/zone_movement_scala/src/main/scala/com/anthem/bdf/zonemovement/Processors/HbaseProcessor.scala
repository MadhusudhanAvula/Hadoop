package com.anthem.bdf.zonemovement.Processors

import com.anthem.bdf.zonemovement.Model.JsonConfig.{DedupPropsConfig, MetaConfig}
import com.anthem.bdf.zonemovement.Model.ParseConfig
import org.apache.log4j.Logger

import scala.collection.JavaConverters._

object HbaseProcessor {
  def updateAsyncDQ(dq_message: String, namespace: String, hbaseOp: HbaseOperations, resource_id: String, src_llk_list: List[String], src_load_ing_list: List[String], tgt_llk_list: List[String], tgt_load_ing_list: List[String], src_db: String, src_tbl: String, targ_db: String, targ_tbl : String, src_order_by: String, tgt_order_by: String, deduplicationProperties: DedupPropsConfig, src_count: Long, tgt_count: Long, dq_status_ind: String, logger: Logger) : Unit = {
    val hbase_data_map: scala.collection.mutable.Map[String,String] = scala.collection.mutable.Map[String,String]()
    val hbaseTable = namespace + ":BDF_ASYNC_DQ"
    val dq_async_key = resource_id + "|" + UtilProcessor.currentUnixTime

    hbase_data_map.put("DQ_MESSAGE",dq_message)
    hbase_data_map.put("RESOURCE_ID",resource_id)
    hbase_data_map.put("DQ_STATUS_IND",dq_status_ind)
    hbase_data_map.put("SRC_DB_TBL",s"$src_db.$src_tbl")
    hbase_data_map.put("SRC_LLK_LIST",src_llk_list.mkString(","))
    hbase_data_map.put("SRC_LOAD_INGSTN_ID_LIST",src_load_ing_list.mkString(","))
    hbase_data_map.put("SRC_PK",deduplicationProperties.groupByCols.mkString(","))
    hbase_data_map.put("SRC_ORDR_BY",src_order_by)
    hbase_data_map.put("TGT_DB_TBL",s"$targ_db.$targ_tbl")
    hbase_data_map.put("TGT_LLK_LIST",tgt_llk_list.mkString(","))
    hbase_data_map.put("TGT_LOAD_INGSTN_ID_LIST",tgt_load_ing_list.mkString(","))
    hbase_data_map.put("TGT_ORDR_BY",tgt_order_by)
    hbase_data_map.put("TGT_PK",deduplicationProperties.groupByCols.mkString(","))
    hbase_data_map.put("DQ_STATUS_CREATE_DTM",UtilProcessor.currentTimeString)
    hbase_data_map.put("DEDUP_TYPE",deduplicationProperties.dedupType)
    hbase_data_map.put("DQ_TYPE","SRSZ_BLC")
    hbase_data_map.put("DQ_SRC_COUNT",src_count.toString)
    hbase_data_map.put("DQ_TGT_COUNT",tgt_count.toString)

    hbaseOp.insertUpdateAuditColumns(hbaseTable: String, "dq",hbase_data_map.asJava, dq_async_key, logger)

  }


  def updateAuditSuccess(hbaseTable: String, hbaseOp: HbaseOperations, env: String, log: Logger, LLK: String): Unit={

    val hbase_data_map: scala.collection.mutable.Map[String,String] = scala.collection.mutable.Map[String,String]()

    hbase_data_map.put("PBLSH_IND","Y")
    hbase_data_map.put("UPDT_DTM",UtilProcessor.currentTimeString)
    hbase_data_map.put("LOAD_END_DTM",UtilProcessor.currentTimeString)
    hbaseOp.insertUpdateAuditColumns(hbaseTable: String, "cf",hbase_data_map.asJava, LLK, log)

  }

  def updateConsumeInd(hbaseTable: String, hbaseOp: HbaseOperations, env: String, log: Logger, LLK: String, tgtLLK: String): Unit={
    val hbase_data_map: scala.collection.mutable.Map[String,String] = scala.collection.mutable.Map[String,String]()
    hbase_data_map.put("CNSMD_IND","Y")
    hbase_data_map.put("UPDT_DTM",UtilProcessor.currentTimeString)
    hbase_data_map.put("RLTD_LOAD_LOG_KEY", tgtLLK)
    hbaseOp.insertUpdateAuditColumns(hbaseTable: String, "cf",hbase_data_map.asJava, LLK, log)

  }

  def updateAuditEmptyLlk(hbaseTable: String, hbaseOp: HbaseOperations, env: String, log: Logger, LLK: String): Unit={
    val hbase_data_map: scala.collection.mutable.Map[String,String] = scala.collection.mutable.Map[String,String]()
    hbase_data_map.put("PBLSH_IND","E")
    hbase_data_map.put("UPDT_DTM",UtilProcessor.currentTimeString)
    hbaseOp.insertUpdateAuditColumns(hbaseTable: String, "cf",hbase_data_map.asJava, LLK, log)

  }

  def updateAuditFail(hbaseTable: String, hbaseOp: HbaseOperations, env: String, log: Logger, LLK: String):Unit = {
    val hbase_data_map: scala.collection.mutable.Map[String,String] = scala.collection.mutable.Map[String,String]()
    hbase_data_map.put("PBLSH_IND","F")
    hbase_data_map.put("UPDT_DTM", UtilProcessor.currentTimeString)
    hbase_data_map.put("LOAD_END_DTM", UtilProcessor.currentTimeString)
    hbaseOp.insertUpdateAuditColumns(hbaseTable: String, "cf",hbase_data_map.asJava, LLK, log)

  }

  def insertAuditColumns(hbaseTable: String, hbaseOp: HbaseOperations, logger: Logger, config: ParseConfig, resourceMetadata: MetaConfig): Unit ={

    val hbase_data_map: scala.collection.mutable.Map[String,String] = scala.collection.mutable.Map[String,String]()

    val LLK = config.load_log_key
    val work_flow_nm = config.table_name.trim

    hbase_data_map.put("BDF_SOR_CD", resourceMetadata.jobProperties.sorCd.trim.toUpperCase)
    hbase_data_map.put("ZONE_CD", "SRSZ")
    hbase_data_map.put("SUBJ_AREA_NM", resourceMetadata.jobProperties.subjectAreaName.trim.toUpperCase)
    hbase_data_map.put("WORK_FLOW_NM", work_flow_nm.toUpperCase)
    hbase_data_map.put("LOAD_STRT_DTM", UtilProcessor.currentTimeString)
    hbase_data_map.put("CREAT_DTM", UtilProcessor.currentTimeString)
    hbase_data_map.put("LOAD_INGSTN_ID", config.tgt_load_ingstn_id)
    hbase_data_map.put("PBLSH_IND", "N")
    hbase_data_map.put("CNSMD_IND", "N")
    hbaseOp.insertUpdateAuditColumns(hbaseTable: String, "cf",hbase_data_map.asJava, LLK, logger)

    logger.info("Inserted Hbase audit entries")
  }

}
