package com.anthem.bdf.zonemovement.Processors

import java.util

import org.apache.log4j.Logger
import com.anthem.bdf.zonemovement.Model.JsonConfig.{MetaConfig, OrderPropsConfig}
import com.anthem.bdf.zonemovement.Model.ParseConfig

object MetaProcessor {
  def getPartitionStr(partitionColumns: List[String]): String = {
    if (partitionColumns.nonEmpty) {
      val target_part = "partition (" + partitionColumns.mkString(",") + ")"
      target_part
    } else ""
  }


  def getLatestLLKInfo(resourceMetadata: MetaConfig, llk_load_ing_lists: util.List[util.List[String]], llk_consume_map: util.Map[String, String], logger: Logger): (List[String], List[String]) = {

    /* Convert JAVA util Lists to Scala Lists */
    val llk_list: List[String] = llk_load_ing_lists.get(0).toArray.toList.map(_.asInstanceOf[String])
    val load_ing_list: List[String] = llk_load_ing_lists.get(1).toArray.toList.map(_.asInstanceOf[String])
    val load_end_dtm_list: List[String] = llk_load_ing_lists.get(2).toArray.toList.map(_.asInstanceOf[String])

    /* ZIP LLK, LOAD INGESTION ID, LOAD END DTM lists to Tuple(List(LLK,LOAD_INGSTN_ID,FORMATTED_LOAD_END_DTM))
     * Format LOAD_END_DTM timestamp format from yyyy-MM-dd HH:mm:ss[.SSS] to bigint; Milli secs is optional */
    val all_keys = (llk_list, load_ing_list, load_end_dtm_list.map(x => UtilProcessor.formatTimeStamp(x, logger))).zipped

    //    logger.info("Audit info scanned for Kill & Fill: " + all_keys.toList)

    /* Find the tuple with max LOAD END DTM(3rd element in tuple) using maxBy and extract Latest LLK & corresponding Load ingestion ID */
    val max_llk = all_keys.maxBy(_._3)._1
    val max_load_ing_id = all_keys.maxBy(_._3)._2

    /* Return the LLK/LOAD INGSTN ID lists only if consume indicator is "N"
     * Return empty Lists if the consume flag is "Y" or any other value not equal to "N" */
    if (llk_consume_map.get(max_llk) == "N")
      (List(max_llk), List(max_load_ing_id))
    else {
      logger.info(s"Most recent LLK & load ingestion id is: $max_llk - $max_load_ing_id ; Consume ind is: ${llk_consume_map.get(max_llk)}")
      (List(), List())
    }

  }

  def getTableNameInfo(config: ParseConfig, resourceMetadata: MetaConfig, hadoopData: util.Map[String, String], logger: Logger): scala.collection.mutable.Map[String, String] = {

    val result_map = scala.collection.mutable.Map[String, String]()

    /* Target load props for Kill & fill/ Incremental loads
     * Truncate indicator is Y for kill & fill batch
     * Return a map of properties */
    if (resourceMetadata.targetProperties.targetLoadType.trim.toUpperCase == "K") {
      result_map.put("tbl_nm", resourceMetadata.targetProperties.targetTable.trim)
      result_map.put("truncateInd", "Y")
      result_map.put("killNfill", "K")
    }
    else {
      result_map.put("tbl_nm", resourceMetadata.targetProperties.targetTable.trim.concat("_hist"))
      result_map.put("truncateInd", "N")
      result_map.put("killNfill", "I")
    }

    result_map.put("tbl_nm_temp", resourceMetadata.targetProperties.targetTable.trim + "_temp")
    result_map.put("targ_db", hadoopData.get(resourceMetadata.targetProperties.targetDatabase.trim))
    result_map.put("comp_tbl_nm", resourceMetadata.targetProperties.targetTable.trim)
    result_map

  }

  def query_yaml_string_replace(query: String, yaml_map: java.util.Map[String, String], logger: Logger): String = {
    /* Search for YAML properties in the query string and replace with corresponding elements in the YAML Map
     * Return yaml string replaced query */

    /* Convert java util map as scala map */
    import scala.collection.JavaConverters._
    var query_formatted = query
    val yaml_scala_map = yaml_map.asScala

    yaml_scala_map.keys.foreach(x => query_formatted = query_formatted.replaceAllLiterally(x.toString, yaml_scala_map(x.toString)))

    query_formatted
  }

  def getDedupOrderByProps(orderByCols: List[OrderPropsConfig]): String = {
    /* Concatenate column name/ ordery by direction and return a string */

    orderByCols.map(x => x.columnName.concat(" ").concat(x.orderDirection)).mkString(",")
  }

}
