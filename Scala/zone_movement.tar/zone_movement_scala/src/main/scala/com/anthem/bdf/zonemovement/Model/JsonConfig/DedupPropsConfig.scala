package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class DedupPropsConfig(
                             groupByCols: List[String],
                             orderByCols: List[OrderPropsConfig],
                             dedupType: String
                           )
