package com.anthem.bdf.zonemovement.Processors

import com.anthem.bdf.zonemovement.Model.JsonConfig.SparkConfig
import com.anthem.bdf.zonemovement.Model.ParseConfig
import com.anthem.bdf.zonemovement.Model.SparkJsonConfig.{ExecPropsConfig, SparkJsonConfig, SparkPropsConfig}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

object SparkConfigProcessor {
  def exec(config: ParseConfig, sparkMetaConf: SparkJsonConfig, sparkJobProps: SparkConfig, logger: Logger): SparkSession = {
    /* Filter spark props config with dynamic_allocation flag from source metadata */
    val sparkProps: SparkPropsConfig = sparkMetaConf.spark_props.
      filter(_.dynamic_allocation.trim.toLowerCase == sparkJobProps.dynamicAllocation.toLowerCase).head

    /* Filter spark props config with job size from source metadata and extract executor properties */
    val execProps: ExecPropsConfig = sparkProps.props.filter(_.size.trim.toUpperCase == sparkJobProps.jobSize.toUpperCase).head.execProps

    /* Create Spark session based on dynamic allocation flag */
    if (sparkProps.dynamic_allocation.trim.toLowerCase == "true"){
      @transient val spark = SparkSession.builder.config(
        "spark.driver.memory", "3g").config(
        "spark.driver.cores", "2").config(
        "spark.dynamicAllocation.enabled", sparkProps.dynamic_allocation.trim.toLowerCase).config(
        "spark.executor.memory", execProps.execMem).config(
        "spark.dynamicAllocation.maxExecutors", execProps.maxExec).config(
        "spark.shuffle.compress", "true").config(
        "spark.shuffle.service.enabled", "true").config(
        "spark.dynamicAllocation.initialExecutors", "4").config(
        "spark.dynamicAllocation.minExecutors", "2").config(
        "hive.exec.dynamic.partition", "true").config(
        "hive.exec.dynamic.partition.mode", "nonstrict").config(
        "hive.exec.max.dynamic.partitions", "400").config(
        "hive.exec.max.dynamic.partitions.pernode", "400").config(
        "hive.enforce.bucketing", "true").config(
        "optimize.sort.dynamic.partitioning", "true").config(
        "hive.vectorized.execution.enabled", "true").config(
        "hive.enforce.sorting", "true").enableHiveSupport().getOrCreate()
      spark
    } else
    {
      @transient val spark = SparkSession.builder.config(
        "spark.driver.memory", "3g").config(
        "spark.driver.cores", "2").config(
        "spark.dynamicAllocation.enabled", "false").config(
        "spark.executor.memory", execProps.execMem).config(
        "spark.executor.cores", execProps.execCores).config(
        "spark.executor.instances", execProps.minExec).config(
        "spark.dynamicAllocation.maxExecutors", execProps.maxExec).config(
        "spark.shuffle.compress", "true").config(
        "spark.shuffle.service.enabled", "true").config(
        "spark.dynamicAllocation.initialExecutors", "4").config(
        "spark.dynamicAllocation.minExecutors", "2").config(
        "hive.exec.dynamic.partition", "true").config(
        "hive.exec.dynamic.partition.mode", "nonstrict").config(
        "hive.exec.max.dynamic.partitions", "400").config(
        "hive.exec.max.dynamic.partitions.pernode", "400").config(
        "hive.enforce.bucketing", "true").config(
        "optimize.sort.dynamic.partitioning", "true").config(
        "hive.vectorized.execution.enabled", "true").config(
        "hive.enforce.sorting", "true").enableHiveSupport().getOrCreate()
      spark
    }

  }

  def createSparkSession(resource_id: String): SparkSession ={
    /* create spark session with default properties and stop
     * This is to make sure spark session is created even in the case of no LLKs to process
     * In spark cluster mode, spark session has to be created during some phase of the program */

    @transient val spark = SparkSession.builder.master("yarn")
      .appName("Zone movement Scala Resource: " + resource_id).enableHiveSupport().getOrCreate()
    spark
  }


}
