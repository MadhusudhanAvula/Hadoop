package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class SrcQueryConfig(
                           query: String,
                           aliasName: String
                         )
