package com.anthem.bdf.zonemovement.Processors

import java.util

import com.anthem.bdf.zonemovement.Model.JsonConfig.{DedupPropsConfig, MetaConfig, RefMetaConfig}
import com.anthem.bdf.zonemovement.Model.ParseConfig
import org.apache.log4j.Logger
import org.apache.spark.sql
import org.apache.spark.sql.{Dataset, Row, SparkSession}
import org.apache.spark.sql.functions.monotonically_increasing_id

import scala.sys.process._

object DataProcessor {

  /* Validate in input LLK is empty or not; If empty, Kill & fill batch won't proceed. */
  def checkEmptyLLk(resourceMetadata: MetaConfig, llk_list: List[String], load_ing_list: List[String], hadoopData: util.Map[String, String], spark: SparkSession, logger: Logger): Boolean = {
    val source_db = hadoopData.get(resourceMetadata.jobProperties.srcDatabase.trim)
    val source_tbl = resourceMetadata.jobProperties.srcTable.trim

    logger.info("Check if Latest LLK has data")
    val result_count = spark.sql(s"""select load_ingstn_id from $source_db.$source_tbl where load_ingstn_id = "${load_ing_list.head}" and bdf_load_log_key = "${llk_list.head}" limit 1""").count
    val isEmpty = if (result_count > 0) {
      logger.info("Most recent LLK is not empty")
      false
    } else
      true

    isEmpty
  }

  def createTempTable(spark: SparkSession, targ_db: String, targ_tbl: String, logger: Logger): Unit = {
    spark.sql(s"""drop table if exists $targ_db.${targ_tbl}_temp purge""")
    spark.sql(s"""create table $targ_db.${targ_tbl}_temp like $targ_db.$targ_tbl""")
  }

  def load(truncateInd: String, source_df: Dataset[Row], targ_db: String, targ_tb: String, resourceMetadata: MetaConfig, config: ParseConfig, spark: SparkSession, hadoopData: util.Map[String, String], hbaseYAMLData: util.Map[String, String], hbaseOp: HbaseOperations, logger: Logger): Unit = {

    val columns = spark.sql(s"select * from $targ_db.$targ_tb").columns.toList.mkString(",")

    val target_part_str = MetaProcessor.getPartitionStr(resourceMetadata.targetProperties.partitionColumns)
    logger.info("Target partition columns are: " + target_part_str)

    source_df.createOrReplaceTempView("df")

    logger.info("Target truncate indicator is: " + truncateInd)
    try {
      //      truncate table
      if (truncateInd == "Y") {
        truncate_table(hadoopData, targ_db, targ_tb, spark, resourceMetadata.targetProperties.partitionColumns, logger)
      }

      val load_sql = s"""insert into table $targ_db.$targ_tb $target_part_str select $columns from df"""
      //      logger.info("load sql is: " + load_sql)
      spark.sql(load_sql)
      logger.info(s"Data load is complete for $targ_db.$targ_tb")
      if (resourceMetadata.targetProperties.partitionColumns.nonEmpty) {
        spark.sql(s"msck repair table $targ_db.$targ_tb")
        logger.info("MSCK Repair complete")
      }

    } catch {
      case e: Exception => logger.error(s"Issue with $targ_db.$targ_tb LOAD")
        logger.error(e)
        HbaseProcessor.updateAuditFail(hbaseYAMLData.get("hbase_llk_table"), hbaseOp, config.env, logger, config.load_log_key)
        spark.catalog.clearCache()
        spark.stop()
        System.exit(-1)
    }
  }

  def truncate_table(hadoopData: util.Map[String, String], targ_db: String, targ_tb: String, spark: SparkSession, partitionColumns: List[String], logger: Logger): Unit = {

    val df_description = spark.sql(s"""desc formatted $targ_db.$targ_tb""").withColumn("df_index", monotonically_increasing_id)
    df_description.createOrReplaceTempView("df_description")
    val df_tbl_location = spark.sql(
      "select data_type from df_description where trim(col_name) = 'Location' order by df_index desc limit 1 ").head.get(0)
    val purge_command = s"hdfs dfs -rm -r -f -skipTrash $df_tbl_location/*"
    logger.info(purge_command)
    purge_command !

    if (partitionColumns.nonEmpty) {
      val part_df = spark.sql(s"show partitions  $targ_db.$targ_tb")
      val partition_list = part_df.collect.map(_.mkString).toList
      partition_list.foreach(partition => drop_partitions(spark, targ_db, targ_tb, partition))
    }
  }

  def drop_partitions(spark: SparkSession, targ_db: String, targ_tb: String, partition: String): Unit = {
    val sql_str = s"ALTER TABLE $targ_db.$targ_tb DROP IF EXISTS PARTITION ($partition)"
    print("drop partitons sql is" + sql_str)
    spark.sql(sql_str)
  }

  def get_source_data(llk_list: List[String], load_ing_list: List[String], resourceMetadata: MetaConfig, refMetadata: List[RefMetaConfig], hadoopData: util.Map[String, String], spark: SparkSession, logger: Logger): sql.DataFrame = {

    var df: sql.DataFrame = null

    resourceMetadata.sourceQueries.foreach(x => {

      df = spark.sql(MetaProcessor.query_yaml_string_replace(x.query, hadoopData, logger))
      df.createOrReplaceTempView(x.aliasName.trim.toLowerCase)

      // Build Lookup Map and broadcast
      if (resourceMetadata.lookupProperties.nonEmpty && x.aliasName.trim.toLowerCase == "select_1") {
        val lookupMap = LookupProcessor.buildLookUpMap(resourceMetadata.lookupProperties, resourceMetadata.jobProperties, refMetadata, hadoopData, spark, logger)
        val broadcast_lookup = spark.sparkContext.broadcast(lookupMap)

        //        Perform Lookup
        df = LookupProcessor.exec_lookup(df, broadcast_lookup, resourceMetadata.lookupProperties, refMetadata, spark, logger)

      }

    })

    df
  }

  def cacheRefTables(refMetaConfig: List[RefMetaConfig], refCacheList: List[String], hadoopData: java.util.Map[String, String], spark: SparkSession, logger: Logger): Unit = {
    refCacheList.foreach(alias => {
      val yaml_replaced_query = MetaProcessor.query_yaml_string_replace(refMetaConfig.filter(_.alias.trim.toLowerCase == alias.trim.toLowerCase).head.query, hadoopData, logger)
      spark.sql(yaml_replaced_query).createOrReplaceTempView(alias)
      spark.catalog.cacheTable(alias)
      logger.info("Cached view alias")
    }
    )
  }

  def performDQ(llk_list: List[String], load_ing_list: List[String], config: ParseConfig, hbaseOp: HbaseOperations, resourceMetadata: MetaConfig, spark: SparkSession, targ_db: String, targ_load_prop_map: scala.collection.mutable.Map[String, String], logger: Logger, hadoopData: util.Map[String, String], hbaseYAMLData: util.Map[String, String]): Unit = {
    logger.info("Starting B&C checks")
    val src_llk_list = llk_list
    val src_load_ing_list = load_ing_list
    val tgt_llk_list = List(config.load_log_key)
    val tgt_load_ing_list = List(config.tgt_load_ingstn_id)
    val src_tbl = resourceMetadata.jobProperties.srcTable
    val src_db = hadoopData.get(resourceMetadata.jobProperties.srcDatabase)
    val src_order_by = MetaProcessor.getDedupOrderByProps(resourceMetadata.deduplicationProperties.orderByCols)
    val tgt_order_by = src_order_by
    val src_pk = resourceMetadata.deduplicationProperties.groupByCols.mkString(",")
    val src_pk_list = resourceMetadata.deduplicationProperties.groupByCols
    val tgt_pk = src_pk
    val tgt_pk_list = src_pk_list

    val src_cnt =
      if (resourceMetadata.deduplicationProperties.dedupType.trim.equalsIgnoreCase("row_number")) {
        val df_src = spark.sql(s"select  load_ingstn_id, bdf_load_log_key, $src_pk from $src_db.$src_tbl")
        val df_src_filter = df_src.filter(df_src("load_ingstn_id").isin(src_load_ing_list: _*) && df_src("bdf_load_log_key").isin(src_llk_list: _*))
        df_src_filter.select(src_pk_list.head, src_pk_list.tail: _*).distinct.count
      }
      else {
        val df_src = spark.sql(s"select * from $src_db.$src_tbl")
        val df_src_filter = df_src.filter(df_src("load_ingstn_id").isin(src_load_ing_list: _*) && df_src("bdf_load_log_key").isin(src_llk_list: _*))
        val df_src_dedup = dedup(df_src_filter, resourceMetadata.deduplicationProperties, drop_delete_trans = "N", spark, logger)
        df_src_dedup.count
      }

    logger.info(s"Current batch source count for $src_db.$src_tbl is: $src_cnt")

    val tgt_count =
      if (resourceMetadata.deduplicationProperties.dedupType.trim.equalsIgnoreCase("row_number")) {
        val df_tgt = spark.sql(s"select load_ingstn_id, bdf_load_log_key, $tgt_pk from $targ_db.${targ_load_prop_map("tbl_nm")}")
        val df_tgt_filter = df_tgt.filter(df_tgt("load_ingstn_id").isin(tgt_load_ing_list: _*) && df_tgt("bdf_load_log_key").isin(tgt_llk_list: _*))
        df_tgt_filter.select(tgt_pk_list.head, tgt_pk_list.tail: _*).distinct.count
      }
      else {
        val df_tgt = spark.sql(s"select * from $targ_db.${targ_load_prop_map("tbl_nm")}")
        val df_tgt_filter = df_tgt.filter(df_tgt("load_ingstn_id").isin(tgt_load_ing_list: _*) && df_tgt("bdf_load_log_key").isin(tgt_llk_list: _*))
        val df_tgt_dedup = dedup(df_tgt_filter, resourceMetadata.deduplicationProperties, drop_delete_trans = "N", spark, logger)
        df_tgt_dedup.count
      }

    logger.info(s"Current batch count for $targ_db.${targ_load_prop_map("tbl_nm")} is: $tgt_count")

    if (src_cnt.equals(tgt_count)) {
      HbaseProcessor.updateAsyncDQ("DQ Success", hbaseYAMLData.get("hbase_namespace"), hbaseOp, config.resource_id, src_llk_list, src_load_ing_list, tgt_llk_list, tgt_load_ing_list, src_db, src_tbl, targ_db, targ_load_prop_map("tbl_nm"), src_order_by, tgt_order_by, resourceMetadata.deduplicationProperties, src_cnt, tgt_count, dq_status_ind = "Y", logger)
      logger.info(s"Balance and control checks for $targ_db.${targ_load_prop_map("tbl_nm")} are successful")
    }
    else {
      HbaseProcessor.updateAsyncDQ("DQ Failed", hbaseYAMLData.get("hbase_namespace"), hbaseOp, config.resource_id, src_llk_list, src_load_ing_list, tgt_llk_list, tgt_load_ing_list, src_db, src_tbl, targ_db, targ_load_prop_map("tbl_nm"), src_order_by, tgt_order_by, resourceMetadata.deduplicationProperties, src_cnt, tgt_count, dq_status_ind = "F", logger)
      HbaseProcessor.updateAuditFail(hbaseYAMLData.get("hbase_llk_table"), hbaseOp, config.env, logger, config.load_log_key)
      logger.error("****** DQ Check failed ******")
      logger.error(s"Source $src_db.$src_tbl count is not equal to target $targ_db.${targ_load_prop_map("tbl_nm")} count")
      logger.error(s"Updated BDF_LOAD_LOG & BDF_ASYNC_DQ table with publish F for SRSZ LLK: ${config.load_log_key} ")
      spark.catalog.clearCache()
      spark.stop()
      System.exit(-1)
    }

    //    (src_cnt, tgt_count)
  }

  def dedup(df_filtered: Dataset[Row], deduplicationProperties: DedupPropsConfig, drop_delete_trans: String, spark: SparkSession, logger: Logger): Dataset[Row] = {

    df_filtered.createOrReplaceTempView("df")
    val group_by_str = deduplicationProperties.groupByCols.map(_.trim).mkString(",")
    val order_by_str = MetaProcessor.getDedupOrderByProps(deduplicationProperties.orderByCols)

    if (deduplicationProperties.dedupType.trim == "rank") {
      val sql_str = s"select *, rank() OVER (PARTITION BY " + group_by_str + " ORDER BY " + order_by_str + ") rn from df"
      logger.info("dedup sql " + sql_str)
      val df_dedup = spark.sql(sql_str).filter("rn=1").dropDuplicates.drop("rn")
      if (drop_delete_trans.trim.equalsIgnoreCase("Y"))
        df_dedup.filter("trim(TRNSCTN_CD)!='D'")
      else
        df_dedup
    }
    else {
      val sql_str = s"select *, row_number() OVER (PARTITION BY " + group_by_str + " ORDER BY " + order_by_str + ") rn from df"
      logger.info("dedup sql " + sql_str)
      val df_dedup = spark.sql(sql_str).filter("rn=1").drop("rn")
      if (drop_delete_trans.trim.equalsIgnoreCase("Y"))
        df_dedup.filter("trim(TRNSCTN_CD)!='D'")
      else
        df_dedup
    }

  }

  def performCompDQ(llk_list: List[String], load_ing_list: List[String], config: ParseConfig, hbaseOp: HbaseOperations, resourceMetadata: MetaConfig, spark: SparkSession, targ_db: String, targ_load_prop_map: scala.collection.mutable.Map[String, String], logger: Logger, hadoopData: util.Map[String, String], hbaseYAMLData: util.Map[String, String]): Unit = {
    //update Async DQ
    logger.info("Starting B&C checks for compact")

    val src_llk_list = List(config.load_log_key)
    val src_load_ing_list = List(config.tgt_load_ingstn_id)
    val src_db_comp = targ_db
    val src_tbl_comp = targ_load_prop_map("tbl_nm")
    val src_order_by = MetaProcessor.getDedupOrderByProps(resourceMetadata.deduplicationProperties.orderByCols)
    val src_pk = resourceMetadata.deduplicationProperties.groupByCols.mkString(",")

    val df_comp_src = spark.sql(s"select * from $src_db_comp.$src_tbl_comp")
    val df_comp_src_dedup = dedup(df_comp_src, resourceMetadata.deduplicationProperties, drop_delete_trans = "Y", spark, logger)
    val src_comp_cnt = df_comp_src_dedup.count

    logger.info(s"Current batch source count for $src_db_comp.$src_tbl_comp is: $src_comp_cnt")

    val df_tgt = spark.sql(s"select * from $targ_db.${targ_load_prop_map("comp_tbl_nm")}")
    val tgt_comp_count = df_tgt.count
    logger.info(s"Count for $targ_db.${targ_load_prop_map("comp_tbl_nm")} is: $tgt_comp_count")

    val dq_message = if (config.onlyCompact.trim.equalsIgnoreCase("Y"))
      "Compact Only DQ" else "Compact DQ"

    if (src_comp_cnt.equals(tgt_comp_count)) {
      HbaseProcessor.updateAsyncDQ(s"$dq_message Success", hbaseYAMLData.get("hbase_namespace"), hbaseOp, config.resource_id, src_llk_list, src_load_ing_list, tgt_llk_list = List(""), tgt_load_ing_list = List(""), src_db_comp, src_tbl_comp, targ_db, targ_load_prop_map("comp_tbl_nm"), src_order_by, tgt_order_by = "", resourceMetadata.deduplicationProperties, src_comp_cnt, tgt_comp_count, dq_status_ind = "Y", logger)
      logger.info(s"Balance and control checks for $targ_db.${targ_load_prop_map("comp_tbl_nm")} are successful")
    }
    else {
      HbaseProcessor.updateAsyncDQ(s"$dq_message Failed", hbaseYAMLData.get("hbase_namespace"), hbaseOp, config.resource_id, src_llk_list, src_load_ing_list, tgt_llk_list = List(""), tgt_load_ing_list = List(""), src_db_comp, src_tbl_comp, targ_db, targ_load_prop_map("comp_tbl_nm"), src_order_by, tgt_order_by = "", resourceMetadata.deduplicationProperties, src_comp_cnt, tgt_comp_count, dq_status_ind = "F", logger)
      HbaseProcessor.updateAuditFail(hbaseYAMLData.get("hbase_llk_table"), hbaseOp, config.env, logger, config.load_log_key)
      logger.error("****** DQ Check failed for compact load ******")
      logger.error(s"Source $src_db_comp.$src_tbl_comp count is not equal to target $targ_db.${targ_load_prop_map("comp_tbl_nm")} count")
      logger.error(s"Updated BDF_LOAD_LOG & BDF_ASYNC_DQ table with publish F for SRSZ LLK: ${config.load_log_key} ")
      spark.catalog.clearCache()
      spark.stop()
      System.exit(-1)
    }
  }

}
