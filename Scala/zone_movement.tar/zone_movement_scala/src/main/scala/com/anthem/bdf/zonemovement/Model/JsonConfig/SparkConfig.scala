package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class SparkConfig(
                        dynamicAllocation: String,
                        jobSize: String,
                        deployMode: Option[String]
                      )
