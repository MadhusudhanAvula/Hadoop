package com.anthem.bdf.zonemovement

import java.io.FileInputStream

import com.anthem.bdf.zonemovement.Model.ParseConfig
import com.anthem.bdf.zonemovement.Processors._
import org.apache.log4j.Logger

object ZoneDriver {

  def main(args: Array[String]): Unit = {

    /* Create logger using Log4j */
    val logger = Logger.getLogger("com.anthem.bdf.zonemovement.ZoneDriver")
    logger.info(s"Initializing Zone movement")

    /* Parse and validate input arguments */
    var config: ParseConfig = null.asInstanceOf[ParseConfig]
    try {
      config = ArgProcessor.exec(args)
      /* Log input config arguments */
      LogProcessor.logInputConfArgs(config: ParseConfig, logger: Logger)
    } catch {
      case e: Exception => logger.error("Issue parsing input arguments")
        System.exit(-1)
    }

    /* Read the source metadata and Parse into JSON4S object */
    val srcJson = new FileInputStream("source_metadata.json")
    val resourceMetadata = JsonProcessor.parseSrcMetadata(config.resource_id, srcJson: FileInputStream, logger: Logger)

    /* Validate Resource metadata and exit if there issues */
    JsonProcessor.validate_json_props(resourceMetadata, logger)

    /* Read the Reference metadata and parse into JSON4S object which is used for Lookup/cache */
    val refJson = new FileInputStream("ref_metadata.json")
    val refMetadata = JsonProcessor.parseRefMetadata(refJson: FileInputStream, logger: Logger)

    /* Create instance of HbaseOperations and get available LLKs using getHbaseLlkData method */
    val hbaseOp = new HbaseOperations

    if (config.onlyCompact.trim.equalsIgnoreCase("N")) {

      val audit_info_pair = hbaseOp.getHbaseLlkData(logger, config.env, resourceMetadata, config.loadIngstnIds)

      /* Extract LLK & Load Ingestion Lists */
      var llk_list: List[String] = audit_info_pair.getKey.get(0).toArray.toList.map(_.asInstanceOf[String])
      var load_ing_list: List[String] = audit_info_pair.getKey.get(1).toArray.toList.map(_.asInstanceOf[String])

      /* If the batch is for Kill & Fill and populate only valid recent LLKs & load ingestion ids*/
      if (resourceMetadata.targetProperties.targetLoadType.trim.toUpperCase == "K" && llk_list.nonEmpty) {
        val llk_load_ing_tuple = MetaProcessor.getLatestLLKInfo(resourceMetadata, audit_info_pair.getKey, audit_info_pair.getValue, logger)
        llk_list = llk_load_ing_tuple._1
        load_ing_list = llk_load_ing_tuple._2
      }

      /* Process LLK/Load Ingestion IDs lists using ZoneProcessor exec method
       * If LLK/Load ingestion ID lists are empty, the Zone movement ends as there are no load log keys to process */
      if (llk_list.nonEmpty) {
        logger.info("Unconsumed keys found to move, Starting Zone movement.!")
        logger.info(audit_info_pair)
        ZoneProcessor.exec(config, resourceMetadata, refMetadata, hbaseOp, llk_list, load_ing_list, logger)
        logger.info("Zone movement is complete")
      }
      else {
        val spark = SparkConfigProcessor.createSparkSession(config.resource_id)
        spark.stop()
        logger.info("No Load Log Keys to consume.! Zone movement complete.")
      }

    } else {
      ZoneProcessor.exec(config, resourceMetadata, refMetadata, hbaseOp, llk_list = List(), load_ing_list = List(), logger)
      logger.info("Zone movement compact only job is complete")
    }

  }
}
