package com.anthem.bdf.zonemovement.Processors

import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.util.Calendar

object UtilProcessor {
  val FMT: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
  val DATE_FMT: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
  val From_Fmt: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss[.SSS]")
  val To_Fmt: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")

  def currentTimeString: String = {
    FMT.format(Calendar.getInstance().getTime)
  }

  def currentDayString: String = {
    DATE_FMT.format(Calendar.getInstance().getTime)
  }

  def formatTimeStamp(InpDate: String, logger: org.apache.log4j.Logger): Long = {
    /* Format LOAD_END_DTM timestamp format from yyyy-MM-dd HH:mm:ss[.SSS] to bigint
     * Milli seconds are optional */

    var fmtTimestamp: Long = 0L
    val fmtInpDate = if (InpDate.length > 23) InpDate.substring(0,23) else InpDate

    try {
      fmtTimestamp = FMT.parse(To_Fmt.format(From_Fmt.parse(fmtInpDate))).getTime
    } catch {
      case e: Exception => logger.error("Issue parsing Load end time; Input Load Ingestion date is: " + InpDate)
        System.exit(-1)
    }

    fmtTimestamp

  }

  def currentUnixTime: String = {

    FMT.parse(FMT.format(Calendar.getInstance().getTime)).getTime.toString

  }

}
