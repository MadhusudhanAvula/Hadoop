package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class OrderPropsConfig(
                             columnName: String,
                             orderDirection: String
                           )
