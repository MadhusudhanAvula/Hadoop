package com.anthem.bdf.zonemovement.Processors;

import com.anthem.bdf.zonemovement.Model.JsonConfig.MetaConfig;
import javafx.util.Pair;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.FilterList;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.io.IOException;

import org.apache.log4j.Logger;

public class HbaseOperations {
    private static Configuration hconfig = new Configuration();
    private static Configuration config = HBaseConfiguration.create();

public void insertUpdateAuditColumns(String hbaseTable, String columnFamily, Map<String,String> hbase_data_map, String LLK, Logger logger) throws IOException {
        Connection connection = null;
        Table table = null;
        String hbaseSite = "hbase-site.xml";
        hconfig.addResource(new Path(hbaseSite));
        connection = ConnectionFactory.createConnection(config);
        table = connection.getTable(TableName.valueOf(hbaseTable));
        config.addResource(hconfig);
        try {
            Put putData = new Put(Bytes.toBytes(LLK));
            for(String key: hbase_data_map.keySet()) {
                putData.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes(key), Bytes.toBytes(hbase_data_map.get(key)));
            }
            table.put(putData);
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("IO Issue with Hbase connection for LLK: " + LLK);
        } finally {
            table.close();
            connection.close();

        }
    }

    public Pair<List<List<String>>, Map<String, String>> getHbaseLlkData(Logger logger, String env, MetaConfig metaProps, String LoadIngRange) throws IOException {

        /*Create ParseYaml instance for parsing input YAML file using YAML factory*/
        ParseYaml pyaml = new ParseYaml();
        String hbaseSite = "hbase-site.xml";

        /* Read hbase site for reading config file */
        hconfig.addResource(new Path(hbaseSite));

        /* Parse YAML file and get hbase data into a map */
        Map<String, String> hbaseData = pyaml.getHbaseData(env, "env.yaml");
        String hbaseTable = hbaseData.get("hbase_llk_table");
        config.addResource(hconfig);
        logger.info("hbase table name is : " + hbaseTable);
        String columnFamily = "cf";

        logger.info("zone code: " + metaProps.jobProperties().srcZoneCd());
        logger.info("work flow name is: " + metaProps.jobProperties().srcWorkflowName());
        logger.info("regex required flag: " + metaProps.jobProperties().srcWfNmRegexReq());
        logger.info("subject area :" + metaProps.jobProperties().subjectAreaName());
        logger.info("sor code is:" + metaProps.jobProperties().sorCd());

        List<String> llk_list = new ArrayList<>(); // LLK list
        List<String> load_ing_list = new ArrayList<>(); // Load Ingestion ID list
        List<String> load_end_dtm_list = new ArrayList<>(); // Load End Dtm List
        Map<String, String> consume_flag_map = new HashMap<>(); // Map of <LLK,Consume_flag>
        List<List<String>> result_list = new ArrayList<>(); // List of (llk_list, load_ing_list)

        Connection connection = ConnectionFactory.createConnection(config);
        Table table = connection.getTable(TableName.valueOf(hbaseTable));

        try {

            /* Create HBASE filter instance
             * Get HBASE filter object for the given input metadata properties/load ingestion id(optional parameter) */
            HbaseFilter hf = new HbaseFilter();
            FilterList fl = new FilterList(FilterList.Operator.MUST_PASS_ALL, hf.getFilter(logger, metaProps, LoadIngRange));

            /*Create scan object with hbbase filter and get the below columns in the output*/
            Scan scan = new Scan();
            scan.setFilter(fl);
            scan.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("PBLSH_IND"));
            scan.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("SUBJ_AREA_NM"));
            scan.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("WORK_FLOW_NM"));
            scan.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("CNSMD_IND"));
            scan.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("ZONE_CD"));
            scan.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("LOAD_INGSTN_ID"));
            scan.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("PBLSH_DTM"));
            scan.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("BDF_SOR_CD"));
            scan.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("LOAD_END_DTM"));

            ResultScanner scanner = table.getScanner(scan);

            /*Iterate over the hbase scanner
            and add elements to LLK/Load ingestion ID/Load end dtm Lists and consume flag Map*/
            for (Result result : scanner) {

                llk_list.add(Bytes.toString(result.getRow()));
                load_ing_list.add(Bytes.toString(result.getValue(Bytes.toBytes("cf"), Bytes.toBytes("LOAD_INGSTN_ID"))));
                load_end_dtm_list.add(Bytes.toString(result.getValue(Bytes.toBytes("cf"), Bytes.toBytes("LOAD_END_DTM"))));
                consume_flag_map.put(Bytes.toString(result.getRow()), Bytes.toString(result.getValue(Bytes.toBytes("cf"), Bytes.toBytes("CNSMD_IND"))));
            }

            scanner.close();
            logger.info("Completed Hbase Scan");

        } catch (IOException e) {
            e.printStackTrace();
            logger.error("IO Issue with Hbase connection during Hbase LLK scan");
        } finally {
            table.close();
            connection.close();
        }

        result_list.add(llk_list);
        result_list.add(load_ing_list);
        result_list.add(load_end_dtm_list);

        /*Return a pair of (List<LLK_List, Load_Ingstn_Id_List>, consume_flag_map)*/
        return new Pair<>(result_list, consume_flag_map);
    }

}
