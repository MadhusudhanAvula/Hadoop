package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class ColumnPropsConfig(
                                    keys: List[ColLookupKeysConfig],
                                    target: String,
                                    lookup: String
                                  )
