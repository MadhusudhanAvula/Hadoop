package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class DictKeyFilterConfig (
                                       key_name: String,
                                       values: List[String],
                                       variables: List[String]
                          )
