package com.anthem.bdf.zonemovement.Processors

import com.anthem.bdf.zonemovement.Model.JsonConfig._
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.udf

import scala.collection.mutable

object LookupProcessor {

  def buildLookUpMap(lookupProperties: List[LookupPropsConfig], jobProps: JobPropsConfig, refMetadata: List[RefMetaConfig], hadoopData: java.util.Map[String, String], spark: SparkSession, logger: Logger): scala.collection.mutable.HashMap[String, scala.collection.mutable.HashMap[String, scala.collection.mutable.HashMap[String, String]]] = {
    /* Build Lookup Map to broadcast it across all executors in the cluster */

    /* Map with lookup table name as key and actual map of lookup KV pairs as value */
    val all_lookups = scala.collection.mutable.HashMap[String, scala.collection.mutable.HashMap[String, scala.collection.mutable.HashMap[String, String]]]()

    /* Iterate through list of lookupProperties from the input source metadata
     * lookup represents each element of lookup props list */
    lookupProperties.foreach(

      lookup => {

        val refQuery = refMetadata.filter(_.alias.trim.toUpperCase == lookup.lookupTable.trim.toUpperCase).head.query

        /* Replace YAML parameters with corresponding values based on the environment
         * and create a Dataframe for reference data
         * */
        val refYamlQuery = MetaProcessor.query_yaml_string_replace(refQuery, hadoopData, logger)
        var df = spark.sql(refYamlQuery)

        /* Iterate over the lookup dictionary keys given in the metadata Filter reference dataframe based on the
         * values/variables for each key property(fil) to reduce the size of the lookup map;
         * This filter logic gives significant performance gain; currently only sorCd variable is only supported for
         * which program filters using the SORCD mentioned in the job properties in the metadata JSON;
         * If both value & variable is populated in the key property filter both;
         * else filter on the populated value only
         * If no element is mentioned in the value or variable, return the reference Dataframe as is
         * */
        lookup.dictKeyFilters.foreach(
          fil => {

            (fil.values.nonEmpty, fil.variables.nonEmpty) match {
              case (true, true) => if (fil.variables.head.trim.toUpperCase == "SORCD")
                df = df.filter(df.col(fil.key_name).isin(List(jobProps.sorCd) ::: fil.values: _*))
              else
                df = df.filter(df.col(fil.key_name).isin(fil.values: _*))

              case (true, false) => df = df.filter(df.col(fil.key_name).isin(fil.values: _*))
              case (false, true) => if (fil.variables.head.trim.toUpperCase == "SORCD") df = df.filter(df.col(fil.key_name).isin(List(jobProps.sorCd): _*))
              case (false, false) => ;
            }

          }
        )

        /* lookupMap containing keys & values */
        val lookupMap = scala.collection.mutable.HashMap[String, scala.collection.mutable.HashMap[String, String]]()

        /* Build lookup map from reference tables/views after filtering the required rows
         * Collect the rows from reference Dataframe to driver and Iterate over the rows to construct keys and values
         * Insert the key value pairs into the lookupMap
         * */
        df.collect.foreach(row => {

          /* HASHMAP of lookup column name(in upper case) & corresponding value
           * Iterate over the dictLookup property for the lookup table and insert KV for current row into Hash Map */
          val row_lookup_values = scala.collection.mutable.HashMap[String, String]()
          lookup.dictLookup.foreach(lookup_cols => row_lookup_values.put(lookup_cols.trim.toUpperCase, row.getAs[String](lookup_cols.toString.trim)))

          /* HASHMAP of concatenated keys(in upper case separated using '|') & value as a map of all lookupCol values
           * for the current row; Iterate over the dictLookup property for the row table and insert KV into Hash Map */
          lookupMap.put(lookup.dictKeyFilters.map(key => row.getAs[String](key.key_name.toString.trim.toUpperCase)).mkString("|"),
            row_lookup_values)
        }
        )

        /* Insert the lookupMap for the whole table(for current the lookup table in the lookupProperties loop)
         * as a value into the map and table name as key */
        //fix ascii conversion issues with rdm data
        all_lookups.put(lookup.lookupTable.trim.toUpperCase, lookupMap)

        //        logger.info("Broadcasted Lookup Map - " + lookup.lookupTable.trim.toUpperCase + "; Count is: " + df.count)

      }
    )

    logger.info(s"Total number of lookup tables to be broadcasted is: ${all_lookups.size}")
    all_lookups
  }

  def exec_lookup(df: DataFrame, broadcast_lookup: Broadcast[mutable.HashMap[String, mutable.HashMap[String, mutable.HashMap[String, String]]]], lookupProperties: List[LookupPropsConfig], refMetadata: List[RefMetaConfig], spark: SparkSession, logger: Logger): DataFrame = {


    logger.info("start exec lookup")
    var source_df: DataFrame = df

    /* Iterate through list of lookupProperties from the input source metadata
     * lookup represents each element of lookup props list */
    lookupProperties.foreach(lookup => {
      val lookup_type = lookup.lookupType.trim.toLowerCase // change this to lookupProperties lookupType

      val refLookupColProps = refMetadata.filter(_.alias.trim.toUpperCase == lookup.lookupTable.trim.toUpperCase).head.lookupColProps
      logger.info("refLookupColProps" + refLookupColProps)

      /* regular lookup; Add all lookup key columns at once for lookup table once using zm_key_${colProps.target} col name
       * This ensures that key columns are added before the lookup is performed
       * using df.withColumn("target column name","lookup value from UDF") */
      if (lookup_type != "nested") {
        val col_sql = make_all_col_concat_sql(lookup.columns)
        logger.info("Adding all key columns; SQL is:" + col_sql)
        source_df = spark.sql(col_sql)
      }

      lookup.columns.foreach(col => {

        /* nested lookup; Add lookup key columns one by one for each "col" in the lookup table using zm_key_${colProps.target} col name
         * This ensures that key columns are added before the lookup is performed
         * using df.withColumn("target column name","lookup value from UDF") */
        if (lookup_type == "nested") {
          val key_sql = s"""select *,${make_cur_col_key_concat_str(col)} from select_1 """
          logger.info("Adding key column; SQL is:" + key_sql)
          source_df = spark.sql(key_sql)
        }

        /* Populate default value if it's mentioned in the reference lookup properties */
        val default_lookup_value =
          if (refLookupColProps.nonEmpty) {
            val refColProps = refLookupColProps.find(_.lookupColName == col.lookup)
            if (refColProps.isDefined)
              refColProps.get.defaultValue
            else
              null
          }
          else
            null


        /* Build source with target lookup columns using "col.target" column name &
         * lookup_val_nbd_udf UDF to get the lookup value for the key zm_key_${col.target}
         * This operation happens for all lookup columns df.withColumn("target column name","lookup value from UDF")
         * and the final dataframe will have all required lookup columns added for the current lookup table */
        source_df = source_df.withColumn(col.target, {
          val lookup_map = broadcast_lookup.value(lookup.lookupTable)
          lookup_val_nbd_udf(default_lookup_value, lookup_map, col.lookup)(source_df.col(s"zm_key_${col.target}"))
        })

        /* Drop the key column as lookup is already complete and added the target lookup column to dataframe */
        source_df = source_df.drop(s"zm_key_${col.target}")

        /* Replace the select_1 temp view(alias for SQL1 for addition of each lookup column to the dataframe
         * This is to make sure nested lookup can be performed for the previously added column in the dataframe for the
          * the current lookup table */
        if (lookup_type == "nested")
          source_df.createOrReplaceTempView("select_1")

      })

      /* Replace the select_1 temp view(alias for SQL1) for addition of each lookup column to the dataframe
       * This is to make sure nested lookup can be performed for the previously added column in the dataframe for the
       * the current lookup table */
      logger.info(s"Added key columns for lookup ${lookup.lookupTable}")
      if (lookup_type != "nested")
        source_df.createOrReplaceTempView("select_1")

    })

    source_df
  }


  /* The below function is another way of doing lookup with relative performance difference;
   * Kept it for analysis*/
  //  def lookup_val_udf(keys: List[ColLookupKeysConfig], broadcast_lookup: Broadcast[mutable.HashMap[String, mutable.HashMap[String, mutable.HashMap[String, String]]]], lookupTable: String, lookup_column: String): UserDefinedFunction = udf((key: String) => {
  //
  //    val lookup_res = broadcast_lookup.value(lookupTable).get(key.toString)
  //    if (lookup_res.isDefined)
  //      lookup_res.get(lookup_column)
  //    else
  //      null
  //  })

  /* Perform lookup using scala currying; Based based on the required lookup column, UDF will be returned to
   * df.with column inorder to add lookup output to dataframe */
  def lookup_val_nbd_udf(default_lookup_value: String, ref_lookup_map: mutable.HashMap[String, mutable.HashMap[String, String]], lookup_column: String): UserDefinedFunction = udf((key: String) => {

    val lookup_res = ref_lookup_map.get(key.toString)
    if (lookup_res.isDefined)
      lookup_res.get(lookup_column)
    else
      default_lookup_value
  })

  /* return all the concatenated key columns SQL to add key columns before lookup is performed */
  def make_all_col_concat_sql(columns: List[ColumnPropsConfig]): String = {

    val concat_keys_str = columns.map(col => make_cur_col_key_concat_str(col)).mkString(",")

    s"""select *,$concat_keys_str from select_1"""
  }

  /* return only the given key column concatenated SQL to add key columns before lookup is performed */
  def make_cur_col_key_concat_str(colProps: ColumnPropsConfig): String = {

    val concat_string = colProps.keys.map(k => {
      if (k.eleType == "col") {
        "upper(trim(" + k.value + "))"
      }
      else
        "upper(trim(" + "'" + k.value + "'" + "))"

    }).mkString(",")

    s"""concat_ws('|',$concat_string) as zm_key_${colProps.target}"""

  }

}

