package com.anthem.bdf.zonemovement.Model.SparkJsonConfig

final case class ExecPropsConfig(
                                  maxExec: String,
                                  minExec: String,
                                  execMem: String,
                                  execCores: String
                                )
