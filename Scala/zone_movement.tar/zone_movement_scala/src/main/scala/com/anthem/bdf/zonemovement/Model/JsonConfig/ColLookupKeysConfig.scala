package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class ColLookupKeysConfig (
                                        value: String,
                                        eleType: String
                                        )
