package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class JobPropsConfig(
                           srcTable: String,
                           srcDatabase: String,
                           srcZoneCd: String,
                           srcWorkflowName: String,
                           srcWfNmRegexReq: String,
                           targZoneCd: String,
                           targWorkflowName: String,
                           subjectAreaName: String,
                           sorCd: String
                         )
