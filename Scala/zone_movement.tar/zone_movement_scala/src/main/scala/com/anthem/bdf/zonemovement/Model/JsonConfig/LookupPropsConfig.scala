package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class LookupPropsConfig(
                              lookupTable: String,
                              lookupType: String,
                              dictKeyFilters: List[DictKeyFilterConfig],
                              dictLookup: List[String],
                              columns: List[ColumnPropsConfig]
                            )
