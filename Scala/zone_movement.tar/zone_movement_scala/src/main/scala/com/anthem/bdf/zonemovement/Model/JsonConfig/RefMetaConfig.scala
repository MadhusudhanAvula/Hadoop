package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class RefMetaConfig (
                           alias: String,
                           query: String,
                           keys: List[String],
                           lookUpCols: List[String],
                           lookupColProps: List[RefLookupColsProps]
                         )
