package com.anthem.bdf.zonemovement.Processors

import com.anthem.bdf.zonemovement.Model.ParseConfig
import org.apache.log4j.Logger

object LogProcessor {

  def logInputConfArgs(config: ParseConfig, log: Logger): Unit = {

    log.info(config)

  }
}
