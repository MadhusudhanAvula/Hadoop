package com.anthem.bdf.zonemovement.Processors

import java.io.FileInputStream
import java.util

import org.apache.log4j.Logger
import com.anthem.bdf.zonemovement.Model.ParseConfig
import com.anthem.bdf.zonemovement.Model.JsonConfig.{MetaConfig, RefMetaConfig}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import scala.collection.mutable


object ZoneProcessor {


  def exec(config: ParseConfig, resourceMetadata: MetaConfig, refMetadata: List[RefMetaConfig], hbaseOp: HbaseOperations, llk_list: List[String], load_ing_list: List[String], logger: Logger): Unit = {

    logger.info("llk list: " + llk_list)
    logger.info("load ingestion id list: " + load_ing_list)
    logger.info(s"SRSZ LLK is ${config.load_log_key}")

    /* set spark parameters based on input spark config */
    val spkJson = new FileInputStream("ref_spark_config.json")
    val sparkMetaConf = JsonProcessor.parseSparkConfig(config, spkJson: FileInputStream, logger: Logger)

    /* Create Spark Session based on the size of the input job given in the resource metadata */
    val spark: SparkSession = SparkConfigProcessor.exec(config, sparkMetaConf, resourceMetadata.sparkProperties, logger)


    /* Create parse YAML instance and extract hadoop Data YAML parameters into hbaseYAMLData map */
    val pyaml = new ParseYaml()
    val hadoopData: util.Map[String, String] = pyaml.getHadoopData(config.env, "env.yaml")
    val hbaseYAMLData = pyaml.getHbaseData(config.env, "env.yaml")

    /* Create Initial LLK entries with publish flag as "N" */
    HbaseProcessor.insertAuditColumns(hbaseYAMLData.get("hbase_llk_table"), hbaseOp, logger, config, resourceMetadata)

    /* Create a map of target load properties like table name, overwrite flag etc
     * based on metadata & kill and fill flag */
    val targ_load_prop_map = MetaProcessor.getTableNameInfo(config, resourceMetadata, hadoopData, logger)
    val targ_db = targ_load_prop_map("targ_db")

    /* Cache the temp views given in the refCacheTables list in the source metadata
     * Users have to make sure views used in SQLs have to be present in refCacheTables & ref_metadata.json.v2  */
    if (resourceMetadata.refCacheTables.nonEmpty)
      DataProcessor.cacheRefTables(refMetadata, resourceMetadata.refCacheTables, hadoopData, spark, logger)

    /* Check if most recently published LLK for Kill & Fill has atleast one record; If empty stop the process and update */
    if (targ_load_prop_map("killNfill") == "K" && config.onlyCompact.trim.equalsIgnoreCase("N") && DataProcessor.checkEmptyLLk(resourceMetadata, llk_list, load_ing_list, hadoopData, spark, logger)) {
      logger.error(s"Most recent LLK ${llk_list.head} does't have any data in source table; Updated PUBLSH_IND as 'E';")
      HbaseProcessor.updateAuditEmptyLlk(hbaseYAMLData.get("hbase_llk_table"), hbaseOp, config.env, logger, llk_list.head)
      HbaseProcessor.updateAuditFail(hbaseYAMLData.get("hbase_llk_table"), hbaseOp, config.env, logger, config.load_log_key)
      spark.stop()
      System.exit(1)
    }

    /* Read input source data; Perform Lookup if required; Filter based on input LLK; Dedup and load into History table; Perform DQ */

    if (config.onlyCompact.trim.equalsIgnoreCase("N"))
      execHistory(resourceMetadata, refMetadata, targ_db, config, llk_list, load_ing_list, targ_load_prop_map, hadoopData, hbaseYAMLData, spark, hbaseOp, logger)
    else
      logger.info("***** Skipping History Load.! *****")


    if ((config.compaction == "Y" && targ_load_prop_map("killNfill") != "K") || config.onlyCompact.trim.equalsIgnoreCase("Y"))
      execCompact(resourceMetadata, targ_db, config, llk_list, load_ing_list, targ_load_prop_map, hadoopData, hbaseYAMLData, spark, hbaseOp, logger)

    /* Update LLK with publish success */
    HbaseProcessor.updateAuditSuccess(hbaseYAMLData.get("hbase_llk_table"), hbaseOp, config.env, logger, config.load_log_key)

    spark.catalog.clearCache()
    spark.stop()

  }


  def execHistory(resourceMetadata: MetaConfig, refMetadata: List[RefMetaConfig], targ_db: String, config: ParseConfig, llk_list: List[String], load_ing_list: List[String], targ_load_prop_map: mutable.Map[String, String], hadoopData: util.Map[String, String], hbaseYAMLData: util.Map[String, String], spark: SparkSession, hbaseOp: HbaseOperations, logger: Logger): Unit = {

    /* Replace YAML parameters with corresponding values based on the environment */
    //    val formatted_query = MetaProcessor.query_yaml_string_replace(refMetadata.head.query, hadoopData, logger)


    /* Create Dataframe by processing the SQL queries/add Lookup columns from the input source metadata */
    val df = DataProcessor.get_source_data(llk_list, load_ing_list, resourceMetadata, refMetadata, hadoopData, spark, logger)

    /* Filter dataframe with load ingestion ids & load log keys scanned from Hbase BDF_LOAD_LOG table */
    val df_filtered = df.filter(df("load_ingstn_id").isin(load_ing_list: _*) && df("bdf_load_log_key").isin(llk_list: _*))

    /* Perform DEDUP with given de-duplication properties in source metadata */
    val df_dedup = DataProcessor.dedup(df_filtered, resourceMetadata.deduplicationProperties, drop_delete_trans = "N", spark, logger)

    /* Replace LLK & Load ingstn id columns with input audit entries */
    var df_fmt_llk = df_dedup.drop("bdf_load_log_key").withColumn("bdf_load_log_key", lit(config.load_log_key))
      .drop("load_ingstn_id").withColumn("load_ingstn_id", lit(config.tgt_load_ingstn_id))
    //    val targ_db = targ_load_prop_map("targ_db")

    if (targ_load_prop_map("killNfill") != "K")
    /* Load source data into target history */
      DataProcessor.load(targ_load_prop_map("truncateInd"), df_fmt_llk, targ_db, targ_load_prop_map("tbl_nm"), resourceMetadata, config, spark, hadoopData, hbaseYAMLData, hbaseOp, logger)
    else {

      /* Create temp compact table <database>.<table_name>_temp for shadow load */
      DataProcessor.createTempTable(spark, targ_db, targ_load_prop_map("tbl_nm"), logger)
      logger.info("Starting temp table load for Kill & Fill")
      DataProcessor.load(truncateInd = "N", df_fmt_llk, targ_db, targ_load_prop_map("tbl_nm_temp"), resourceMetadata, config, spark, hadoopData, hbaseYAMLData, hbaseOp, logger)

      /* Load source data into target table for kill & fill */
      logger.info("Starting Kill & Fill Load")
      val df_temp = spark.sql(s""" select * from $targ_db.${targ_load_prop_map("tbl_nm_temp")} """)
      DataProcessor.load(targ_load_prop_map("truncateInd"), df_temp, targ_db, targ_load_prop_map("tbl_nm"), resourceMetadata, config, spark, hadoopData, hbaseYAMLData, hbaseOp, logger)

      spark.sql(s"""drop table if exists $targ_db.${targ_load_prop_map("tbl_nm_temp")} purge""")

    }

    /* Update async DQ after history/kill & fill loads */
    DataProcessor.performDQ(llk_list: List[String], load_ing_list: List[String], config: ParseConfig, hbaseOp, resourceMetadata: MetaConfig, spark: SparkSession, targ_db: String, targ_load_prop_map: scala.collection.mutable.Map[String, String], logger: Logger, hadoopData: util.Map[String, String], hbaseYAMLData: util.Map[String, String])

    /* Update consume indicator for source LLKs */
    llk_list.foreach(source_llk => HbaseProcessor.updateConsumeInd(hbaseYAMLData.get("hbase_llk_table"), hbaseOp, config.env, logger, source_llk, config.load_log_key))

  }

  def execCompact(resourceMetadata: MetaConfig, targ_db: String, config: ParseConfig, llk_list: List[String], load_ing_list: List[String], targ_load_prop_map: mutable.Map[String, String], hadoopData: util.Map[String, String], hbaseYAMLData: util.Map[String, String], spark: SparkSession, hbaseOp: HbaseOperations, logger: Logger): Unit = {

    logger.info("Starting Compact table load")
    val targ_compact_tb = targ_load_prop_map("comp_tbl_nm")
    val targ_compact_tb_temp = targ_load_prop_map("tbl_nm_temp")

    /* Read data from history table to load into compact table */
    val df_hist = spark.sql(s"select * from $targ_db.${targ_load_prop_map("tbl_nm")}")

    /* Dedup the history data before loading into temp compact table */
    val df_hist_dedup = DataProcessor.dedup(df_hist, resourceMetadata.deduplicationProperties, drop_delete_trans = "Y", spark, logger)

    /* Create temp compact table <database>.<table_name>_temp for shadow load */
    DataProcessor.createTempTable(spark, targ_db, targ_compact_tb, logger)

    logger.info("Starting temp table load for compaction")
    DataProcessor.load(truncateInd = "N", df_hist_dedup, targ_db, targ_compact_tb_temp, resourceMetadata, config, spark, hadoopData, hbaseYAMLData, hbaseOp, logger)

    /* Build dataframe from temp table with compacted history data for current run */
    val df_compact_temp = spark.sql(s""" select * from $targ_db.$targ_compact_tb_temp """)

    logger.info("Starting target compact table load")
    DataProcessor.load(truncateInd = "Y", df_compact_temp, targ_db, targ_compact_tb, resourceMetadata, config, spark, hadoopData, hbaseYAMLData, hbaseOp, logger)

    /* Drop temp table for kill & fill */
    spark.sql(s"drop table if exists $targ_db.$targ_compact_tb_temp purge")

    /* Update async DQ after compact loads */
    DataProcessor.performCompDQ(llk_list: List[String], load_ing_list: List[String], config: ParseConfig, hbaseOp: HbaseOperations, resourceMetadata: MetaConfig, spark: SparkSession, targ_db: String, targ_load_prop_map: scala.collection.mutable.Map[String, String], logger: Logger, hadoopData: util.Map[String, String], hbaseYAMLData: util.Map[String, String])


  }

}
