package com.anthem.bdf.zonemovement.Model

final case class ParseConfig(
                              resource_id: String = "",
                              load_log_key: String = "",
                              tgt_load_ingstn_id: String = "",
                              subjArea: String = "",
                              sourceSystem: String = "",
                              table_name: String = "",
                              compaction: String = "Y",
                              loadIngstnIds: String = "",
                              env: String = "",
                              etl_relative_dir: String = "",
                              relVersion: String = "",
                              onlyCompact: String = "N"
                            )