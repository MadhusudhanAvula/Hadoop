package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class RefLookupColsProps(
                                     lookupColName: String,
                                     defaultValue: String
                                   )