package com.anthem.bdf.zonemovement.Model.SparkJsonConfig

final case class SparkPropsConfig(
                             dynamic_allocation: String,
                             props: List[PropsConfig]
                           )
