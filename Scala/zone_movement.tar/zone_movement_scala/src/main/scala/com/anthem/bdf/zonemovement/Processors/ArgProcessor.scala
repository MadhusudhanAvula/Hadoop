package com.anthem.bdf.zonemovement.Processors

import com.anthem.bdf.zonemovement.Model.ParseConfig
import scopt.OptionParser

/**
  * process & validate command line arguments
  */
object ArgProcessor {

  val APP_NAME = "Zone_movement"
  val ENV: Set[String] = Set("dv", "ts", "pr")
  val REL_VRSN: Set[String] = Set("r000", "prd")
  val ONLY_COMPACT: Set[String] = Set("Y", "N")

  val cmdParser: OptionParser[ParseConfig] = new scopt.OptionParser[ParseConfig](APP_NAME) {
    opt[String]('i', "resource_id").required().action((x, c) =>
      c.copy(resource_id = x)).text("Unique id for each source-target in metadata")
      .validate(x =>
        if (!x.isEmpty)
          success
        else
          failure("Resource ID is empty")
      )

    opt[String]('k', "load_log_key").required().action((x, c) =>
      c.copy(load_log_key = x)).text("Source Standard Zone Load Log Key")
      .validate(x =>
        if (!x.isEmpty)
          success
        else
          failure("load_log_key is empty")
      )

    opt[String]('l', "tgt_load_ingstn_id").required().action((x, c) =>
      c.copy(tgt_load_ingstn_id = x)).text("SRSZ Load ingestion id")
      .validate(x =>
        if (!x.isEmpty)
          success
        else
          failure("tgt_load_ingstn_id is empty")
      )

    opt[String]('s', "subjArea").required().action((x, c) =>
      c.copy(subjArea = x)).text("Subject Area")
      .validate(x =>
        if (!x.isEmpty)
          success
        else
          failure("subjArea is empty")
      )

    opt[String]('d', "source_system").required().action((x, c) =>
      c.copy(sourceSystem = x)).text("Source System")
      .validate(x =>
        if (!x.isEmpty)
          success
        else
          failure("source_system is empty")
      )

    opt[String]('t', "table_name").required().action((x, c) =>
      c.copy(table_name = x)).text("Table name")
      .validate(x =>
        if (!x.isEmpty)
          success
        else
          failure("table_name is empty")
      )

    opt[String]('c', "compaction").optional().action((x, c) =>
      c.copy(compaction = x)).text("compact flag")
    opt[String]('r', "loadIngstnIds").optional().action((x, c) =>
      c.copy(loadIngstnIds = x)).text("Load ingestion id range")

    opt[String]('e', "env").required().action((x, c) =>
      c.copy(env = x)).text("env, one of [dv|ts|pr]")
      .validate(x =>
        if (ENV.contains(x.trim.toLowerCase)) success
        else failure(s"Environment must be one of the $ENV")
      )

    opt[String]('m', "etl_relative_dir").required().action((x, c) =>
      c.copy(etl_relative_dir = x)).text("ETL relative directory")

    opt[String]('v', "relVersion").required().action((x, c) =>
      c.copy(relVersion = x)).text("release_version")
      .validate(x =>
        if (REL_VRSN.contains(x.trim.toLowerCase)) success
        else failure(s"Release version must be one of the $REL_VRSN")
      )
    opt[String]('o', "only_compact").optional().action((x, c) =>
      c.copy(onlyCompact = x)).text("Skip history and process compact table only")
      .validate(x =>
        if (ONLY_COMPACT.contains(x.trim.toUpperCase())) success
        else failure(s"Input must be one of the Y|N")
      )

  }

  /* Parse and validate arguments using Scopt Option parser and ParseConfig conf object */
  def exec(args: Array[String]): ParseConfig = {
    cmdParser.parse(args, ParseConfig()) match {
      case Some(config) =>
        config
      case None =>
        throw new IllegalArgumentException("Error parsing command line arguments")
    }
  }

}