package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class MetaConfig(
                       id: String,
                       deduplicationProperties: DedupPropsConfig,
                       jobProperties: JobPropsConfig,
                       lookupProperties: List[LookupPropsConfig],
                       sourceQueries: List[SrcQueryConfig],
                       targetProperties: TargetConfig,
                       sparkProperties: SparkConfig,
                       refCacheTables: List[String]
                     )
