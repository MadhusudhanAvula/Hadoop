package com.anthem.bdf.zonemovement.Processors;

import com.anthem.bdf.zonemovement.Model.JsonConfig.MetaConfig;
import org.apache.hadoop.hbase.filter.SingleColumnValueFilter;
import org.apache.hadoop.hbase.filter.BinaryComparator;
import org.apache.hadoop.hbase.filter.CompareFilter;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.Filter;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;


 public class HbaseFilter {

       public List<Filter> getFilter(Logger logger, MetaConfig metaProps, String LoadIngRange) {
        List<Filter> filters = new ArrayList<>();

        /*Filter ZONE CD*/
        SingleColumnValueFilter colValFilter = new SingleColumnValueFilter(Bytes.toBytes("cf"), Bytes.toBytes("ZONE_CD")
                , CompareFilter.CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(metaProps.jobProperties().srcZoneCd())));
        colValFilter.setFilterIfMissing(true);
        colValFilter.setLatestVersionOnly(true);
        filters.add(colValFilter);

        /* Filter for Work flow name
         * Use BinarComparator if srcWfNmRegexReq in the metadata is "N" else use RegexStringComparator
         */
        if (metaProps.jobProperties().srcWfNmRegexReq().trim().equalsIgnoreCase("N")) {
            SingleColumnValueFilter colValFilter2 = new SingleColumnValueFilter(Bytes.toBytes("cf"), Bytes.toBytes("WORK_FLOW_NM")
                    , CompareFilter.CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(metaProps.jobProperties().srcWorkflowName())));
            colValFilter2.setFilterIfMissing(true);
            colValFilter2.setLatestVersionOnly(true);
            filters.add(colValFilter2);
            logger.info("Regex is false");
        } else {
            SingleColumnValueFilter colValFilter2 = new SingleColumnValueFilter(Bytes.toBytes("cf"), Bytes.toBytes("WORK_FLOW_NM")
                    , CompareFilter.CompareOp.EQUAL, new RegexStringComparator(metaProps.jobProperties().srcWorkflowName()));
            colValFilter2.setFilterIfMissing(true);
            colValFilter2.setLatestVersionOnly(true);
            filters.add(colValFilter2);
        }

        /* Filter for Subject area */
        SingleColumnValueFilter colValFilter3 = new SingleColumnValueFilter(Bytes.toBytes("cf"), Bytes.toBytes("SUBJ_AREA_NM")
                , CompareFilter.CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(metaProps.jobProperties().subjectAreaName())));
        colValFilter3.setFilterIfMissing(true);
        colValFilter3.setLatestVersionOnly(true);
        filters.add(colValFilter3);

        /* Filter for BDF SOR code */
        SingleColumnValueFilter colValFilter4 = new SingleColumnValueFilter(Bytes.toBytes("cf"), Bytes.toBytes("BDF_SOR_CD")
                , CompareFilter.CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(metaProps.jobProperties().sorCd())));
        colValFilter4.setFilterIfMissing(true);
        colValFilter4.setLatestVersionOnly(true);
        filters.add(colValFilter4);

        /*
         * If TargetLoadType is Kill & Fill, Filter valid CONSUME IND which are not empty && null
         * else Filter for consume flag N
         */
        if (metaProps.targetProperties().targetLoadType().trim().equalsIgnoreCase("K")) {
            SingleColumnValueFilter colValFilter5 = new SingleColumnValueFilter(Bytes.toBytes("cf"), Bytes.toBytes("CNSMD_IND")
                    , CompareFilter.CompareOp.NOT_EQUAL, new BinaryComparator(Bytes.toBytes("")));
            colValFilter5.setFilterIfMissing(true);
            colValFilter5.setLatestVersionOnly(true);
            filters.add(colValFilter5);

            SingleColumnValueFilter colValFilter6 = new SingleColumnValueFilter(Bytes.toBytes("cf"), Bytes.toBytes("CNSMD_IND")
                    , CompareFilter.CompareOp.NOT_EQUAL, new BinaryComparator(null));
            colValFilter6.setFilterIfMissing(true);
            colValFilter6.setLatestVersionOnly(true);
            filters.add(colValFilter6);
        }
        else
        {
            SingleColumnValueFilter colValFilter5 = new SingleColumnValueFilter(Bytes.toBytes("cf"), Bytes.toBytes("CNSMD_IND")
                    , CompareFilter.CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes("N")));
            colValFilter5.setFilterIfMissing(true);
            colValFilter5.setLatestVersionOnly(true);
            filters.add(colValFilter5);
        }

        /* Filter with Publish indicator equal to "Y" */
        SingleColumnValueFilter colValFilter7 = new SingleColumnValueFilter(Bytes.toBytes("cf"), Bytes.toBytes("PBLSH_IND")
                , CompareFilter.CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes("Y")));
        colValFilter7.setFilterIfMissing(true);
        colValFilter7.setLatestVersionOnly(true);
        filters.add(colValFilter7);

        /* Filter Load ingestion id is input LoadIngRange argument is not empty */
        if (!(LoadIngRange.trim().equals(""))) {

            logger.info("load ingestion is passed");
            String loadStartDate = LoadIngRange.split("-")[0];
            String loadEndDate = LoadIngRange.split("-")[1];

            logger.info("Load ingestion id range passed is: " + LoadIngRange);
            logger.info("start date is:" + loadStartDate);
            logger.info("end date is:" + loadEndDate);

            SingleColumnValueFilter colValFilter8 = new SingleColumnValueFilter(Bytes.toBytes("cf"), Bytes.toBytes("LOAD_INGSTN_ID")
                    , CompareFilter.CompareOp.GREATER_OR_EQUAL, new BinaryComparator(Bytes.toBytes(loadStartDate)));
            colValFilter8.setFilterIfMissing(true);
            colValFilter8.setLatestVersionOnly(true);
            filters.add(colValFilter8);

            SingleColumnValueFilter colValFilter9 = new SingleColumnValueFilter(Bytes.toBytes("cf"), Bytes.toBytes("LOAD_INGSTN_ID")
                    , CompareFilter.CompareOp.LESS_OR_EQUAL, new BinaryComparator(Bytes.toBytes(loadEndDate)));
            colValFilter9.setFilterIfMissing(true);
            colValFilter9.setLatestVersionOnly(true);
            filters.add(colValFilter9);

        }

        return filters;
    }
}
