package com.anthem.bdf.zonemovement.Model.SparkJsonConfig

final case class SparkJsonConfig(
                                  env: String,
                                  spark_props: List[SparkPropsConfig]
                                )
