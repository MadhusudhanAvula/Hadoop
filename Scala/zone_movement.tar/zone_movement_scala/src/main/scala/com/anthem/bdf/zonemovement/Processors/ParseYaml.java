package com.anthem.bdf.zonemovement.Processors;

import com.anthem.bdf.zonemovement.Model.GlobalConfig;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ParseYaml {

    public Map<String, String> getHadoopData(String env, String yamlLocation) {
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        Map<String, String> output = new HashMap<>();
        try {
            GlobalConfig gc = mapper.readValue(new File(yamlLocation), GlobalConfig.class);
            Map<String, String> hadoop_data_map;
            if (env.equalsIgnoreCase("pr")) {
                hadoop_data_map = gc.getPr().getHadoop_data();

            } else if (env.equalsIgnoreCase("ts")) {
                hadoop_data_map = gc.getTs().getHadoop_data();
            } else {
                hadoop_data_map = gc.getDv().getHadoop_data();
            }

            output = hadoop_data_map;

        } catch (JsonParseException e) {
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Please verify the YAML location and try again!");
            e.printStackTrace();
        }

        return output;
    }

    public Map<String, String> getHbaseData(String env, String yamlLocation) {
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        Map<String, String> output = new HashMap<>();
        try {
            GlobalConfig gc = mapper.readValue(new File(yamlLocation), GlobalConfig.class);
            Map<String, String> hbase_map;
            if (env.equalsIgnoreCase("pr")) {
                hbase_map = gc.getPr().getHbase();

            } else if (env.equalsIgnoreCase("ts")) {
                hbase_map = gc.getTs().getHbase();
            } else {
                hbase_map = gc.getDv().getHbase();
            }

            output = hbase_map;

        } catch (JsonParseException e) {
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Please verify the YAML location and try again!");
            e.printStackTrace();
        }

        return output;
    }

//    public String getAppValue(String key, String env, String category, String source, String yamlLocation) {
//        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
//        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//        String value = null;
//        try {
//            AppConfig ac = mapper.readValue(new File(yamlLocation), AppConfig.class);
//            Map<String, Map<String, Map<String, String>>> app_map = new HashMap<String, Map<String, Map<String, String>>>();
//            if (env.equalsIgnoreCase("pr")) {
//                app_map = ac.getPr();
//            } else if (env.equalsIgnoreCase("ts")) {
//                app_map = ac.getTs();
//            } else {
//                app_map = ac.getDv();
//            }
//
//            value = app_map.get(category).get(source).get(key);
//
//        } catch (JsonParseException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            System.out.println("Please verify the YAML location and try again!");
//            e.printStackTrace();
//        }
//
//        return value;
//    }

}
