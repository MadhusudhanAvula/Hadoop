package com.anthem.bdf.zonemovement.Model.JsonConfig

final case class TargetConfig(
                         partitionColumns: List[String],
                         targetDatabase: String,
                         targetLoadType: String,
                         targetTable: String
                       )
