package com.anthem.bdf.zonemovement.Processors

import java.io.FileInputStream

import com.anthem.bdf.zonemovement.Model.JsonConfig.{MetaConfig, RefMetaConfig}
import com.anthem.bdf.zonemovement.Model.ParseConfig
import com.anthem.bdf.zonemovement.Model.SparkJsonConfig.SparkJsonConfig
import org.apache.log4j.Logger
import org.json4s._
import org.json4s.jackson.JsonMethods._
import org.json4s.DefaultFormats._

object JsonProcessor {


  def parseRefMetadata(refJson: FileInputStream, log: Logger): List[RefMetaConfig] = {
    /* Parse metadata json into list of RefMetaConfigs
     * Refer case class RefMetaConfigs for structure of reference metadata
     * Return the list of metadata */

    implicit val formats: DefaultFormats = DefaultFormats

    val refMetadata = parse(refJson)

    refMetadata.extract[List[RefMetaConfig]]

  }

  def parseSrcMetadata(resource_id: String, srcJson: FileInputStream, log: Logger): MetaConfig = {
    /* Parse metadata json into list of MetaConfigs
     * Refer case class MetaConfig for structure of source metadata
     * Filter Metadata using input resource_id which returns a list with one MetaConfig object
     * Return the head(which is the only element in the list) */

    /* Import default JSON4S used for conversion of json into JSON4S object */
    implicit val formats: DefaultFormats = DefaultFormats
    val sourceMetadata = parse(srcJson)

    val fmtSrcMetadata = sourceMetadata.extract[List[MetaConfig]]
    val resourceMetadata = fmtSrcMetadata.filter(_.id == resource_id)

    resourceMetadata.head

  }

  def parseSparkConfig(config: ParseConfig, sparkJson: FileInputStream, log: Logger): SparkJsonConfig = {
    /* Parse spark metadata json into list of SparkJsonConfig
     * Refer case class SparkJsonConfig for structure of spark metadata
     * Filter Spark Metadata using input environment which returns a list spark config objects
     * Return the head(which is the only element in the list) */

    implicit val formats: DefaultFormats = DefaultFormats

    val sparkMetadata = parse(sparkJson)
    val sparkConfig = sparkMetadata.extract[List[SparkJsonConfig]]

    sparkConfig.filter(_.env.trim.toLowerCase == config.env.trim.toLowerCase).head

  }

  def validate_json_props(resourceMetadata: MetaConfig, logger: Logger): Unit = {
    /* Validate input resource metadata
     * Log error if there is any issue */

    logger.info("Validating Metadata jobProperties/targetProperties/groupByCols/sourceQueries.head.aliasName")

    assert(if (resourceMetadata.jobProperties.srcDatabase != "") true
    else {
      logger.error("Issue with resourceMetadata.jobProperties.srcDatabase in metadata ")
      false
    })

    assert(if (resourceMetadata.jobProperties.srcTable != "") true
    else {
      logger.error("Issue with resourceMetadata.jobProperties.srcTable in metadata ")
      false
    })


    assert(if (resourceMetadata.jobProperties.subjectAreaName != "" && resourceMetadata.jobProperties.subjectAreaName != "---") true
    else {
      logger.error("Issue with resourceMetadata.jobProperties.subjectAreaName in metadata ")
      false
    })

    assert(if (resourceMetadata.jobProperties.sorCd != "" && resourceMetadata.jobProperties.sorCd != "000") true
    else {
      logger.error("Issue with resourceMetadata.jobProperties.sorCd in metadata ")
      false
    })

    assert(if (resourceMetadata.jobProperties.srcWorkflowName != "" && resourceMetadata.jobProperties.srcWorkflowName != "<source workflow>") true
    else {
      logger.error("Issue with resourceMetadata.jobProperties.srcWorkflowName in metadata ")
      false
    })

    assert(if (resourceMetadata.jobProperties.srcZoneCd != "") true
    else {
      logger.error("Issue with resourceMetadata.jobProperties.srcZoneCd in metadata ")
      false
    })

    assert(if (resourceMetadata.targetProperties.targetLoadType != "") true
    else {
      logger.error("Issue with resourceMetadata.targetProperties.targetLoadType in metadata ")
      false
    })

    assert(if (resourceMetadata.targetProperties.targetDatabase != "") true
    else {
      logger.error("Issue with resourceMetadata.targetProperties.targetDatabase in metadata ")
      false
    })

    assert(if (resourceMetadata.targetProperties.targetTable != "") true
    else {
      logger.error("Issue with resourceMetadata.targetProperties.targetTable in metadata ")
      false
    })

    assert(if (resourceMetadata.deduplicationProperties.groupByCols.head != "<group by columns>") true
    else {
      logger.error("Issue with resourceMetadata.deduplicationProperties.groupByCols in metadata ")
      false
    })

    assert(if (resourceMetadata.sourceQueries.head.aliasName == "select_1") true
    else {
      logger.error("Issue with Metadata; sourceQueries.head.aliasName != select_1 ")
      false
    })


  }

}
