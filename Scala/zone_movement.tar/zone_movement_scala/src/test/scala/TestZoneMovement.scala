import com.anthem.bdf.zonemovement.Processors._
import java.io.FileInputStream

import org.apache.log4j.Logger
import org.scalatest.FunSpec

class TestZoneMovement extends FunSpec {

  describe("Zone movement") {

    val logger = Logger.getLogger("TestZoneMovement")
    logger.info(s"Initializing Zone movement")

    val srcJson = new FileInputStream("src/main/resources/unit_test_resources/test_source_metadata.json")
    val srcJson_w_regex = new FileInputStream("src/main/resources/unit_test_resources/test_source_metadata.json")
    val srcJson_invalid_metadata = new FileInputStream("src/main/resources/unit_test_resources/test_source_metadata.json")

    val refJson = new FileInputStream("src/main/resources/unit_test_resources/test_ref_metadata.json")
    //
    val refMetadata = JsonProcessor.parseRefMetadata(refJson: FileInputStream, logger: Logger)
    val resourceMetadata = JsonProcessor.parseSrcMetadata("2", srcJson: FileInputStream, logger: Logger)
    val resourceMetadata_other = JsonProcessor.parseSrcMetadata("3", srcJson_w_regex: FileInputStream, logger: Logger)
    val resourceMetadata_invalid = JsonProcessor.parseSrcMetadata("1", srcJson_invalid_metadata: FileInputStream, logger: Logger)

    val config = ArgProcessor.exec(TestDataRef.args)
    val config_optional = ArgProcessor.exec(TestDataRef.args_optional)

    // Hbase YAML Parsing
    val pyaml = new ParseYaml()
    val hadoopData_dv = pyaml.getHadoopData(config.env, "src/main/resources/unit_test_resources/test_env.yaml")
    val hadoopData_ts = pyaml.getHadoopData("ts", "src/main/resources/unit_test_resources/test_env.yaml")
    val hadoopData_pr = pyaml.getHadoopData("pr", "src/main/resources/unit_test_resources/test_env.yaml")
    val hbase_dv = pyaml.getHbaseData("dv", "src/main/resources/unit_test_resources/test_env.yaml")
    val hbase_ts = pyaml.getHbaseData("ts", "src/main/resources/unit_test_resources/test_env.yaml")
    val hbase_pr = pyaml.getHbaseData("pr", "src/main/resources/unit_test_resources/test_env.yaml")

    //        yaml replace
    val formatted_ref_query = MetaProcessor.query_yaml_string_replace(refMetadata.head.query, hadoopData_pr, logger)
    val formatted_source_query = MetaProcessor.query_yaml_string_replace(resourceMetadata.sourceQueries.head.query, hadoopData_dv, logger)

    //    Hbase filters
    val hf = new HbaseFilter()

    val hf_wo_regex_wo_li = hf.getFilter(logger, resourceMetadata, "")
    val hf_wo_regex_w_li = hf.getFilter(logger, resourceMetadata, "20180101-20181231")
    val hf_w_regex_wo_li = hf.getFilter(logger, resourceMetadata_other, "")
    val hf_w_regex_w_li = hf.getFilter(logger, resourceMetadata_other, "20180101-20181231")

    val llk_load_ing_tuple = MetaProcessor.getLatestLLKInfo(resourceMetadata, TestDataRef.llk_load_ing_lists, TestDataRef.consume_flag_map_java, logger)


    describe("Validate Input arguments") {
      it("Should validate all required arguments and parse into Model ") {

        assert(config.env == TestDataRef.input_env)
        assert(config.etl_relative_dir == TestDataRef.input_etl_root_dir)
        assert(config.load_log_key == TestDataRef.input_llk)
        assert(config.relVersion == TestDataRef.input_release)
        assert(config.resource_id == TestDataRef.input_id)
        assert(config.subjArea == TestDataRef.input_subarea)
        assert(config.sourceSystem == TestDataRef.input_ss)
        assert(config.tgt_load_ingstn_id == TestDataRef.input_load_ing_id)
        assert(config.compaction == TestDataRef.input_compaction_true)
        assert(config.loadIngstnIds == "")

      }

      it("Should validate all arguments including optional parameters and parse into Model ") {

        assert(config_optional.env == TestDataRef.input_env)
        assert(config_optional.etl_relative_dir == TestDataRef.input_etl_root_dir)
        assert(config_optional.load_log_key == TestDataRef.input_llk)
        assert(config_optional.relVersion == TestDataRef.input_release)
        assert(config_optional.resource_id == TestDataRef.input_id)
        assert(config_optional.subjArea == TestDataRef.input_subarea)
        assert(config_optional.sourceSystem == TestDataRef.input_ss)
        assert(config_optional.tgt_load_ingstn_id == TestDataRef.input_load_ing_id)
        assert(config_optional.compaction == TestDataRef.input_compaction_false)
        assert(config_optional.loadIngstnIds == TestDataRef.input_loadIngstnIds)
        assert(config_optional.onlyCompact == TestDataRef.input_compaction_false)

      }
    }

    describe("Parse & validate Source Metadata Json") {

      it("Should have valid Id") {

        assert(resourceMetadata.id == "2")

      }

      it("Should have valid Job Props") {

        assert(resourceMetadata.jobProperties.sorCd == TestDataRef.sorCd)
        assert(resourceMetadata.jobProperties.srcDatabase == TestDataRef.srcDatabase)
        assert(resourceMetadata.jobProperties.srcTable == TestDataRef.srcTable)
        assert(resourceMetadata.jobProperties.srcWfNmRegexReq == TestDataRef.srcWfNmRegexReq)
        assert(resourceMetadata.jobProperties.srcWorkflowName == TestDataRef.srcWorkflowName)
        assert(resourceMetadata.jobProperties.srcZoneCd == TestDataRef.srcZoneCd)
        assert(resourceMetadata.jobProperties.subjectAreaName == TestDataRef.subjectAreaName)
        assert(resourceMetadata.jobProperties.targWorkflowName == TestDataRef.targWorkflowName)
        assert(resourceMetadata.jobProperties.targZoneCd == TestDataRef.targZoneCd)

      }

      it("Should have valid Source Props") {

        assert(resourceMetadata.sourceQueries.head.query == TestDataRef.source_sql)
        assert(resourceMetadata.sourceQueries.head.aliasName == TestDataRef.source_aliasName)

      }

      it("Should have valid Target Props") {

        assert(resourceMetadata.targetProperties.targetTable == TestDataRef.targetTable)
        assert(resourceMetadata.targetProperties.targetLoadType == TestDataRef.targetLoadType)
        assert(resourceMetadata.targetProperties.partitionColumns == TestDataRef.partitionColumns)
        assert(resourceMetadata.targetProperties.partitionColumns.length == 1)
        assert(resourceMetadata.targetProperties.targetDatabase == TestDataRef.targetDatabase)

      }

      it("Should have valid Dedup Props") {

        assert(resourceMetadata.deduplicationProperties.dedupType == TestDataRef.dedupType)
        assert(resourceMetadata.deduplicationProperties.orderByCols.head.orderDirection == TestDataRef.orderByCols_orderDirection)
        assert(resourceMetadata.deduplicationProperties.orderByCols.head.columnName == TestDataRef.orderByCols_columnName)
        assert(resourceMetadata.deduplicationProperties.groupByCols == TestDataRef.groupByCols)

      }

      it("Should have valid refCacheTables") {

        assert(resourceMetadata.refCacheTables == TestDataRef.refCacheTables)

      }

      it("Should have valid Lookup Props") {

        assert(resourceMetadata.lookupProperties.length == 1)
        assert(resourceMetadata.lookupProperties.head.dictKeyFilters.length == 3)
        assert(resourceMetadata.lookupProperties.head.columns.length == 1)
        assert(resourceMetadata.lookupProperties.head.columns.head.keys.length == 3)

        assert(resourceMetadata.lookupProperties.head.lookupTable == TestDataRef.lookupTable)
        assert(resourceMetadata.lookupProperties.head.dictLookup == TestDataRef.dictLookup)
        assert(resourceMetadata.lookupProperties.head.lookupType == TestDataRef.lookupType)

        assert(resourceMetadata.lookupProperties.head.dictKeyFilters.head.values == TestDataRef.dictKeyFilters_values)
        assert(resourceMetadata.lookupProperties.head.dictKeyFilters.head.key_name == TestDataRef.dictKeyFilters_key_name)
        assert(resourceMetadata.lookupProperties.head.dictKeyFilters.head.variables == TestDataRef.dictKeyFilters_variables)

        assert(resourceMetadata.lookupProperties.head.columns.head.lookup == TestDataRef.columns_lookup)
        assert(resourceMetadata.lookupProperties.head.columns.head.target == TestDataRef.columns_target)
        assert(resourceMetadata.lookupProperties.head.columns.head.keys.head.value == TestDataRef.columns_keys_value)
        assert(resourceMetadata.lookupProperties.head.columns.head.keys.head.eleType == TestDataRef.columns_keys_eleType)
        assert(resourceMetadata.lookupProperties.head.columns.head.keys.head.value == TestDataRef.columns_keys_value)
      }

      it("Should have valid Spark Props") {

        assert(TestDataRef.dynamicAllocation.contains(resourceMetadata.sparkProperties.dynamicAllocation.trim.toLowerCase))
        assert(TestDataRef.jobSize.contains(resourceMetadata.sparkProperties.jobSize.trim.toUpperCase))

      }

      it("Should validate input JSON metadata") {

        JsonProcessor.validate_json_props(resourceMetadata, logger)
        JsonProcessor.validate_json_props(resourceMetadata_other, logger)

        val condition = true

        try {
          JsonProcessor.validate_json_props(resourceMetadata_invalid, logger)
        } catch {
          case exception: java.lang.AssertionError => assert(condition)
        }

      }

    }

    describe("Validate Reference Metadata") {

      it("Should have valid SQL & alias entries") {

        assert(refMetadata.length == 5)
        assert(refMetadata.head.alias == TestDataRef.ref_alias)
        assert(refMetadata.head.keys == TestDataRef.ref_keys)
        assert(refMetadata.head.lookUpCols == TestDataRef.ref_lookUpCols)
        assert(refMetadata.head.query == TestDataRef.ref_query)

      }
    }

    describe("Yaml parsing") {

      it("Should populate valid YAML values based on each environment") {

        assert(hadoopData_dv.get("rawz_nogbd_warehouse_db") == TestDataRef.whdb_dv)
        assert(hadoopData_ts.get("rawz_nogbd_warehouse_db") == TestDataRef.whdb_ts)
        assert(hadoopData_pr.get("rawz_nogbd_warehouse_db") == TestDataRef.whdb_pr)

      }

      it("Should replace YAML keys in source queries properly") {

        assert(formatted_source_query == TestDataRef.yaml_source_query)

      }

      it("Should replace YAML keys in reference queries properly") {

        assert(formatted_ref_query == TestDataRef.yaml_ref_query)

      }

      it("Should return valid Hbase YAML values") {

        assert(hbase_dv.get("hbase_llk_table") == TestDataRef.hbase_table_dv)
        assert(hbase_ts.get("hbase_llk_table") == TestDataRef.hbase_table_ts)
        assert(hbase_pr.get("hbase_llk_table") == TestDataRef.hbase_table_pr)

      }

    }

    describe("Scan Hbase Filter validation") {

      it("Should have valid filters to scan hbase - Without regex & Load ingstn ids") {

        assert(hf_wo_regex_wo_li.size() == 6)
        assert(hf_wo_regex_wo_li.toString == TestDataRef.hbaseFilter_wo_regex)

      }

      it("Should have valid filters to scan hbase - Without regex & with Load Ingstn Ids") {

        assert(hf_wo_regex_w_li.size() == 8)
        assert(hf_wo_regex_w_li.toString == TestDataRef.hbaseFilter_wo_regex_w_lingids)

      }

      it("Should have valid filters to scan hbase - With regex & Load ingstn ids") {

        assert(hf_w_regex_wo_li.size() == 7)
        assert(hf_w_regex_wo_li.toString == TestDataRef.hbaseFilter_w_regex)

      }

      it("Should have valid filters to scan hbase - With regex & with Load Ingstn Ids") {

        assert(hf_w_regex_w_li.size() == 9)
        assert(hf_w_regex_w_li.toString == TestDataRef.hbaseFilter_w_regex_w_lingids)

      }
    }

    describe("Metadata processing ") {

      it("Should populate recently published LLK from Hbase published-unconsumed LLKs for Kill & Fill") {

        assert(llk_load_ing_tuple == TestDataRef.recent_llk)

      }

      it("Should populate valid Target table information for incremental loads") {

        assert(MetaProcessor.getTableNameInfo(config, resourceMetadata, hadoopData_dv, logger) == TestDataRef.targ_tbl_map_i)

      }

      it("Should populate valid Target table information for kill & fill loads") {

        assert(MetaProcessor.getTableNameInfo(config, resourceMetadata_other, hadoopData_pr, logger) == TestDataRef.targ_tbl_map_k)

      }

    }


  }

}