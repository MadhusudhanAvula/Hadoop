import scala.collection.JavaConverters._
import java.util

object TestDataRef {


  //  Input Arguments
  val args = Array("--resource_id", "2", "--load_log_key", "test_llk", "--tgt_load_ingstn_id", "20190214", "--subjArea", "CLM", "--source_system", "WGS", "--table_name", "CLM_WGS_TEST_TABLE", "--env", "dv", "--etl_relative_dir", "etl_relative_dir", "--relVersion", "r000")
  val args_optional = Array("--resource_id", "2", "--load_log_key", "test_llk", "--tgt_load_ingstn_id", "20190214", "--subjArea", "CLM", "--source_system", "WGS", "--table_name", "CLM_WGS_TEST_TABLE", "--env", "dv", "--etl_relative_dir", "etl_relative_dir", "--relVersion", "r000", "--loadIngstnIds", "20180101-20181231", "--compaction", "N", "--only_compact", "N")

  val input_id = "2"
  val input_llk = "test_llk"
  val input_subarea = "CLM"
  val input_ss = "WGS"
  val input_tb = "CLM_WGS_TEST_TABLE"
  val input_env = "dv"
  val input_etl_root_dir = "etl_relative_dir"
  val input_release = "r000"
  val input_load_ing_id = "20190214"
  val input_compaction_false = "N"
  val input_compaction_true = "Y"
  val input_loadIngstnIds = "20180101-20181231"

  //  Job props - source parameter
  val source_sql = "SELECT  SRCTBL.*, COALESCE(LU1.BDF_SCRTY_LVL_CD, 'UNK') AS BDF_SCRTY_LVL_CD FROM rawz_nogbd_warehouse_db.CLM_WGS_GNCADJP SRCTBL   LEFT JOIN srsz_nogbd_warehouse_db.CLM_WGS_CLMP LU1     ON trim(SRCTBL.PK_HASH_KEY) = trim(LU1.PK_HASH_KEY)  "
  val source_aliasName = "select_1"

  //  Reference conig props
  val ref_alias = "RFRNC_RDM_BASE_CD_VAL_TRNSLTN_MSTR"
  val ref_query = "select DISTINCT RDM_MSTR.SRC_SOR_CD,RDM_MSTR.CLMN_PHYSCL_NM,RDM_MSTR.CD_VAL_TXT,RDM_MSTR.CD_VAL_NM,RDM_MSTR.TRGT_CD_VAL_TXT,RDM_MSTR.TRGT_CD_VAL_NM FROM srsz_nogbd_warehouse_db.RFRNC_RDM_BASE_CD_VAL_TRNSLTN_MSTR  RDM_MSTR "
  val ref_keys = List("SRC_SOR_CD", "CLMN_PHYSCL_NM", "CD_VAL_TXT")
  val ref_lookUpCols = List("CD_VAL_NM", "TRGT_CD_VAL_TXT", "TRGT_CD_VAL_NM")

  //  Job props - audit parameters to query BDF_LOAD_LOG HBASE table
  val sorCd = "808"
  val srcDatabase = "rawz_nogbd_warehouse_db"
  val srcTable = "CLM_WGS_GNCADJP"
  val srcWfNmRegexReq = "N"
  val srcWorkflowName = "BDF_REFRESH_RAWZ_DMLINSERT_INCR_0001-gncadjp"
  val srcZoneCd = "RAWZ"
  val subjectAreaName = "CLM"
  val targWorkflowName = "CLM_WGS_CLM_WGS_ADJP"
  val targZoneCd = "SRSZ"

  //  Target Properties
  val targetDatabase = "srsz_nogbd_warehouse_db"
  val targetTable = "clm_wgs_adjp"
  val targetLoadType = "I"
  val partitionColumns = List("load_ingstn_id")

  //  Deduplication properties
  val groupByCols = List("pk_hash_key")
  val orderByCols_columnName = "src_load_dtm"
  val orderByCols_orderDirection = "desc"
  val dedupType = "row_number"

  //  Reference Cache Tables
  val refCacheTables = List("RFRNC_RDM_BASE_CD_VAL_TRNSLTN_MSTR")


  //  Lookup Properties
  val lookupTable = "RFRNC_RDM_BASE_CD_VAL_TRNSLTN_MSTR"
  val lookupType = "regular"
  val dictKeyFilters_key_name = "SRC_SOR_CD"
  val dictKeyFilters_values = List("801")
  val dictKeyFilters_variables = List("SOR_CD")
  val dictLookup = List("CD_VAL_NM")
  val columns_keys_value = "801"
  val columns_keys_eleType = "lit"
  val columns_target = "BDF_SOR_DESC"
  val columns_lookup = "CD_VAL_NM"

  //  Spark job props
  val dynamicAllocation = List("true", "false")
  val jobSize = List("S", "M", "L", "XL")


  //  YAML
  val whdb_dv = "dv_bdfrawzph_nogbd_r000_wh"
  val whdb_ts = "ts_bdfrawzph_gbd_r000_wh"
  val whdb_pr = "pr_bdfrawzph_gbd_prd_wh"
  val yaml_source_query = "SELECT  SRCTBL.*, COALESCE(LU1.BDF_SCRTY_LVL_CD, 'UNK') AS BDF_SCRTY_LVL_CD FROM dv_bdfrawzph_nogbd_r000_wh.CLM_WGS_GNCADJP SRCTBL   LEFT JOIN dv_bdfsrszph_nogbd_r000_wh.CLM_WGS_CLMP LU1     ON trim(SRCTBL.PK_HASH_KEY) = trim(LU1.PK_HASH_KEY)  "
  val yaml_ref_query = "select DISTINCT RDM_MSTR.SRC_SOR_CD,RDM_MSTR.CLMN_PHYSCL_NM,RDM_MSTR.CD_VAL_TXT,RDM_MSTR.CD_VAL_NM,RDM_MSTR.TRGT_CD_VAL_TXT,RDM_MSTR.TRGT_CD_VAL_NM FROM pr_bdfsrszph_gbd_prd_wh.RFRNC_RDM_BASE_CD_VAL_TRNSLTN_MSTR  RDM_MSTR "

  //  Hbase props
  val hbaseFilter_wo_regex = "[SingleColumnValueFilter (cf, ZONE_CD, EQUAL, RAWZ), SingleColumnValueFilter (cf, WORK_FLOW_NM, EQUAL, BDF_REFRESH_RAWZ_DMLINSERT_INCR_0001-gncadjp), SingleColumnValueFilter (cf, SUBJ_AREA_NM, EQUAL, CLM), SingleColumnValueFilter (cf, BDF_SOR_CD, EQUAL, 808), SingleColumnValueFilter (cf, CNSMD_IND, EQUAL, N), SingleColumnValueFilter (cf, PBLSH_IND, EQUAL, Y)]"
  val hbaseFilter_wo_regex_w_lingids = "[SingleColumnValueFilter (cf, ZONE_CD, EQUAL, RAWZ), SingleColumnValueFilter (cf, WORK_FLOW_NM, EQUAL, BDF_REFRESH_RAWZ_DMLINSERT_INCR_0001-gncadjp), SingleColumnValueFilter (cf, SUBJ_AREA_NM, EQUAL, CLM), SingleColumnValueFilter (cf, BDF_SOR_CD, EQUAL, 808), SingleColumnValueFilter (cf, CNSMD_IND, EQUAL, N), SingleColumnValueFilter (cf, PBLSH_IND, EQUAL, Y), SingleColumnValueFilter (cf, LOAD_INGSTN_ID, GREATER_OR_EQUAL, 20180101), SingleColumnValueFilter (cf, LOAD_INGSTN_ID, LESS_OR_EQUAL, 20181231)]"
  val hbaseFilter_w_regex = "[SingleColumnValueFilter (cf, ZONE_CD, EQUAL, RAWZ), SingleColumnValueFilter (cf, WORK_FLOW_NM, EQUAL, BDF_REFRESH_RAWZ_DMLINSERT_INCR_0001-gncadjp), SingleColumnValueFilter (cf, SUBJ_AREA_NM, EQUAL, CLM), SingleColumnValueFilter (cf, BDF_SOR_CD, EQUAL, 808), SingleColumnValueFilter (cf, CNSMD_IND, NOT_EQUAL, ), SingleColumnValueFilter (cf, CNSMD_IND, NOT_EQUAL, null), SingleColumnValueFilter (cf, PBLSH_IND, EQUAL, Y)]"
  val hbaseFilter_w_regex_w_lingids = "[SingleColumnValueFilter (cf, ZONE_CD, EQUAL, RAWZ), SingleColumnValueFilter (cf, WORK_FLOW_NM, EQUAL, BDF_REFRESH_RAWZ_DMLINSERT_INCR_0001-gncadjp), SingleColumnValueFilter (cf, SUBJ_AREA_NM, EQUAL, CLM), SingleColumnValueFilter (cf, BDF_SOR_CD, EQUAL, 808), SingleColumnValueFilter (cf, CNSMD_IND, NOT_EQUAL, ), SingleColumnValueFilter (cf, CNSMD_IND, NOT_EQUAL, null), SingleColumnValueFilter (cf, PBLSH_IND, EQUAL, Y), SingleColumnValueFilter (cf, LOAD_INGSTN_ID, GREATER_OR_EQUAL, 20180101), SingleColumnValueFilter (cf, LOAD_INGSTN_ID, LESS_OR_EQUAL, 20181231)]"
  val hbase_table_dv = "dv_hb_bdfrawz_nogbd_r1a_wh:BDF_LOAD_LOG"
  val hbase_table_ts = "ts_hb_bdfrawz_nogbd_r1a_wh:BDF_LOAD_LOG"
  val hbase_table_pr = "pr_hb_bdfrawz_nogbd_prd_wh:BDF_LOAD_LOG"

  val llk_load_ing_lists:java.util.List[java.util.List[String]] = List(List("32157319-be7e-4e82-8a9a-3a149e734f7b-gncadjp", "668a9e85-29a1-4481-a3aa-5de08151a298-gncadjp", "baeb4f00-30ec-412d-bed7-a8a3d4439839-gncadjp", "f9a88b1b-1870-4f14-94ad-c79fac2d46ec-gncadjp").asJava, List("20180626", "20180904", "20190129", "20181008").asJava, List("2018-06-26 15:17:34", "2018-09-04 16:11:18", "2019-01-29 15:03:34", "2018-10-08 11:29:53").asJava).asJava
  val recent_llk:(List[String],List[String]) = (List("baeb4f00-30ec-412d-bed7-a8a3d4439839-gncadjp"),List("20190129"))
  val consume_flag_map: scala.collection.mutable.Map[String, String] = scala.collection.mutable.Map[String, String]()
  consume_flag_map.put("32157319-be7e-4e82-8a9a-3a149e734f7b-gncadjp","N")
  consume_flag_map.put("668a9e85-29a1-4481-a3aa-5de08151a298-gncadjp","N")
  consume_flag_map.put("baeb4f00-30ec-412d-bed7-a8a3d4439839-gncadjp","N")
  consume_flag_map.put("f9a88b1b-1870-4f14-94ad-c79fac2d46ec-gncadjp","N")

  val consume_flag_map_java:util.Map[String, String] = consume_flag_map.asJava
  val targ_tbl_map_i:scala.collection.mutable.Map[String, String] = scala.collection.mutable.Map[String, String]()
  val targ_tbl_map_k:scala.collection.mutable.Map[String, String] = scala.collection.mutable.Map[String, String]()

  targ_tbl_map_i.put("tbl_nm", "clm_wgs_adjp_hist")
  targ_tbl_map_i.put("truncateInd", "N")
  targ_tbl_map_i.put("killNfill", "I")
  targ_tbl_map_i.put("comp_tbl_nm", "clm_wgs_adjp")
  targ_tbl_map_i.put("targ_db", "dv_bdfsrszph_nogbd_r000_wh")
  targ_tbl_map_i.put("tbl_nm_temp", "clm_wgs_adjp_temp")


  targ_tbl_map_k.put("tbl_nm", "clm_wgs_adjp")
  targ_tbl_map_k.put("tbl_nm_temp", "clm_wgs_adjp_temp")
  targ_tbl_map_k.put("truncateInd", "Y")
  targ_tbl_map_k.put("killNfill", "K")
  targ_tbl_map_k.put("comp_tbl_nm", "clm_wgs_adjp")
  targ_tbl_map_k.put("targ_db", "pr_bdfsrszph_gbd_prd_wh")


}

