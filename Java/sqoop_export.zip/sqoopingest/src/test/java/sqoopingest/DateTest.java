package sqoopingest;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DateTest{
	public static void main(String[] args) throws Exception  {
		/***String oldFmt = "dd-MMM-yyyy HH:mm:ss";
		String newFmt = "MM/dd/yyyy HH:mm:ss.SSSSSS a";
		
		DateFormat fmt = new SimpleDateFormat(oldFmt);
		Date date = fmt.parse("14-Jan-2019 00:00:00");
		
		fmt = new SimpleDateFormat(newFmt);
		String str = fmt.format(date);
		
		System.out.println(str); ***/
		String oldFmt = "dd-MMM-yyyy HH:mm:ss";
		String newFmt = "MM/dd/yyyy HH:mm:ss.SSSSSS a";

		DateFormat fmt = new SimpleDateFormat(oldFmt);
		Date maxDateFmt = null;
		String maxDateStr = null; 
		try {
			maxDateFmt = fmt.parse("14-Jan-2019 00:00:00");
			System.out.println("###############" + maxDateFmt + "#####################");
			fmt = new SimpleDateFormat(newFmt);
			maxDateStr = fmt.format(maxDateFmt);
			System.out.println("###############" + maxDateStr + "#####################");
		} catch (ParseException pe) {					
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}
} 


