package com.anthem.ingest;

import java.util.Map;


public class AccConfig {
	private Dev dev;
	private Test test;
	private Prod prod;
	private Home home;
	
	public Dev getDev() {
		return dev;
	}
	public void setDev(Dev dev) {
		this.dev = dev;
	}
	
	
    public Test getTest() {
		return test;
	}
	public void setTest(Test test) {
		this.test = test;
	}
	
	
	public Prod getProd() {
		return prod;
	}
	public void setProd(Prod prod) {
		this.prod = prod;
	}
	public Home getHome() {
		return home;
	}
	public void setHome(Home home) {
		this.home = home;
	}
	public static class Dev extends Env {}
    public static class Test extends Env {}
    public static class Prod extends Env {}
    public static class Home extends Env {}
   
    public static abstract class Env {
    	private Map<String, String> acc_config;
    	private Map<String, Map<String, Map<String, String>>> app;
	
		public Map<String, String> getAcc_config() {
			return acc_config;
		}

		public void setAcc_config(Map<String, String> acc_config) {
			this.acc_config = acc_config;
		}

		public Map<String, Map<String, Map<String, String>>> getApp() {
			return app;
		}

		public void setApp(Map<String, Map<String, Map<String, String>>> app) {
			this.app = app;
		}		
    	
    }
}
