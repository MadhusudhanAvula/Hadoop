package com.anthem.ingest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class SmokeTest {

	public static boolean debug = false;
	public static String homeDir = null;
	public static String logDir = null;
	public static String lockDir = null;
	public static String auditDir = null;
	public static String connDir = null;
	public static String sshDir = null;
	public static String jsonDir = null;
	public static String principalName = null;
	public static String keyTabFile = null;
	public static String coreSite = null;
	public static String hdfsSite = null;
	public static String yarnSite = null;
	public static String mapredSite = null;
	public static String generatedJavaSrc = null;
	public static String fullFileDir = null;
	public static String incFileDir = null;
	public static String scriptsDir = null;
	public static String arcFileDir = null;
	public static int nbrofDays = 0;
	public static final String ING = "INGESTION";
	public static final String REC = "RECONCILIATION";
	public static final String ARC = "ARCHIVE";
	public static Properties prop = null;
	public static Logger logger = null;

	String templateType = "";
	String[] sqoopQueries = null;
	ArrayList<SqoopTableConfig> tableArrayList = null;

	public static void main(String args[]) throws DataIngestException, IOException {
		int argCount = args.length;
		if (argCount != 1) {
			System.out.println("Please give JSON file name");
			System.out.println("Usage DataIngestionDrive MyTemplate.json");
			throw new DataIngestException("Error ! Please provide  a JSON template file.");
		}
		String templateFileName = args[0];
		init();
		listProperties(prop);

		SmokeTest did = new SmokeTest();
		JSONParser parser = new JSONParser();
		JSONObject template = null;
		BufferedReader brd = null;
		BufferedWriter wrt = null;
		String driver = null;
		String connectionManager = null;
		String database = null;
		try {
			brd = did.getReader(jsonDir, templateFileName);
			template = (JSONObject) parser.parse(brd);
			String templateType = (String) template.get("templatetype");
			String connectionfile = (String) template.get("connectionfile");
			String hiveURL = (String) template.get("hiveURL");
			if ("sftp".equalsIgnoreCase(templateType)) {
				isValidSftpConnection(connectionfile);
			} else if ("sqoop".equalsIgnoreCase(templateType)) {
				driver = (String) template.get("driver");
				connectionManager = (String) template.get("connectionManager");
				database = (String) template.get("database");
				isValidDbConnection(driver, connectionManager, connectionfile, database);
			}
			isValidHiveConnection(hiveURL);
		} catch (Exception e) {
			throw new DataIngestException("(Error):", e);
		} finally {
			if (brd != null)
				brd.close();
		}
	}

	private static void init() throws DataIngestException {

		prop = new Properties();
		InputStream input = null;

		try {
			input = SmokeTest.class.getClassLoader().getResourceAsStream("config.properties");
			// load a properties file
			prop.load(input);
			debug = Boolean.parseBoolean(prop.getProperty("tool.debug"));
			// System.out.println("\nDebug Flag : " + debug);
			coreSite = prop.getProperty("core.site");
			hdfsSite = prop.getProperty("hdfs.site");
			yarnSite = prop.getProperty("yarn.site");
			mapredSite = prop.getProperty("mapred.site");
			principalName = prop.getProperty("kerberos.principal");
			keyTabFile = prop.getProperty("kerberos.keytab");
			homeDir = prop.getProperty("home.dir");
			jsonDir = prop.getProperty("json.dir");
			logDir = prop.getProperty("log.dir");
			lockDir = prop.getProperty("lock.dir");
			connDir = prop.getProperty("connection.dir");
			sshDir = prop.getProperty("ssh.dir");
			auditDir = prop.getProperty("audit.dir");
			generatedJavaSrc = prop.getProperty("generated.java.src");
			fullFileDir = prop.getProperty("full.file.dir");
			incFileDir = prop.getProperty("incremental.file.dir");
			arcFileDir = prop.getProperty("arc.file.dir");
			scriptsDir = prop.getProperty("scripts.dir");
			String s = prop.getProperty("nbrofdays.older");

			try {
				nbrofDays = Integer.parseInt(s);
			} catch (NumberFormatException e) {
				nbrofDays = 0;
			}
			// prop.list(System.out);

		} catch (IOException ex) {
			throw new DataIngestException(ex);
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					throw new DataIngestException(e);
				}
			}
		}
	} // end of method

	public static void listProperties(Properties prp) {
		if (debug) {
			System.out.println("DataIngestDriver --Listing Properties-- \n");
			Enumeration keys = prp.keys();
			while (keys.hasMoreElements()) {
				String key = (String) keys.nextElement();
				String value = (String) prp.get(key);
				//System.out.println(key + "=" + value);
			}
		}
	} // end of method

	private BufferedReader getReader(String path, String fileName) throws Exception {
		return new BufferedReader(new FileReader(path + File.separator + fileName));
	}

	public static void isValidSftpConnection(String fileName) {
		JSch jsch = new JSch();
		Session session = null;
		String sshPath = null;
		Properties prop = null;
		FileInputStream fileInputStream = null;
		String connectionPath;
		try {
			connectionPath = SmokeTest.connDir + File.separator + fileName;
			fileInputStream = new FileInputStream(connectionPath);
			prop = new Properties();
			// load a properties file
			prop.load(fileInputStream);
			String userName = prop.getProperty("username");
			String sftpURL = prop.getProperty("sftpURL");
			sshPath = SmokeTest.sshDir;
			jsch.addIdentity(sshPath);
			session = jsch.getSession(userName, sftpURL);
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();

			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			System.out.println("SFTP Connection successful to source");
			sftpChannel.exit();
			session.disconnect();
		} catch (JSchException e) {
			System.out.println("SFTP Connection failed to source ");
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("SFTP Connection failed to source ");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("SFTP Connection failed to source ");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("SFTP Connection failed to source ");
			e.printStackTrace();
		} finally {
			try {
				session.disconnect();
			} catch (Exception e) {
				;
			}
		}
	}

	public static void isValidHiveConnection(String hiveURL) {
		Configuration config = new Configuration();
		config.addResource(new Path(SmokeTest.coreSite));
		config.addResource(new Path(SmokeTest.hdfsSite));
		config.addResource(new Path(SmokeTest.mapredSite));
		config.addResource(new Path(SmokeTest.yarnSite));
		// System.out.println("");
		// System.out.println( "Principal Authentication:");
		// System.out.println("");
		String user = SmokeTest.principalName;
		String keyPath = SmokeTest.keyTabFile;
		UserGroupInformation.setConfiguration(config);
		try {
			UserGroupInformation.loginUserFromKeytab(user, keyPath);
		} catch (Exception e) {
			System.out.println("Printing Stack Trace : " + e.getMessage());
		}
		Connection connection = null;
		try {
			Class.forName("org.apache.hive.jdbc.HiveDriver");
			connection = DriverManager.getConnection(hiveURL);
			System.out.println("Connection Successful to hive");
		} catch (Exception e) {
			System.out.println("Connection failed to hive");
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (Exception e) {
				System.out.println("Connection could not be closed");
			}
		}
	}

	public static void isValidDbConnection(String driver, String connectionManager, String fileName, String dbName) {
		Connection connection = null;
		String className = null;
		Properties prop = null;
		FileInputStream fileInputStream = null;
		String connectionPath;
		String userName = null;
		String password = null;
		String jdbcurl = null;
		try {
			if (driver != null) {
				className = driver;
			} else if (connectionManager != null) {
				className = connectionManager;
			}
			Class.forName(className);
			connectionPath = SmokeTest.connDir + File.separator + fileName;
			fileInputStream = new FileInputStream(connectionPath);
			prop = new Properties();
			// load a properties file
			prop.load(fileInputStream);
			userName = prop.getProperty("username");
			password = prop.getProperty("password");
			if (password != null) {
				password = SmokeTest.decryptPwd(password);
			}
			jdbcurl = prop.getProperty("jdbcurl") + dbName + ";user=" + userName + ";password=" + password;
			//System.out.println("jdbcurl******" + jdbcurl);
			connection = DriverManager.getConnection(jdbcurl);
			System.out.println("Connection Successful to Source");
		} catch (Exception e) {
			System.out.println("Connection failed to Source");
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (Exception e) {
				System.out.println("Connection could not be closed");
			}
		}
	}

	public static String decryptPwd(String value) {
		try {
			return new EncryptDecryptUtil().decryptPwd(value);
		} catch (Exception e) {
			if (debug) {
				System.out.println("Could NOT decrypt Password : " + value);
			}

			return null;
		}
	}
}
