package com.anthem.ingest;

import java.util.Map;

public class GlobalConfig {

	private Dev dv;
	private Test ts;
	private Prod pr;
	
	
	
	
	public Dev getDv() {
		return dv;
	}


	public void setDv(Dev dv) {
		this.dv = dv;
	}


	public Test getTs() {
		return ts;
	}


	public void setTs(Test ts) {
		this.ts = ts;
	}


	public Prod getPr() {
		return pr;
	}


	public void setPr(Prod pr) {
		this.pr = pr;
	}


	public static class Dev extends Env {}
    public static class Test extends Env {}
    public static class Prod extends Env {}
    
   
    public static abstract class Env {
    	private Map<String, String> hadoop_config;
    	private Map<String, String> hadoop_data;
    	private Map<String, String> edgenode;
		public Map<String, String> getEdgenode() {
			return edgenode;
		}

		public void setEdgenode(Map<String, String> edgenode) {
			this.edgenode = edgenode;
		}

		public Map<String, String> getHadoop_config() {
			return hadoop_config;
		}

		public void setHadoop_config(Map<String, String> hadoop_config) {
			this.hadoop_config = hadoop_config;
		}

		public Map<String, String> getHadoop_data() {
			return hadoop_data;
		}

		public void setHadoop_data(Map<String, String> hadoop_data) {
			this.hadoop_data = hadoop_data;
		}		
    	
    }
    
	
}
