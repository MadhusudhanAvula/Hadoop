package com.anthem.ingest;

import java.security.Key;
import java.util.Base64;


import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
 /**
 * This class defines the key parameter used in encryption
 * and decryption .
 */
public class EncryptDecryptUtil {

	private static String key = "RNDZBAR-KAARYAAN";

	public static void main(String[] args) throws Exception {
		int argCount = args.length;

		System.out.println("Number of Arguments :" + argCount);
		if (argCount < 2) {
			System.out.println("Usage:\n\nTo Encrypt Password\nEncryptDecryptUtil encrypt yourplaintext");
			System.out.println("To Decrypt Password\n\nEncryptDecryptUtil decrypt yourdecryptedtext");
			System.exit(0);
		}
		System.out.println("Given Original String :" + args[1]);
		if (args[0].equalsIgnoreCase("encrypt")) {
			encrypt(args[1]);
			System.exit(0);
		}
		if (args[0].equalsIgnoreCase("decrypt")) {
			decrypt(args[1]);
			System.exit(0);
		}

		System.out.println("Done Nothing");

	}
    /**
     * This method describes the encryption of a string.
     * @param text
     * @return
     * @throws Exception
     */
	public static String encrypt(String text) throws Exception {
		Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, aesKey);
		byte[] encrypted = cipher.doFinal(text.getBytes());
		Base64.Encoder encoder = Base64.getEncoder();
		String encryptedString = encoder.encodeToString(encrypted);
		System.out.println("encrypted string " + encryptedString);
		return encryptedString;
	}
    /**
     * This method describes the decryption of an encrypted string.
     * @param encryptedString
     * @return
     * @throws Exception
     */
	public static String decrypt(String encryptedString) throws Exception {
		Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		Base64.Decoder decoder = Base64.getDecoder();
		cipher.init(Cipher.DECRYPT_MODE, aesKey);
		String decrypted = new String(cipher.doFinal(decoder.decode(encryptedString)));
		System.out.println("decrypted string " + decrypted);
		return decrypted;
	}

	public static String encryptPwd(String text) throws Exception {
		Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, aesKey);
		byte[] encrypted = cipher.doFinal(text.getBytes());
		Base64.Encoder encoder = Base64.getEncoder();
		String encryptedString = encoder.encodeToString(encrypted);
		return encryptedString;
	}

	public static String decryptPwd(String encryptedString) throws Exception {
		Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
		Cipher cipher = Cipher.getInstance("AES");
		Base64.Decoder decoder = Base64.getDecoder();
		cipher.init(Cipher.DECRYPT_MODE, aesKey);
		String decrypted = new String(cipher.doFinal(decoder.decode(encryptedString)));
		return decrypted;
	}

} // End of Class
