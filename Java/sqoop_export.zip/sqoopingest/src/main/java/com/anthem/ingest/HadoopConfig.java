package com.anthem.ingest;

public class HadoopConfig {

}
