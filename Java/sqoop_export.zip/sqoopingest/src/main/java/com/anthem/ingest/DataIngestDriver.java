package com.anthem.ingest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;

import java.util.Map;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
/**
 * This class defines all the parameters of configuration 
 * properties used by the framework.
 */
public class DataIngestDriver {
	public static boolean debug = false;
	public static String homeDir = null;
	public static String logDir = null;
	public static String lockDir = null;
	public static String auditDir = null;
	public static String connDir = null;
	public static String sshDir = null;
	public static String jsonDir = null;
	public static String principalName = null;
	public static String keyTabFile = null;
	public static String coreSite = null;
	public static String hdfsSite = null;
	public static String yarnSite = null;
	public static String mapredSite = null;
	public static String generatedJavaSrc = null;
	public static String fullFileDir = null;
	public static String incFileDir = null;
	public static String scriptsDir = null;
	public static String arcFileDir = null;
	public static String dbUserName = null;
	public static String pwdAlias = null;
	public static String jceksFileLocation = null;
	public static String sourcedbname=null;
	public static String jdbcURL = null;
	public static int nbrofDays = 0;
	public static final String ING = "INGESTION";
	public static final String REC = "RECONCILIATION";
	public static final String ARC = "ARCHIVE";
	public static Properties prop = null;
	public static Logger logger = null;
	public static String templateFileName = null;
	public static String tdwalletpwd=null;
	public static String hdfstargetdir=null;
	public static String schemaEvolution="true";
	public static String gbdNoGbd="gbd";
	public static String tdchmethod="internal.fastexport";
	public static String dbtype="NONE";
	

	String templateType = "";
	String[] sqoopQueries = null;
	ArrayList<SqoopTableConfig> tableArrayList = null;
	static String yamlFileLocation="";
	static String loadLogKey="";
	static String environment="";
	static String release="";
	static String source="";
	static String category="";
	static String logFileGbd="";
	static String logFileName="";
	
	public static void main(String[] args) throws DataIngestException, Exception {
		int argCount = args.length;
		if (argCount < 7) {
			System.out.println("JSON file name // YAML file location // loadLogKey // environment // release //category // source is missing");
			System.out.println("Usage DataIngestionDrive MyTemplate.json /full/path/to/env.yaml loadLogKey env release category source");
			throw new DataIngestException("Error ! Please provide JSON file name // YAML file location // loadLogKey // environment // release //category // source");
		}
		templateFileName = args[0];
		yamlFileLocation = args[1];
		loadLogKey=args[2];
		environment=args[3];
		release=args[4];
		category=args[5];
		source=args[6];
		logFileGbd=args[7];
		logFileName=args[8];
		
		if (argCount == 11) {
			if(args[9].contains("gbd")){
				gbdNoGbd=args[9];
				tdchmethod=args[10];
			}
			else if(args[10].contains("gbd")){
				gbdNoGbd=args[10];
				tdchmethod=args[9];
				
			}
		}
		else if(argCount == 10){
			if(args[9].contains("gbd")){
				gbdNoGbd=args[9];
				
			}
			else{
				tdchmethod=args[9];
			}
			
		}

		System.out.println("HDFS target directory is in "+ gbdNoGbd+" location");
		
		init();

		createLogger(templateFileName);
		listProperties(prop);

		String fullLck = lockDir + File.separator + templateFileName + ".lck";
		try {
			if (!checkLockFile(fullLck)) {
				return;
			}
		} catch (Exception e) {
			if (debug)
				System.out.println("Lock File " + fullLck + " verification Failed.");
		}

		//System.out.println("Checkpoint 1");

		DataIngestDriver did = new DataIngestDriver();
		JSONParser parser = new JSONParser();
		JSONObject template = null;
		BufferedReader brd = null;
		BufferedWriter wrt = null;
		//System.out.println("Checkpoint 2");
		try {
			brd = did.getReader(jsonDir, templateFileName);
			template = (JSONObject) parser.parse(brd);
		} catch (Exception e) {
			throw new DataIngestException("(Error):", e);
		} finally {
			if (brd != null)
				brd.close();
		}
		//System.out.println("Checkpoint 3");

		if (did.validType(template)) {
			//System.out.println("Checkpoint 4");

			DataIngestFactory factory = new DataIngestFactory();
			//System.out.println("Checkpoint 5");
			//System.out.println("checkpoint Template Type :  "+did.templateType);
			DataIngest dataIngest = factory.getIngestObj(did.templateType);
			//System.out.println("Checkpoint 6");

			if (dataIngest != null) {
				dataIngest.loadConfig(templateFileName);
				dataIngest.printRunnable();
				int status = dataIngest.run();
			} else {
				// System.out.println("Not Implemented Yet");
				throw new DataIngestException("Templatetype " + did.templateType + " NOT implemented yet.");
			}
		}
		//System.out.println("Checkpoint 7");
		deleteFile(fullLck);
	}

	private boolean validType(JSONObject template) throws DataIngestException {
		boolean flag = false;
		if (template.isEmpty() || !template.containsKey("templatetype")) {
			String s = template.isEmpty() ? "Empty JSON Template" : "No \"templatetype\" key found in JSON file";
			throw new DataIngestException(s);

		} else {
			this.templateType = (String) template.get("templatetype");
			// System.out.println("Template Type : " +
			// template.get("templatetype"));
			flag = true;
		}
		return flag;
	}

	private BufferedReader getReader(String path, String fileName) throws Exception {
		return new BufferedReader(new FileReader(path + File.separator + fileName));
	}
	/**
	 * Init method would read all configuration details from
	 * config.properties ,which is in injection framework class path.
	 * @throws DataIngestException
	 */
	private static void init() throws DataIngestException {

		prop = new Properties();
		InputStream input = null;

		try {

			ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			GlobalConfig gc = mapper.readValue(new File(yamlFileLocation+"/env.yaml"), GlobalConfig.class);
			AppConfig ac = mapper.readValue(new File(yamlFileLocation+"/"+category+"/"+source+"/"+category+"_"+source+".yaml"), AppConfig.class);

			if (environment.equalsIgnoreCase("dv")){
				
				System.out.println("Parsing DEV yaml(dv->hadoop_config:) configurations !");
				Map<String,String> dv_hadoop_config_map = gc.getDv().getHadoop_config();
				
				System.out.println("Parsing DEV yaml(dv->hadoop_data:) configurations !");
				Map<String,String> dv_hadoop_data_map = gc.getDv().getHadoop_data();
				
				
				System.out.println("Parsing DEV yaml(dv->edgenode:) configurations !");
				Map<String,String> dv_edgenode_map = gc.getDv().getEdgenode();
				
				System.out.println("Parsing DEV yaml(dv->"+category+"->"+source+":) configurations!");
				
				Map<String, Map<String, Map<String, String>>> dv_app_map = ac.getDv();
				
				coreSite=dv_hadoop_config_map.get("core_site");
				hdfsSite=dv_hadoop_config_map.get("hdfs_site");
				yarnSite=dv_hadoop_config_map.get("yarn_site");
				mapredSite=dv_hadoop_config_map.get("mapred_site");
				principalName=dv_hadoop_config_map.get("kerberos_principal");
				keyTabFile=dv_hadoop_config_map.get("kerberos_keytab");
				homeDir=dv_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/bin/accelerator";
				//connDir=dv_acc_config_map.get("TDCH_CONN_DIR");
				jsonDir=dv_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/parm/"+category+"/"+source+"/json";
				logDir=dv_edgenode_map.get("edgenode_app_"+logFileGbd+"_top")+release+"/etl/logs/"+"/"+category+"/"+source;
				generatedJavaSrc=dv_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/schema/"+category+"/"+source;
				lockDir=dv_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/parm/"+category+"/"+source+"/lock";
				debug=Boolean.valueOf(dv_hadoop_config_map.get("tool_debug"));
				fullFileDir="input";
				
				if(gbdNoGbd.equalsIgnoreCase("no_gbd")){
					hdfstargetdir=dv_hadoop_data_map.get("hdfs_rawz_nogbd_top")+release+"/inbound/"+category+"/"+source;
				}
				else{
					hdfstargetdir=dv_hadoop_data_map.get("hdfs_rawz_gbd_top")+release+"/inbound/"+category+"/"+source;
				}
				
				dbUserName=dv_app_map.get(category).get(source).get("dbusername");
				
				pwdAlias = dv_app_map.get(category).get(source).get("password_alias");
				jceksFileLocation = dv_app_map.get(category).get(source).get("jceksfilelocation");
				sourcedbname = dv_app_map.get(category).get(source).get("sourcedbname");
				jdbcURL = dv_app_map.get(category).get(source).get("jdbcurl");
				tdwalletpwd=dv_app_map.get(category).get(source).get("tdwalletname");
				
				if (dv_app_map.get(category).get(source).get("schema_evolution")!=null){
					schemaEvolution=dv_app_map.get(category).get(source).get("schema_evolution");	
				}
				if (dv_app_map.get(category).get(source).get("dbtype")!=null){
					dbtype=dv_app_map.get(category).get(source).get("dbtype");	
				}

			}

			if (environment.equalsIgnoreCase("ts")){
				System.out.println("Parsing TEST yaml(ts->hadoop_config:) configurations !");
				Map<String,String> ts_hadoop_config_map = gc.getTs().getHadoop_config();
				
				System.out.println("Parsing TEST yaml(ts->hadoop_data:) configurations !");
				Map<String,String> ts_hadoop_data_map = gc.getTs().getHadoop_data();
				
				System.out.println("Parsing TEST yaml(ts->edgenode:) confgurations !");
				Map<String,String> ts_edgenode_map = gc.getTs().getEdgenode();
				
				System.out.println("Parsing TEST yaml(ts->"+category+"->"+source+":) configurations!");				
				Map<String, Map<String, Map<String, String>>> ts_app_map = ac.getTs();
				
				coreSite=ts_hadoop_config_map.get("core_site");
				hdfsSite=ts_hadoop_config_map.get("hdfs_site");
				yarnSite=ts_hadoop_config_map.get("yarn_site");
				mapredSite=ts_hadoop_config_map.get("mapred_site");
				principalName=ts_hadoop_config_map.get("kerberos_principal");
				keyTabFile=ts_hadoop_config_map.get("kerberos_keytab");
				homeDir=ts_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/bin/accelerator";
				//connDir=dv_acc_config_map.get("TDCH_CONN_DIR");
				jsonDir=ts_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/parm/"+category+"/"+source+"/json";
				logDir=ts_edgenode_map.get("edgenode_app_"+logFileGbd+"_top")+release+"/etl/logs/"+"/"+category+"/"+source;
				generatedJavaSrc=ts_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/schema/"+category+"/"+source;
				lockDir=ts_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/parm/"+category+"/"+source+"/lock";
				debug=Boolean.valueOf(ts_hadoop_config_map.get("tool_debug"));
				fullFileDir="input";
				
				if(gbdNoGbd.equalsIgnoreCase("no_gbd")){
					hdfstargetdir=ts_hadoop_data_map.get("hdfs_rawz_nogbd_top")+release+"/inbound/"+category+"/"+source;
				}
				else{
					hdfstargetdir=ts_hadoop_data_map.get("hdfs_rawz_gbd_top")+release+"/inbound/"+category+"/"+source;
				}
				
				dbUserName=ts_app_map.get(category).get(source).get("dbusername");
				pwdAlias = ts_app_map.get(category).get(source).get("password_alias");
				jceksFileLocation = ts_app_map.get(category).get(source).get("jceksfilelocation");
				sourcedbname = ts_app_map.get(category).get(source).get("sourcedbname");
				jdbcURL = ts_app_map.get(category).get(source).get("jdbcurl");
				tdwalletpwd=ts_app_map.get(category).get(source).get("tdwalletname");
				
				if (ts_app_map.get(category).get(source).get("schema_evolution")!=null){
					schemaEvolution=ts_app_map.get(category).get(source).get("schema_evolution");	
				}
				if (ts_app_map.get(category).get(source).get("dbtype")!=null){
					dbtype=ts_app_map.get(category).get(source).get("dbtype");	
				}
				if (ts_app_map.get(category).get(source).get("enablehivedropdelim")!=null){
					dbtype=ts_app_map.get(category).get(source).get("enablehivedropdelim");	
				}
				

			}

			if (environment.equalsIgnoreCase("pr")){
				System.out.println("Parsing PROD yaml(pr->hadoop_config:) configurations !");
				Map<String,String> pr_hadoop_config_map = gc.getPr().getHadoop_config();
				
				System.out.println("Parsing PROD yaml(pr->hadoop_data:) configurations !");
				Map<String,String> pr_hadoop_data_map = gc.getPr().getHadoop_data();
				
				System.out.println("Parsing PROD yaml(pr->edgenode:) configurations !");
				Map<String,String> pr_edgenode_map = gc.getPr().getEdgenode();
				
				System.out.println("Parsing PROD yaml(pr->"+category+"->"+source+":) configurations!");				
				Map<String, Map<String, Map<String, String>>> pr_app_map = ac.getPr();
				
				coreSite=pr_hadoop_config_map.get("core_site");
				hdfsSite=pr_hadoop_config_map.get("hdfs_site");
				yarnSite=pr_hadoop_config_map.get("yarn_site");
				mapredSite=pr_hadoop_config_map.get("mapred_site");
				principalName=pr_hadoop_config_map.get("kerberos_principal");
				keyTabFile=pr_hadoop_config_map.get("kerberos_keytab");
				homeDir=pr_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/bin/accelerator";
				//connDir=dv_acc_config_map.get("TDCH_CONN_DIR");
				jsonDir=pr_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/parm/"+category+"/"+source+"/json";
				logDir=pr_edgenode_map.get("edgenode_app_"+logFileGbd+"_top")+release+"/etl/logs/"+"/"+category+"/"+source;
				generatedJavaSrc=pr_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/schema/"+category+"/"+source;
				lockDir=pr_edgenode_map.get("edgenode_app_nogbd_top")+release+"/etl/parm/"+category+"/"+source+"/lock";
				debug=Boolean.valueOf(pr_hadoop_config_map.get("tool_debug"));
				fullFileDir="input";
				
				if(gbdNoGbd.equalsIgnoreCase("no_gbd")){
					hdfstargetdir=pr_hadoop_data_map.get("hdfs_rawz_nogbd_top")+release+"/inbound/"+category+"/"+source;
				}
				else{
					hdfstargetdir=pr_hadoop_data_map.get("hdfs_rawz_gbd_top")+release+"/inbound/"+category+"/"+source;
				}
				
				dbUserName=pr_app_map.get(category).get(source).get("dbusername");
				pwdAlias = pr_app_map.get(category).get(source).get("password_alias");
				jceksFileLocation = pr_app_map.get(category).get(source).get("jceksfilelocation");
				sourcedbname = pr_app_map.get(category).get(source).get("sourcedbname");
				jdbcURL = pr_app_map.get(category).get(source).get("jdbcurl");
				tdwalletpwd=pr_app_map.get(category).get(source).get("tdwalletname");
				
				if (pr_app_map.get(category).get(source).get("schema_evolution")!=null){
					schemaEvolution=pr_app_map.get(category).get(source).get("schema_evolution");	
				}
				if (pr_app_map.get(category).get(source).get("dbtype")!=null){
					dbtype=pr_app_map.get(category).get(source).get("dbtype");	
				}

			}
		} catch (IOException ex) {
			throw new DataIngestException(ex);
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					throw new DataIngestException(e);
				}
			}
		}
	} // end of method
	/**
	 * Create Logger Mechanism and route all the logs to log4J location
	 * @param tFileName
	 */
	public static void createLogger(String tFileName) {

		//String logflname = tFileName + "_" + new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss.SSS").format(new Date());
		String logflname = logFileName;
		System.setProperty("logfilename", logflname);
		System.setProperty("logDir", DataIngestDriver.logDir);
		logger = Logger.getLogger(DataIngestDriver.class.getName());
		System.setOut(reStdOut(System.out));
		//System.setErr(reStdErr(System.err));

	}

	public static PrintStream reStdOut(final PrintStream realPrintStream) {
		return new PrintStream(realPrintStream) {
			public void print(final String string) {
				logger.info(string);
			}

			public void println(final String string) {
				logger.info(string);
			}
		};
	}

	public static PrintStream reStdErr(final PrintStream realPrintStream) {
		return new PrintStream(realPrintStream) {
			public void print(final String string) {
				logger.error(string);
			}

			public void println(final String string) {
				logger.error(string);
			}
		};
	}

	public static void listProperties(Properties prp) {
		if (debug) {
			System.out.println("DataIngestDriver --Listing Properties-- \n");
			System.out.println("DataIngestDriver --GIT PUSH TEST!!!!!-- \n");
			System.out.println("DataIngestDriver --GIT PUSH TEST--ANTHEM!!!!!-- \n");
			System.out.println("coreSite= "+coreSite);
			System.out.println("hdfsSite= "+hdfsSite);
			System.out.println("yarnSite= "+yarnSite);
			System.out.println("mapredSite= "+mapredSite);
			System.out.println("principalName= "+principalName);
			System.out.println("keyTabFile= "+keyTabFile);
			System.out.println("homeDir= "+homeDir);
			System.out.println("connDir= "+connDir);
			System.out.println("jsonDir= "+jsonDir);
			System.out.println("logDir= "+logDir);
			System.out.println("generatedJavaSrc= "+generatedJavaSrc);
			System.out.println("lockDir= "+lockDir);
			System.out.println("debug= "+debug);
			System.out.println("fullFileDir= "+fullFileDir);
			System.out.println("dbUserName= "+dbUserName);
			System.out.println("pwdAlias= "+pwdAlias); 
			System.out.println("jceksFileLocation= "+jceksFileLocation); 
			System.out.println("sourcedbname= "+sourcedbname); 
			System.out.println("jdbcURL= "+jdbcURL);
			System.out.println("tdwalletpwd= "+tdwalletpwd);
			System.out.println("gbdNoGbd= "+gbdNoGbd);
			System.out.println("tdchmethod= "+tdchmethod);
			System.out.println("logFileName= "+logFileName);
			System.out.println("dbtype= "+dbtype);
			System.out.println("schemaEvolution= "+schemaEvolution);/*Enumeration keys = prp.keys();
			while (keys.hasMoreElements()) {
				String key = (String) keys.nextElement();
				String value = (String) prp.get(key);
				System.out.println(key + "=" + value);
			}*/
		}
	}
	/**
	 * The checkLockFile method is used to check the given input json files is already locked or not.
	 * @param fullLck
	 * @return
	 * @throws Exception
	 */
	public static boolean checkLockFile(String fullLck) throws Exception {
		boolean proceed = true;
		if (debug)
			System.out.println("Current Job PID : " + ManagementFactory.getRuntimeMXBean().getName());
		File f = new File(fullLck);
		String PID = null;
		boolean running = false;
		if (f.exists() && !f.isDirectory()) {
			if (debug)
				System.out.println("Lock File " + fullLck + " already exists, checking for Process Status...");
			try {
				BufferedReader bReader = new BufferedReader(new FileReader(fullLck));

				String strLine = null;
				while ((strLine = bReader.readLine()) != null) {
					if (strLine.contains("PID")) {
						PID = getPID(strLine.trim());
						if (debug)
							System.out.println("Extracted PID : " + PID);
					}
				}
				running = isProcessIdRunning(PID);
				if (!running) {
					createLockFile(fullLck);
				} else {
					proceed = false;
				}

				bReader.close();

			} catch (Exception e) {
				System.out.println("Error encountered in reading lock file : " + fullLck);
			}
		} else {
			if (debug)
				System.out.println("File " + fullLck + " Does NOT Exist.");
			createLockFile(fullLck);
		}
		return proceed;
	}

	private static String getPID(String s) {
		String pid = null;
		String[] ar = s.split(":");
		pid = ar[1].split("@")[0];
		return pid.trim();
	}
	/**
	 * This method is used to get the process id from management 
	 * factory bean and it is stored  the process id
	 * with yyyy-MM-dd HH:mm:ss  time stamp 
	 * @param fl
	 */
	private static void createLockFile(String fl) {
		if (debug)
			System.out.println("Creating lock file....." + fl);
		try {
			PrintWriter writer = new PrintWriter(fl, "UTF-8");
			writer.println("PID : " + ManagementFactory.getRuntimeMXBean().getName());
			writer.println("Process Start Time : " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
			writer.close();
		} catch (IOException e) {
			System.out.println("Error encountered in writing lock file : " + fl);
		}
	}
	/**
	 * This method would be checking the given id is active or not based on the process run time command.
	 * This method will return true if process id is active, otherwise return false.
	 * @param pid
	 * @return
	 */
	private static boolean isProcessIdRunning(String pid) {
		String command = "ps -p " + pid;
		try {
			Runtime rt = Runtime.getRuntime();
			Process pr = rt.exec(command);

			InputStreamReader isReader = new InputStreamReader(pr.getInputStream());
			BufferedReader bReader = new BufferedReader(isReader);
			String strLine = null;
			while ((strLine = bReader.readLine()) != null) {
				if (strLine.contains(pid)) {
					if (debug)
						System.out.println("Process " + pid + " is Active.");
					return true;
				}
			}
			if (debug)
				System.out.println("Process " + pid + " is NOT Active.");
			return false;
		} catch (Exception ex) {
			System.out.println("Got exception using system command " + command);
			return false;
		}
	}

	public static void deleteFile(String fileName) {
		try {
			File file = new File(fileName);
			if (file.delete()) {
				System.out.println(file.getName() + " deleted successfully.");
			} else {
				System.out.println(fileName + " DELETE operation failed.");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String decryptPwd(String value) {
		try {
			return new EncryptDecryptUtil().decryptPwd(value);
		} catch (Exception e) {
			if (debug) {
				System.out.println("Could NOT decrypt Password : " + value);
			}

			return null;
		}
	}

	public static String encryptPwd(String value) {
		try {
			return new EncryptDecryptUtil().encryptPwd(value);
		} catch (Exception e) {
			if (debug) {
				System.out.println("Could NOT encrypt Password : " + value);
			}

			return null;
		}
	}

} // end of class
