package com.anthem.ingest;
 /**
 * This class is a place holder for import file parameters in a java object
 */
public class SFTPFileConfig {

	public static final String sftpSrcDir_p = "sftpsrcdir"; // sftpsrcdir
	public static final String sftpSrcFile_p = "sftpsrcfile"; // --file
	public static final String hdfsTargetDir_p = "hdfstargetdir"; // --target-dir
	public static final String incremental_p = "incremental"; // --incremental
	public static final String localDir_p = "localdir"; // --localDir
	//import Sequence used to sort this object
	public static final String importSequence_p = "importsequence";
	public static final String hiveScript_p = "hivescript";
	public static final String preProcessScript_p = "preprocessscript";
	public static final String tableName_p = "tablename"; // --tableName
	public static final String hdfsStageDir_p = "hdfsstagedir"; // --stage dir
	public static final String issueType_p = "issuetype";
	public static final String fileType_p = "filetype";

	String sftpSrcDir = null;
	String sftpSrcFile = null;
	String hdfsTargetDir = null;
	String incremental = null;
	String localDir = null;
	int importSequence = 9999;
	String sftpCmd = null;
	boolean validFileConfig = false;
	String sftpSrcPath = null;
	String localSrcPath = null;
	String targetHDFSPath = null;
	String archivePath = null;
	String hiveScript = null;
	String preProcessScript = null;
	String tablename = null;
	String hdfsStageDir = null;
	String issueType = null;
	String fileType = null;

	SFTPFileConfig() {
		super();
	}
    /**
     * This class is a place holder for import file parameters in a java object from given input json file
     * @param sftpSrcDir
     * @param sftpSrcFile
     * @param hdfsTargetDir
     * @param incremental
     * @param localDir
     * @param importSequence
     * @param hiveScript
     * @param preProcessScript
     * @param tablename
     * @param hdfsStageDir
     * @param issueType
     * @param filetype
     */
	SFTPFileConfig(String sftpSrcDir, String sftpSrcFile, String hdfsTargetDir, String incremental, String localDir,
			int importSequence, String hiveScript, String preProcessScript, String tablename, String hdfsStageDir,
			String issueType, String filetype) {
		this.sftpSrcFile = sftpSrcFile;
		this.localDir = localDir;
		this.hdfsTargetDir = hdfsTargetDir;
		this.incremental = incremental;
		this.sftpSrcDir = sftpSrcDir;
		this.importSequence = importSequence;
		this.hiveScript = hiveScript;
		this.preProcessScript = preProcessScript;
		this.tablename = tablename;
		this.hdfsStageDir = hdfsStageDir;
		this.issueType = issueType;
		this.fileType = filetype;

	}

	public String getArchivePath() {
		return this.archivePath;
	}

	public void setArchivePath(String p) {
		this.archivePath = p;
	}

	public void setSftpSrcFile(String sftpSrcFile) {
		this.sftpSrcFile = sftpSrcFile;
	}

	public String getSftpSrcFile() {
		return this.sftpSrcFile;
	}

	public void setLocalDir(String localDir) {
		this.localDir = localDir;
	}

	public String getLocalDir() {
		return this.localDir;
	}

	public void setHdfsTargetDir(String hdfsTargetDir) {
		this.hdfsTargetDir = hdfsTargetDir;
	}

	public String getHdfsTargetDir() {
		return this.hdfsTargetDir;
	}

	public void setIncremental(String incremental) {
		this.incremental = incremental;
	}

	public String getIncremental() {
		return this.incremental;
	}

	public void setSftpSrcDir(String sftpSrcDir) {
		this.sftpSrcDir = sftpSrcDir;
	}

	public String getSftpSrcDir() {
		return this.sftpSrcDir;
	}

	public void setImportSequence(int importSequence) {
		this.importSequence = importSequence;
	}

	public int getImportSequence() {
		return this.importSequence;
	}

	public boolean getValidFileConfig() {
		return this.validFileConfig;
	}

	public void setValidFileConfig(boolean validFileConfig) {
		this.validFileConfig = validFileConfig;
	}

	public String getSftpCmd() {
		return this.sftpCmd;
	}

	public void setSftpCmd(String cmd) {
		this.sftpCmd = cmd;
	}

	public void setLocalSrcPath(String s) {
		this.localSrcPath = s;
	}

	public String getLocalSrcPath() {
		return this.localSrcPath;
	}

	public void setTargetHDFSPath(String s) {
		this.targetHDFSPath = s;
	}

	public String getTargetHDFSPath() {
		return this.targetHDFSPath;
	}

	public void setHiveScript(String scp) {
		this.hiveScript = scp;
	}

	public String getHiveScript() {
		return this.hiveScript;
	}

	public void setPreProcessScript(String preProcessScript) {
		this.preProcessScript = preProcessScript;
	}

	public String getPreProcessScript() {
		return this.preProcessScript;
	}

	public void setTableName(String tablename) {
		this.tablename = tablename;
	}

	public String getTableName() {
		return this.tablename;
	}

	public void setHdfsStageDir(String hdfsStageDir) {
		this.hdfsStageDir = hdfsStageDir;
	}

	public String getHdfsStageDir() {
		return this.hdfsStageDir;
	}

	public void setIssueType(String issueType) {
		this.issueType = issueType;
	}

	public String getIssueType() {
		return this.issueType;
	}

	public void setFileType(String filetype) {
		this.fileType = filetype;
	}

	public String getFileType() {
		return this.fileType;
	}

	public void setSftpSrcPath(String s) {
		this.sftpSrcPath = s;
	}

	public String getSftpSrcPath() {
		return this.sftpSrcPath;
	}

	public boolean isValidFileConfig() {
		validateFileConfig();
		return validFileConfig;
	}

	public void validateFileConfig() {
		if (sftpSrcFile == null || localDir == null || hdfsTargetDir == null || incremental == null
				|| sftpSrcDir == null || hiveScript == null || preProcessScript == null || tablename == null
				|| hdfsStageDir == null || issueType == null) {
			validFileConfig = false;
		} else
			validFileConfig = true;

	}

	public String toString() {
		StringBuffer tbl = new StringBuffer();
		tbl.append(sftpSrcDir_p + " : " + sftpSrcDir + "\n");
		tbl.append(sftpSrcFile_p + " : " + sftpSrcFile + "\n");
		tbl.append(hdfsTargetDir_p + " : " + hdfsTargetDir + "\n");
		tbl.append(incremental_p + " : " + incremental + "\n");
		tbl.append(localDir_p + " : " + localDir + "\n");
		tbl.append(importSequence_p + " : " + importSequence + "\n");
		tbl.append("SFTP Command : " + sftpCmd + "\n");
		tbl.append("sftpSrcPath: " + sftpSrcPath + "\n");
		tbl.append("localSrcPath: " + localSrcPath + "\n");
		tbl.append("targetHDFSPath :" + targetHDFSPath + "\n");
		tbl.append("Archive Path : " + archivePath + "\n");
		tbl.append(hiveScript_p + " : " + hiveScript + "\n");
		tbl.append(preProcessScript_p + " : " + preProcessScript + "\n");
		tbl.append(tableName_p + " : " + tablename + "\n");
		tbl.append(hdfsStageDir_p + " : " + hdfsStageDir + "\n");
		tbl.append(issueType_p + " : " + issueType + "\n");
		tbl.append(fileType_p + " : " + fileType + "\n");
		tbl.append("Valid SFTP Config" + " : " + validFileConfig);
		return tbl.toString();
	}

} // End of Class
