package com.anthem.ingest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Stats {
	private static DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static Properties prop = null;

	public static void main(String[] args) throws IOException {
		generateStats(args[0]);
	}
	
	public static void generateStats(String auditFileName){

		// TODO Auto-generated method stub
		prop = new Properties();
		InputStream input = null;

		try {
			//input = new FileInputStream("C:\\Framework\\config.properties");
			input = Stats.class.getClassLoader().getResourceAsStream("config.properties");
			prop.load(input);
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("new sheet");
		HSSFRow row1 = sheet.createRow(0);
		HSSFRow row2 = sheet.createRow(1);
		HSSFRow row;
		HSSFCell cell = null;

		/*
		 * row1.getCell(1).setCellStyle(style);
		 * row1.getCell(2).setCellStyle(style);
		 */
		row2.createCell(0).setCellValue("File Name");
		row2.createCell(1).setCellValue("Start Time");
		row2.createCell(2).setCellValue("End Time");
		row2.createCell(3).setCellValue("Ingestion Status");
		row2.createCell(4).setCellValue("Ingestion Time Taken");
		row2.createCell(5).setCellValue("Start Time");
		row2.createCell(6).setCellValue("End Time");
		row2.createCell(7).setCellValue("Reconcilation Status");
		row2.createCell(8).setCellValue("Reconcilation Time Taken");
		row2.createCell(9).setCellValue("Complete Duration");
		row2.createCell(10).setCellValue("File size in Bytes");
		row1.createCell(1).setCellValue("Ingestion");
		row1.createCell(5).setCellValue("Reconciliation");
		row1.createCell(9).setCellValue(" ");
		row1.createCell(10).setCellValue(" ");
		row1.createCell(0).setCellValue("Processing Step");
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 1, 4));
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 5, 8));
		CellStyle style = wb.createCellStyle();// Create style
		CellStyle headerStyle = wb.createCellStyle();
		headerStyle.setAlignment(headerStyle.ALIGN_CENTER_SELECTION);
		headerStyle.setAlignment(headerStyle.ALIGN_CENTER);
		HSSFFont font = wb.createFont();// Create font
		font.setBoldweight(font.BOLDWEIGHT_BOLD);// Make font bold
		style.setFillForegroundColor(IndexedColors.CORAL.getIndex());
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFont(font);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		row1.getCell(1).setCellStyle(headerStyle);
		row1.getCell(5).setCellStyle(headerStyle);
		row1.getCell(0).setCellStyle(style);
		row1.getCell(1).setCellStyle(style);
		row1.getCell(5).setCellStyle(style);
		row1.getCell(9).setCellStyle(style);
		row1.getCell(10).setCellStyle(style);
		row2.getCell(0).setCellStyle(style);
		row2.getCell(1).setCellStyle(style);
		row2.getCell(2).setCellStyle(style);
		row2.getCell(3).setCellStyle(style);
		row2.getCell(4).setCellStyle(style);
		row2.getCell(5).setCellStyle(style);
		row2.getCell(6).setCellStyle(style);
		row2.getCell(7).setCellStyle(style);
		row2.getCell(8).setCellStyle(style);
		row2.getCell(9).setCellStyle(style);
		row2.getCell(10).setCellStyle(style);
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(2);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);
		sheet.autoSizeColumn(6);
		sheet.autoSizeColumn(7);
		sheet.autoSizeColumn(8);
		sheet.autoSizeColumn(9);
		sheet.autoSizeColumn(10);

		// ************JSON PARSE********************//
		JSONParser parser = new JSONParser();
		try {
			String getIngestionStarttime = null;
			String getIngestionEndtime = null;
			String ingestionStatus = null;
			String ingestionSize = null;
			String getReconciliationStarttime = null;
			String getReconciliationEndtime = null;
			String reconciliationStarttime = null;
			String reconciliationEndtime = null;
			String reconciliationTimeTaken = null;
			String step = null;
			String filename = null;
			String reconciliationStatus = null;
			String ingestionStarttime = null;
			String ingestionEndtime = null;
			String IngestionTimeTaken = null;
			String completeDurationTaken = null;
			int k = 2;
			String inputFile = (String) Stats.prop.getProperty("audit.dir");
			File inFile = null;
			if (0 < auditFileName.length()) {
				inFile = new File(inputFile+File.separator+auditFileName);
			} else {
				System.err.println("Invalid arguments count:" + auditFileName.length());
				System.exit(0);
			}
			Object obj = parser.parse(new FileReader(inFile));
			String outputFileName = auditFileName.replace("audit_", "stats_").replace(".json", ".xls");
			//System.out.println(outputFileName);
			String outputFile = (String) Stats.prop.getProperty("stats.dir") + File.separator + outputFileName;
			FileOutputStream fileOut = new FileOutputStream(outputFile);
			JSONArray entry = (JSONArray) ((HashMap) obj).get("Entities");
			for (int i = 0; i < entry.size(); i++) {
				JSONArray subentry = (JSONArray) entry.get(i);
				for (int j = 0; j < subentry.size(); j++) {
					JSONObject jso = (JSONObject) subentry.get(j);
					filename = (String) jso.get("entityName");
					step = (String) jso.get("processingStep");
					if (step.equalsIgnoreCase("INGESTION")) {
						getIngestionStarttime = (String) jso.get("startDateTime");
						getIngestionEndtime = (String) jso.get("statusDateTime");
						ingestionStatus = (String) jso.get("status");
						ingestionSize=(String) jso.get("fileSize");
						ingestionStarttime = formatTime(getIngestionStarttime);
						ingestionEndtime = formatTime(getIngestionEndtime);
						IngestionTimeTaken = TimeTaken(getIngestionStarttime, getIngestionEndtime);
					} else if (step.equalsIgnoreCase("RECONCILIATION")){
						getReconciliationStarttime = (String) jso.get("startDateTime");
						getReconciliationEndtime = (String) jso.get("statusDateTime");
						reconciliationStatus = (String) jso.get("status");
						reconciliationStarttime = formatTime(getReconciliationStarttime);
						reconciliationEndtime = formatTime(getReconciliationEndtime);
						reconciliationTimeTaken = TimeTaken(getReconciliationStarttime, getReconciliationEndtime);
					}
				}
				completeDurationTaken=CompleteDuration(getIngestionStarttime,getIngestionEndtime,getReconciliationStarttime,getReconciliationEndtime);
				row = sheet.createRow(k++);
				row.createCell(0).setCellValue(filename);
				row.createCell(1).setCellValue(ingestionStarttime);
				row.createCell(2).setCellValue(ingestionEndtime);
				row.createCell(3).setCellValue(ingestionStatus);
				row.createCell(4).setCellValue(IngestionTimeTaken);
				row.createCell(5).setCellValue(reconciliationStarttime);
				row.createCell(6).setCellValue(reconciliationEndtime);
				row.createCell(7).setCellValue(reconciliationStatus);
				row.createCell(8).setCellValue(reconciliationTimeTaken);
				row.createCell(9).setCellValue(completeDurationTaken);
				row.createCell(10).setCellValue(ingestionSize);
				
				String output = filename + "\t" + step + "\t" + ingestionStarttime + "\t" + ingestionEndtime + "\t"
						+ IngestionTimeTaken + "\n";
				//System.out.println(output);
			}
			wb.write(fileOut);
			fileOut.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String TimeTaken(String starttime, String endtime) {
		String timeTaken = null;
		Date d1 = null;
		Date d2 = null;
		try {
			d1 = sdf.parse(starttime);
			d2 = sdf.parse(endtime);
			long diff = d2.getTime() - d1.getTime();
			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			//System.out.println("Time Differance***" + diffHours + ":" + diffMinutes + ":" + diffSeconds);
			timeTaken = diffHours + ":" + diffMinutes + ":" + diffSeconds;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return timeTaken;
	}
	
	private static String CompleteDuration(String ingStarttime, String ingEndtime, String recStarttime, String recEndtime) {
		String CompleteDurationTaken = null;
		Date d1 = null;
		Date d2 = null;
		Date d3 = null;
		Date d4 = null;
		try {
			d1 = sdf.parse(ingStarttime);
			d2 = sdf.parse(ingEndtime);
			d3 = sdf.parse(recStarttime);
			d4 = sdf.parse(recEndtime);
			long ingestiondiff = d2.getTime() - d1.getTime();
			long recdiff = d4.getTime() - d3.getTime();
			long completeDuration = ingestiondiff + recdiff;
			long totalSeconds = completeDuration / 1000 % 60;
			long totalMinutes = completeDuration / (60 * 1000) % 60;
			long totalHours = completeDuration / (60 * 60 * 1000) % 24;
			//System.out.println("Complete Duration***" + totalHours + ":" + totalMinutes + ":" + totalSeconds);
			CompleteDurationTaken = totalHours + ":" + totalMinutes + ":" + totalSeconds;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return CompleteDurationTaken;
	}

	private static String formatTime(String timeToFormat) throws ParseException {

		DateFormat time_format = new SimpleDateFormat("HH:mm:ss");
		Date parse_time;
		parse_time = sdf.parse(timeToFormat);
		String ingestionStarttime = time_format.format(parse_time);
		return ingestionStarttime;
	}
}
