package com.anthem.ingest;
/**
 * This class is a place holder for import DB Connection parameters
 *  Valid types are sqoop or FTP
 */
public class SFTPHDConfig {
	
	public static final String templateType_p = "templatetype";
	public static final String sftpURL_p = "sftpURL"; // jdbc url
	public static final String userName_p = "username"; // user
	// Password in plain text?
	//public static final String password_p = "password"; 
	public static final String connection_p = "connectionfile";
	public static final String hiveURL_p = "hiveURL";
	String templateType = null;
	String sftpURL = null;
	String userName = null;
	String password = null;
	String connectionFile = null;
	String hiveURL = null;
	boolean validHDConfig = false;

	SFTPHDConfig() {
		super();
	}
    /**
     * This method contains all the DB connection
     * parameters of SFTP
     * @param template
     * @param url
     * @param user
     * @param connFile
     * @param hvURL
     * @return
     */
	SFTPHDConfig(String template, String url, String user, String connFile, String hvURL) {
		this.templateType = template;
		this.sftpURL = url;
		this.userName = user;
		//this.password = pwd;
		this.hiveURL = hvURL;
		this.connectionFile = connFile;
		this.validHDConfig = false;
	}

	public void setHiveURL(String hvURL) {
		this.hiveURL = hvURL;
	}

	public String getHiveURL() {
		return this.hiveURL;
	}

	public void setTemplateType(String template) {
		this.templateType = template;
	}

	public String getTemplateType() {
		return this.templateType;
	}

	public void setSftpURL(String url) {
		this.sftpURL = url;
	}

	public String getSftpURL() {
		return this.sftpURL;
	}

	public void setUserName(String usr) {
		this.userName = usr;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setConnectionFile(String connFile) {
		this.connectionFile = connFile;
	}

	public String getConnectionFile() {
		return this.connectionFile;
	}

	public void setValidHDConfig(boolean validDB) {
		this.validHDConfig = validDB;
	}

	public boolean getValidHDConfig() {
		return this.validHDConfig;
	}

	public boolean isValidHDConfig() {
		validateHDConfig();
		return validHDConfig;
	}

	private void validateHDConfig() {
		if (templateType == null || sftpURL == null || userName == null || connectionFile == null
				|| hiveURL == null) {
			validHDConfig = false;
		} else
			validHDConfig = true;

	}

	public String toString() {
		StringBuffer db = new StringBuffer();
		db.append(templateType_p + " : " + templateType + "\n");
		db.append(sftpURL_p + " : " + sftpURL + "\n");
		db.append(userName_p + " : " + userName + "\n");
		//db.append(password_p + " : " + "XXXXXXX" + "\n");
		db.append(connection_p + " : " + "connectionFile" + "\n");
		db.append(hiveURL_p + " : " + hiveURL + "\n");
		db.append("Valid SFTP Config" + " : " + validHDConfig);
		return db.toString();
	}

} // End of Class
