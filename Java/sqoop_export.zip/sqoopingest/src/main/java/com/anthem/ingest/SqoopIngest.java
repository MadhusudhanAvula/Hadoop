package com.anthem.ingest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.ContentSummary;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;
import org.apache.sqoop.Sqoop;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.common.base.Strings;
/**
 * This class defines all the parameters of Sqoop ingestion 
 * 
 */
public class SqoopIngest implements DataIngest {
	public static final boolean debug = DataIngestDriver.debug;
	JSONObject configJson;
	ArrayList<SqoopTableConfig> tableArray = new ArrayList<SqoopTableConfig>();
	SqoopDBConfig dbConfig = new SqoopDBConfig();
	ArrayList<ArrayList<String>> sqoopQueries = new ArrayList<ArrayList<String>>();
	String jsonFileName = null;
	String templateType = null;
	String auditFileName = null;
	String loadTimeStamp =  new SimpleDateFormat("dd-MMM-yyyy HH.mm.ss").format(new java.util.Date());
	static String user;
	static String keyPath;
	static Configuration config = new Configuration();
	static{		
		config.addResource(new Path(DataIngestDriver.coreSite));
		config.addResource(new Path(DataIngestDriver.hdfsSite));
		config.addResource(new Path(DataIngestDriver.mapredSite));
		config.addResource(new Path(DataIngestDriver.yarnSite));
		user = DataIngestDriver.principalName;
		keyPath = DataIngestDriver.keyTabFile;
		UserGroupInformation.setConfiguration(config);
	}
	
	/*
	 * Default Constructor
	 */
	SqoopIngest() {
		super();
	}

	public void setConfigJson(JSONObject configJson) {
		this.configJson = configJson;
	}

	public JSONObject getConfigJson() {
		return this.configJson;
	}

	public void setJsonFileName(String fileName) {
		this.jsonFileName = fileName;
	}

	public String getJsonFileName() {
		return this.jsonFileName;
	}

	public void setTemplateType(String tType) {
		this.templateType = tType;
	}

	public String getTemplateType() {
		return this.templateType;
	}
	/**
	 *This method will receive the input as audit json object 
	 *and it will iterate each json object, then it will Validate that
	 * All required  key=value configurations are present
	 * in the JSONObject to perform sqoop ingestion.
	 * @param parser
	 */
	public void loadConfig(String fileName) throws DataIngestException, Exception {
		this.jsonFileName = fileName;
		Date date = new Date();
		String yymmddDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		this.auditFileName = DataIngestDriver.auditDir + File.separator + "audit_" + yymmddDate + "_" + jsonFileName;
		// System.out.println("\n" + "AuditFile Name : " + auditFileName);
		JSONParser parser = new JSONParser();
		JSONObject template = null;
		BufferedReader brd = null;

		try {
			brd = getReader(DataIngestDriver.jsonDir, jsonFileName);
			template = (JSONObject) parser.parse(brd);
		} catch (Exception e) {
			throw new DataIngestException("(Error):", e);
		} finally {
			if (brd != null)
				brd.close();
		}

		loadConfig(template);
	}

	/*
	 * Validate that All required key=value configurations are present in the
	 * JSONObject to perform a sqoop -import
	 */
	private void loadConfig(JSONObject obj) throws DataIngestException {
		this.setConfigJson(obj);
		int i = 0;
		Iterator it = configJson.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			if (configJson.get(pair.getKey()) instanceof JSONArray) {
				JSONArray jsonArray = (JSONArray) configJson.get(pair.getKey());
				Iterator iterator = jsonArray.iterator();
				while (iterator.hasNext()) {
					i++;
					JSONObject table = (JSONObject) iterator.next();
					// System.out.println("Extracting Properties from Table > "
					// + i + " "+ table);
					tableArray.add(getTableProperties(table));
				}

			} else {
				// System.out.println(pair.getKey() + " = " + pair.getValue());
				getDBProperty(pair);
			}

		}
		// dbConfig.validateDBConfig();
		if (!dbConfig.isValidDBConfig()) {
			throw new DataIngestException(
					"Database Connection Configuration Error > (DB Config) " + dbConfig.toString());
		}
		buildSqoopQueries();
		// System.out.println("Data Base Config: " + dbConfig.toString());
	}
	/**
	 * This method contains all the DB properties for 
	 * Sqoop connection.
	 * Based on SqoopDBConfig key value pair, templatetype, username,
	 * password and connectionManager_p will be set into SqoopDBConfig.
	 * @param pair
	 */
	private void getDBProperty(Map.Entry pair) {
		String key = (String) pair.getKey();
		String value = (String) pair.getValue();
		switch (key) {
		case SqoopDBConfig.templateType_p:
			dbConfig.setTemplateType(value);
			this.setTemplateType(value);
			// System.out.println(key + " = " + value);
			break;
		case SqoopDBConfig.userName_p:
			dbConfig.setUserName(value);
			// System.out.println(key + " = " + value);
			break;
		case SqoopDBConfig.connection_p:
			if (value != null) {
				setConnectionProperties(value);
				dbConfig.setConnectionFile(value);
			}
			// System.out.println(key + " = " + value);
			break;
		case SqoopDBConfig.jdbcURL_p:
			dbConfig.setJdbcURL(value);
			// System.out.println(key + " = " + value);
			break;
		case SqoopDBConfig.database_p:
			dbConfig.setDatabase(value);
			// System.out.println(key + " = " + value);
			break;
		case SqoopDBConfig.connectionManager_p:
			dbConfig.setConnectionManager(value);
			// System.out.println(key + " = " + value);
			break;
		case SqoopDBConfig.driver_p:
			dbConfig.setDriver(value);
			// System.out.println(key + " = " + value);
			break;
		case SqoopDBConfig.license_p:
			dbConfig.setLicense(value);
			// System.out.println(key + " = " + value);
			break;
		case SqoopDBConfig.hiveURL_p:
			dbConfig.setHiveURL(value);
			// System.out.println(key + " = " + value);
			break;
		case SqoopDBConfig.jceksalias_p:
			dbConfig.setJceksalias(value);
			break;
		case SqoopDBConfig.jcekslocation_p:
			dbConfig.setJcekslocation(value);
			break;
		default:
			// System.out.println("Did Not Match Ignore");
			break;
		}
	}
	/**
	 * This method contains all the table properties.
	 * @param table
	 * @return
	 */
	private SqoopTableConfig getTableProperties(JSONObject table) {
		SqoopTableConfig tc = new SqoopTableConfig();
		tc.setTableName((String) table.get(SqoopTableConfig.tableName_p));
		tc.setColumns((String) table.get(SqoopTableConfig.columns_p));
		tc.setMaxTimeColumnName((String) table.get(SqoopTableConfig.maxtimecolumnname_p));
		tc.setMapColumnJava((String) table.get(SqoopTableConfig.mapcolumntojavatype_p));
		tc.setHdfsTargetDir((String) table.get(SqoopTableConfig.hdfsTargetDir_p));
		tc.setIncremental((String) table.get(SqoopTableConfig.incremental_p));
		tc.setResourceId((String) table.get(SqoopTableConfig.resourceid_p));
		if (tc.getIncremental() == null) {
			tc.setIncremental("NO");
		}
		try {
			String s = (String) table.get(SqoopTableConfig.nbrOfMappers_p);
			tc.setNbrOfMappers(Integer.parseInt(s));
		} catch (NumberFormatException e) {
			tc.setNbrOfMappers(1);
		}
		tc.setSplitBy((String) table.get(SqoopTableConfig.splitBy_p));
		tc.setDateFormat((String) table.get(SqoopTableConfig.dateFormat_p));
		tc.setPrimaryKey((String) table.get(SqoopTableConfig.primarykeys_p));
		tc.setSelectQuery((String) table.get(SqoopTableConfig.selectquery_p));
		try {
			String s1 = (String) table.get(SqoopTableConfig.importSequence_p);
			tc.setImportSequence(Integer.parseInt(s1));

		} catch (NumberFormatException e) {
			tc.setImportSequence(9999);
		}
		if (tc.getResourceId() != null) {
			tc.setResourceId((String) table.get(SqoopTableConfig.resourceid_p));
		}
		else{
			tc.setResourceId("NA");
		}
		tc.validateTableConfig();
		// System.out.println("Extracted Table Config > " + tc.toString());
		return tc;

	}
	/**
	 * This method will receive the input param as 
	 * database connection and SqoopTableConfig.
	 */
	private void buildSqoopQueries() {
		// sqoopQueries = null;
		int i = 0;
		Iterator<SqoopTableConfig> it = tableArray.iterator();
		while (it.hasNext()) {
			SqoopTableConfig tc = it.next();
			// System.out.println("Original Sequence:" +
			// tc.getImportSequence());
			if (tc.isValidTableConfig())
				i++;
		}

		// System.out.println("Number of Valid Tables " + i);
		if (dbConfig.isValidDBConfig() && i > 0) {
			// sqoopQueries = new String[i];
			Comparator<SqoopTableConfig> comparator = new Comparator<SqoopTableConfig>() {
				public int compare(SqoopTableConfig obj1, SqoopTableConfig obj2) {
					return obj1.getImportSequence() - obj2.getImportSequence();
				}

			}; // Innner Class
			Collections.sort(tableArray, comparator);
			int j = 0;
			ArrayList<String> conn = buildDBConnection();

			Iterator<SqoopTableConfig> it2 = tableArray.iterator();
			while (it2.hasNext()) {
				SqoopTableConfig tc2 = it2.next();
				// System.out.println("Sort Sequence :" +
				// tc2.getImportSequence());
				sqoopQueries.add(buildSqoopQuery(conn, tc2));
				j++;
			}

		}

	}// Method End
	/**
	 * This method consists of parameters for building DB connection.
	 * @
	 * @return
	 */
	private ArrayList<String> buildDBConnection() {
		ArrayList<String> connbfr = new ArrayList<String>();
		connbfr.add("import");
		connbfr.add("-Dmapreduce.job.queuename=bdf_yarn");
		connbfr.add("-Dhadoop.security.credential.provider.path="+dbConfig.getJcekslocation()); 	
		if (!dbConfig.getLicense().equalsIgnoreCase("NONE")) {
			connbfr.add("--libjars");
			connbfr.add(dbConfig.getLicense());
		}
		if(DataIngestDriver.dbtype.equalsIgnoreCase("teradata")){
			connbfr.add("--libjars");
			connbfr.add(DataIngestDriver.homeDir+"/tdgssconfig.jar,"+DataIngestDriver.homeDir+"/terajdbc4.jar");
		}
		//connbfr.add("--verbose");
		connbfr.add("--connect");
		connbfr.add(dbConfig.getJdbcURL());
		if (!dbConfig.getDriver().equalsIgnoreCase("NONE")) {
			connbfr.add("--driver");
			connbfr.add(dbConfig.getDriver());
		}
		if (!dbConfig.getConnectionManager().equalsIgnoreCase("NONE")) {
			connbfr.add("--connection-manager");
			connbfr.add(dbConfig.getConnectionManager());
		}
		connbfr.add("--username");
		connbfr.add(dbConfig.getUserName()); 
		
		connbfr.add("--password-alias");
		connbfr.add(dbConfig.getJceksalias()); 
		 
		return connbfr;

	}
	/**
	 * This method build sqoop query using table properties.
	 * @param conn
	 * @param tbl
	 * @return cmd
	 */
	private ArrayList<String> buildSqoopQuery(ArrayList<String> conn, SqoopTableConfig tbl) {
		ArrayList<String> cmd = new ArrayList<String>();
		for (String obj : conn) {
			cmd.add(obj);
		}

		if (!tbl.getTableName().equalsIgnoreCase("NONE") && !tbl.getColumns().equalsIgnoreCase("NONE") && tbl.getSelectQuery().equalsIgnoreCase("NONE")) {
			cmd.add("--table");
			cmd.add(tbl.getTableName());
			cmd.add("--columns");
			cmd.add(tbl.getColumns());
		}
		if (!tbl.getTableName().equalsIgnoreCase("NONE") && tbl.getColumns().equalsIgnoreCase("NONE") && tbl.getSelectQuery().equalsIgnoreCase("NONE")) {
			cmd.add("--table");
			cmd.add(tbl.getTableName());
			
		}
				
		/*if (!dbConfig.getConnectionManager().equalsIgnoreCase("NONE")
				|| !dbConfig.getDriver().equalsIgnoreCase("NONE")) {
			cmd.add("--relaxed-isolation");
		}*/
		String maxDate = null;
		if (tbl.getIncremental().equalsIgnoreCase("YES")) {
			maxDate = readLastUpdDate(DataIngestDriver.hdfstargetdir + File.separator + DataIngestDriver.category.toLowerCase()+"_"+DataIngestDriver.source.toLowerCase()+"_"+tbl.getTableName().toLowerCase()+File.separator+"lastLoadTime.txt");
		}
		
		if (!tbl.getSelectQuery().equalsIgnoreCase("NONE")) {
			cmd.add("--query");
			if (maxDate != null && tbl.getIncremental().equalsIgnoreCase("YES")) {
				String selectQuery = tbl.getSelectQuery();
				if(DataIngestDriver.dbtype.equalsIgnoreCase("sqlserver")){
					selectQuery = selectQuery 
							+ " AND convert(datetime2," + tbl.getMaxTimeColumnName() +  ")>=" + "convert(datetime2,'" +  maxDate.toString().replace(".", ":") +"')"
							+ " AND convert(datetime2," + tbl.getMaxTimeColumnName() +  ")< " + "convert(datetime2,'" +  loadTimeStamp.toString().replace(".", ":") +"')";
				}
				else if(DataIngestDriver.dbtype.equalsIgnoreCase("teradata")){
					selectQuery = selectQuery 
							+ " AND cast(substr(cast("+tbl.getMaxTimeColumnName()+" as char(26)),1,19) as TIMESTAMP) (TIMESTAMP,FORMAT '"+tbl.getDateFormat()+"') (char(25)) >='" + maxDate.toString()+"'"
							+ " AND cast(substr(cast("+tbl.getMaxTimeColumnName()+" as char(26)),1,19) as TIMESTAMP) (TIMESTAMP,FORMAT '"+tbl.getDateFormat()+"') (char(25)) <'" + loadTimeStamp.toString()+"'";
				}
				else if(DataIngestDriver.dbtype.equalsIgnoreCase("sybase")){
					String oldFmt = "dd-MMM-yyyy HH.mm.ss";
					String newFmt = "MM/dd/yyyy HH:mm:ss.SSSSSS a";
					
					DateFormat fmt = new SimpleDateFormat(oldFmt);
					Date maxDateFmt = null;
					System.out.println("##########" + maxDate + "##########");
					try {
						maxDateFmt = fmt.parse(maxDate.toString());
						System.out.println("##########" + maxDateFmt + "##########");
					} catch (ParseException pe) {					
					}
					
					fmt = new SimpleDateFormat(newFmt);
					System.out.println("##########" + fmt + "##########");
					String maxDateStr = fmt.format(maxDateFmt);
					System.out.println("##########" + maxDateStr + "##########");
					
					
					selectQuery = selectQuery 
							+ " AND " + tbl.getMaxTimeColumnName() +  " >= '" + maxDateStr + "' "
							+ " AND " + tbl.getMaxTimeColumnName() +  " < '" + maxDateStr + "' ";
				}
				else{
					selectQuery = selectQuery 
							+ " AND " + " to_timestamp("+tbl.getMaxTimeColumnName() + ",'"+tbl.getDateFormat()+"')"+ ">=" + "to_timestamp('" + maxDate.toString()+ "','dd-mon-yyyy hh24.mi.ss')"
							+ " AND " + " to_timestamp("+tbl.getMaxTimeColumnName() + ",'"+tbl.getDateFormat()+"')"+ "<" + "to_timestamp('" + loadTimeStamp.toString()+ "','dd-mon-yyyy hh24.mi.ss')";
			
				}
				selectQuery = selectQuery.replaceAll("\\n", "");
				cmd.add(selectQuery);
				
			} else {
				cmd.add(tbl.getSelectQuery());
			}
		}
		
		cmd.add("--target-dir");
		String bPath = null;
		
		bPath = DataIngestDriver.hdfstargetdir + File.separator + DataIngestDriver.category.toLowerCase()+"_"+DataIngestDriver.source.toLowerCase()+"_"+tbl.getTableName().toLowerCase() + File.separator+ DataIngestDriver.fullFileDir;
		
		tbl.setTargetHDFSPath(bPath);
		cmd.add(bPath);

		if (!tbl.getSplitBy().equalsIgnoreCase("NONE")) {
			cmd.add("--split-by");
			cmd.add(tbl.getSplitBy());
		}
		if (!tbl.getMapColumnJava().equalsIgnoreCase("NONE")) {
			cmd.add("--map-column-java");
			cmd.add(tbl.getMapColumnJava());
		}
		cmd.add("--m");
		cmd.add(String.valueOf(tbl.getNbrOfMappers()));
		cmd.add("--as-avrodatafile");
		
		if(!DataIngestDriver.dbtype.equalsIgnoreCase("NONE")){
			cmd.add("--hive-drop-import-delims");	
		}
		
		
		cmd.add("--delete-target-dir");
		cmd.add("--outdir");
		cmd.add(DataIngestDriver.generatedJavaSrc+"/"+tbl.getTableName().toLowerCase());
		
		tbl.setSqoopQuery(cmd.toArray(new String[cmd.size()]));

		return cmd;
	} // End of Method

	public ArrayList<ArrayList<String>> getSqoopQueries() {
		return sqoopQueries;
	}

	public ArrayList<SqoopTableConfig> getTableArrayList() {
		return tableArray;
	}

	public void printConfig() {
		Iterator it = configJson.entrySet().iterator();
		int i = 0;
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			if (configJson.get(pair.getKey()) instanceof JSONArray) {
				JSONArray jsonArray = (JSONArray) configJson.get(pair.getKey());
				System.out.println("Printing JSONArray : " + jsonArray + "\n");
				Iterator iterator = jsonArray.iterator();
				while (iterator.hasNext()) {
					i++;
					JSONObject table = (JSONObject) iterator.next();
					// System.out.println("Table" + i + ":" + table);
				}

			} else {
				System.out.println(pair.getKey() + " = " + pair.getValue());
			}

		}
	}

	public void printRunnable() {
		if (debug) {
			System.out.println("Printing Runnable Configurations : " + this.getClass().getName() + ":" + new Object() {
			}.getClass().getEnclosingMethod().getName() + "\n");
			for (SqoopTableConfig tbl : tableArray) {
				System.out.println(tbl.toString() + "\n");
			}
		} else {
			System.out.println("Please set tool.debug=true in confiuration properties to print runnables.");
		}
	}

	private BufferedReader getReader(String path, String fileName) throws Exception {
		return new BufferedReader(new FileReader(path + File.separator + fileName));
	}
	/**
	 *This method will read the new DataIngestStatus from audit folder location.
	 *@param statusF
	 *@return statusF
	 */
	@SuppressWarnings("deprecation")
	public int run() {
		int statusF = 0;
		DataIngestStatus newSts = new DataIngestStatus(this.templateType, this.auditFileName);
		StringBuilder tableStatus = new StringBuilder();
		String inboundHome=null;

		for (SqoopTableConfig tbl : tableArray) {
			int status = 0;
			//creating paths for schema and audit file creation
			//String localSchemaPath = DataIngestDriver.generatedJavaSrc+"/"+tbl.getTableName().toLowerCase()+"/QueryResult.avsc";
			String schmeFilePathFull=tbl.getTargetHDFSPath();
			int index1=schmeFilePathFull.lastIndexOf('/');			
			String schemaPathTruncate1 = schmeFilePathFull.substring(0,index1);
			int index2=schemaPathTruncate1.lastIndexOf('/');
			//String schemaPathTruncate = schemaPathTruncate1.substring(0,index2)+"/"+tbl.getTableName().toLowerCase()+"_meta";	
			
			//Setting table status path 
			if(Strings.isNullOrEmpty(inboundHome)) {
				inboundHome = schemaPathTruncate1.substring(0,index2);
				
			}
			if (tbl.isValidTableConfig()) {

				if (debug) {
					System.out.println("Running Sqoop.RunTool for Table : " + tbl.getTableName() + "\n");
				}
				DataIngestStatus.IngestStatus st = newSts.new IngestStatus();
				st.entityName = tbl.getTableName();
				st.processingStep = DataIngestDriver.ING;
				st.targetHDFSPath = tbl.getTargetHDFSPath();
				st.incremental = tbl.getIncremental();
				st.startDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
				
				
				//Delete the old Avro schema file for SQOOP to generate the updated schema file
				String delAVSCOld = "rm "+DataIngestDriver.generatedJavaSrc+"/"+tbl.getTableName().toLowerCase()+"/QueryResult.avsc";
				System.out.println("Deleted the old avro schema: "+delAVSCOld);
				try {
					Runtime.getRuntime().exec(delAVSCOld);
				} catch (IOException e) {
					e.printStackTrace();
				}
				//run the sqoop
				status = Sqoop.runTool(tbl.getSqoopQuery(), config);
				
				//temp changes 
				
				//System.out.println("The sqoop status --> "+status);
				//Get load log key from map file and collecting the table status to HDFS for data warehouse to read
				String LoadlogKey = DataIngestDriver.loadLogKey;
				String loadType;
				if(tbl.getIncremental().equalsIgnoreCase("YES")){
					loadType="I";
				}
				else{
					loadType="H";
				}
				tableStatus.append(tbl.getTableName().toString().toLowerCase()+"|"+status+"|"+LoadlogKey+"|"+loadType+"|"+tbl.getPrimaryKey().replaceAll(";", ",")+"|"+tbl.getResourceId()+"\n");
											
				if(status == 0) {
					String fileSize = getFileSize(tbl.getTargetHDFSPath(),config);							
					writeDataToHDFS(schemaPathTruncate1+"/lastLoadTime.txt",tbl.getTableName().toLowerCase()+"|"+loadTimeStamp);
					
					if (debug) {
						System.out.println("FileSize: "+fileSize+" bytes");
					}
					st.fileSize=fileSize+" bytes";

				}
				else {
					System.out.println("Sqoop failed Returned Code : " + Integer.toString(status));
				}

				st.statusDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
				st.returnCode = status;
				st.status = (status == 0) ? "SUCCESS" : "FAIL";
				st.statusDesc = (status == 0) ? "Sqoop Import Successful."
						: "Sqoop Import failed check log for detail.";
				newSts.addStatus(tbl.getTableName() + st.processingStep, st);
			} else {

				if (debug) {
					System.out.println("Skipping Import for Table  : " + tbl.getTableName() + "\n");
				}
				if (!tbl.isValidTableConfig()) {
					DataIngestStatus.IngestStatus st = newSts.new IngestStatus();
					st.entityName = tbl.getTableName();
					st.processingStep = DataIngestDriver.ING;
					st.targetHDFSPath = tbl.getTargetHDFSPath();
					st.incremental = tbl.getIncremental();
					st.startDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
					status = 999;
					st.statusDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
					st.returnCode = status;
					st.status = "INVALID";
					st.statusDesc = "Invalid Configuration : " + tbl.getTableName();
					newSts.addStatus(tbl.getTableName() + st.processingStep, st);

				}
			}
		} // end for tableArray
		
		// Writing the table status to file in HDFS
		writeDataToHDFS(inboundHome+"/tableStatus/"+DataIngestDriver.templateFileName.replace(".json", ".txt"),tableStatus.toString());
		//archive(newSts);
		return statusF = newSts.getHeaderReturnCode();
	} // end of run method

		private void setConnectionProperties(String fileName) {
		try {			
			// load a properties file
			dbConfig.setUserName(DataIngestDriver.dbUserName);
			dbConfig.setJceksalias(DataIngestDriver.pwdAlias);
			dbConfig.setJcekslocation(DataIngestDriver.jceksFileLocation);
			
			if (DataIngestDriver.sourcedbname.equalsIgnoreCase("NONE"))
				dbConfig.setJdbcURL(DataIngestDriver.jdbcURL);
			else
			dbConfig.setJdbcURL(DataIngestDriver.jdbcURL +"/" +DataIngestDriver.sourcedbname);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String getFileSize(String filePath,Configuration config) {
		long size=0;
		String fileSize = null;
		Path path =null;
		FileSystem hdfs=null;
		try {
			path = new Path(filePath);
			hdfs = path.getFileSystem(config);
			ContentSummary summary = hdfs.getContentSummary(path);
			size = (summary!=null)?summary.getLength():0;
			fileSize = String.valueOf(size);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return fileSize;
	}
	private void getAVSCFileToHDFS(String src, String dst,String tblName) {		
		try {
			FileSystem fileSystem = FileSystem.get(config);
			if(!fileSystem.exists(new Path(dst))){
				fileSystem.mkdirs(new Path(dst)); 	
			}
			
			if(fileSystem.exists(new Path(dst+"/"+tblName.toLowerCase()+".avsc"))){
				fileSystem.delete(new Path(dst+"/"+tblName.toLowerCase()+".avsc"), false);
				System.out.println("Old Schema file deleted");
					
			}
			
			fileSystem.copyFromLocalFile(new Path(src), new Path(dst));
			System.out.println("Schema file copied from local to HDFS");
			
			fileSystem.rename(new Path(dst+"/QueryResult.avsc"), new Path(dst+"/"+tblName.toLowerCase()+".avsc"));
			System.out.println("Schema file renamed");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private void writeDataToHDFS(String auditFilePath,String auditContent){
		BufferedWriter br=null;
		FileSystem fileSystem=null;
		try {
			fileSystem = FileSystem.get(config);			
			Path file = new Path(auditFilePath);			
			if ( fileSystem.exists( file )) 
			{ 
				fileSystem.delete( file, true ); 
			} 
			OutputStream os = fileSystem.create(file);
			br = new BufferedWriter( new OutputStreamWriter( os, "UTF-8" ));
			br.write(auditContent);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				br.close();
				fileSystem.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}
	}
	
	private String readLastUpdDate(String auditFilePath){
		FileSystem fileSystem=null;
		String lastModified=null;
		try {
			//changed 12/18/2017 -- removing the authentication as KeyTab is handled through keytab
			//UserGroupInformation.loginUserFromKeytab(user, keyPath);
			Path path = new Path(auditFilePath);			
			fileSystem = path.getFileSystem(config);
			FSDataInputStream inputStream = fileSystem.open(path);
			String inputData = IOUtils.toString(inputStream); 
			System.out.println("Reading the last date modified");
			
			
			String[] splitArray = inputData.split("\\|");
			lastModified= splitArray[1];
			
		    //System.out.println("lastModified --> "+lastModified);
						
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (Exception e) {
			System.out.println("Printing Stack Trace : " + e.getMessage());
		}
		finally{
			try {
				fileSystem.close();
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		return lastModified;
		
	}
	
} // End Of Class
