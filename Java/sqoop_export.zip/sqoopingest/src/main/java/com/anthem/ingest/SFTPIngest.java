
package com.anthem.ingest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.Vector;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.anthem.ingest.DataIngestStatus.IngestStatus;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;

/**
 * This class defines all the parameters of SFTP ingestion.
 */
public class SFTPIngest implements DataIngest {
	public static final boolean debug = DataIngestDriver.debug;
	JSONObject configJson;
	ArrayList<SFTPFileConfig> fileArray = new ArrayList<SFTPFileConfig>();
	SFTPHDConfig hdConfig = new SFTPHDConfig();
	ArrayList<String> sftpCommands = new ArrayList<String>();
	String jsonFileName = null;
	String templateType = null;
	String auditFileName = null;
	Date lastSuccessAuditTime = null;
	SimpleDateFormat gregorainSdf = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
	Map<String, JSONObject> lastFileProcessTimeMap = null;

	/*
	 * Default Constructor
	 */
	SFTPIngest() {
		super();
	}

	public void setConfigJson(JSONObject configJson) {
		this.configJson = configJson;
	}

	public JSONObject getConfigJson() {
		return this.configJson;
	}

	public void setJsonFileName(String fileName) {
		this.jsonFileName = fileName;
	}

	public String getJsonFileName() {
		return this.jsonFileName;
	}

	public void setTemplateType(String tType) {
		this.templateType = tType;
	}

	public String getTemplateType() {
		return this.templateType;
	}

	/**
	 * Loading the json file into json object
	 * 
	 * @param fileName
	 * @return
	 */
	public void loadConfig(String fileName) throws DataIngestException, Exception {
		this.jsonFileName = fileName;
		String yymmddDate = getStrDate(new Date());
		this.auditFileName = DataIngestDriver.auditDir + File.separator + "audit_" + yymmddDate + "_" + jsonFileName;
		Date auditMaxDate = getAuditMaxDate(this.jsonFileName);
		if (auditMaxDate != null) {
			String lastProcessedAuditFile = "audit_" + getStrDate(auditMaxDate) + "_" + this.jsonFileName;
			lastSuccessAuditTime = getLastSuccessAuditTime(DataIngestDriver.auditDir, lastProcessedAuditFile);
			setLastFileProcessTime(DataIngestDriver.auditDir, lastProcessedAuditFile);
			// System.out.println("\n" + "AuditFile Name : " + auditFileName);
		} else {
			lastSuccessAuditTime = new Date();
		}
		JSONParser parser = new JSONParser();
		JSONObject template = null;
		BufferedReader brd = null;

		try {
			brd = getReader(DataIngestDriver.jsonDir, jsonFileName);
			template = (JSONObject) parser.parse(brd);
		} catch (Exception e) {
			throw new DataIngestException("(Error):", e);
		} finally {
			if (brd != null)
				brd.close();
		}

		loadConfig(template, auditMaxDate);
	}

	/*
	 * Validate that All required key=value configurations are present in the
	 * JSONObject to perform a sqoop -import as per BCBSNC design specification
	 */
	private void loadConfig(JSONObject obj, Date auditMaxDate) throws DataIngestException {
		this.setConfigJson(obj);
		int i = 0;
		Iterator it = configJson.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			if (configJson.get(pair.getKey()) instanceof JSONArray) {
				JSONArray jsonArray = (JSONArray) configJson.get(pair.getKey());
				Iterator iterator = jsonArray.iterator();
				while (iterator.hasNext()) {
					i++;
					JSONObject fl = (JSONObject) iterator.next();
					// System.out.println("Extracting Properties from Table > "
					// + i + " "+ table);
					addFileProperties(fl, auditMaxDate);
				}

			} else {
				// System.out.println(pair.getKey() + " = " + pair.getValue());
				getHDProperty(pair);
			}

		}
		// hdConfig.validateDBConfig();
		if (!hdConfig.isValidHDConfig()) {
			throw new DataIngestException("SFTP Configuration Error :  " + hdConfig.toString());
		}
		buildSftpCommands();
		// System.out.println("Data Base Config: " + hdConfig.toString());
	}

	/**
	 * Based on key value pair, templatetype, username, password and sftpURL
	 * will be set into SFTPHDConfig.
	 * 
	 * @param pair
	 */
	private void getHDProperty(Map.Entry pair) {
		String key = (String) pair.getKey();
		String value = (String) pair.getValue();
		switch (key) {
		case SFTPHDConfig.templateType_p:
			hdConfig.setTemplateType(value);
			this.setTemplateType(value);
			// System.out.println(key + " = " + value);
			break;
		case SFTPHDConfig.userName_p:
			hdConfig.setUserName(value);
			// System.out.println(key + " = " + value);
			break;
		// case SFTPHDConfig.password_p:
		// hdConfig.setPassword(value);
		// if (value != null) {
		// hdConfig.setPassword(DataIngestDriver.decryptPwd(value));
		// }
		// System.out.println(key + " = " + value);
		// break;
		case SFTPHDConfig.connection_p:
			if (value != null) {
				setConnectionProperties(value);
				hdConfig.setConnectionFile(value);
			}
			// System.out.println(key + " = " + value);
			break;
		case SFTPHDConfig.sftpURL_p:
			hdConfig.setSftpURL(value);
			// System.out.println(key + " = " + value);
			break;
		case SFTPHDConfig.hiveURL_p:
			hdConfig.setHiveURL(value);
			break;

		default:
			// System.out.println("Did Not Match Ignore");
			break;
		}
	}

	public String decryptPwd(String value) {
		try {
			return new EncryptDecryptUtil().decrypt(value);
		} catch (Exception e) {
			if (debug) {
				System.out.println("Could NOT decrypt Password : " + value);
			}

			return null;
		}
	}

	/**
	 * This method will receive a json object as input field The file date will
	 * be calculated based on number of days ago and current day.
	 * 
	 * @param file
	 */
	private void addFileProperties(JSONObject file, Date auditMaxDate) {
		String src = (String) file.get(SFTPFileConfig.sftpSrcFile_p);
		ArrayList<String> lst = new ArrayList<String>();
		boolean isFileExist = false;
		String lastFileProcessTime = null;
		String status = null;
		long n = DataIngestDriver.nbrofDays;
		Date date = new Date();
		Date daysAgo = new Date(date.getTime() - n * 24 * 3600 * 1000);
		String fDate = new SimpleDateFormat("yyyyMMdd").format(daysAgo);
		// fDate = "20170411";
		// System.out.println("Current Date :" + fDate);
		if (src.contains("*")) {
			String bldSrc = null;
			String user = hdConfig.getUserName();
			// String pwd = hdConfig.getPassword();
			String url = hdConfig.getSftpURL();
			String dir = (String) file.get(SFTPFileConfig.sftpSrcDir_p);
			if (dir.equalsIgnoreCase(File.separator)) {
				bldSrc = dir + src;
			} else {
				bldSrc = dir + File.separator + src;
			}

			JSONObject lastFileProcessTimeObject = (lastFileProcessTimeMap != null)
					? lastFileProcessTimeMap.get((String) file.get(SFTPFileConfig.tableName_p)) : null;
			if (lastFileProcessTimeObject != null) {
				lastFileProcessTime = (String) lastFileProcessTimeObject.get("lastFileProcessTime");
				status = (String) lastFileProcessTimeObject.get("status");
			}
			Date fileProcessTime = (lastFileProcessTimeObject != null) ? getDate(lastFileProcessTime) : new Date();
			JSch jsch = new JSch();
			Session session = null;
			String sshPath = null;
			Date currentDate = null;
			try {
				currentDate = convertDate(getStrDate(new Date()));
				sshPath = DataIngestDriver.sshDir;
				jsch.addIdentity(sshPath);
				session = jsch.getSession(user, url);
				session.setConfig("StrictHostKeyChecking", "no");
				session.connect();
				Channel channel = session.openChannel("sftp");
				channel.connect();
				ChannelSftp sftpChannel = (ChannelSftp) channel;
				Vector<ChannelSftp.LsEntry> v = sftpChannel.ls(bldSrc);
				for (ChannelSftp.LsEntry e : v) {
					String strFileDate = e.getAttrs().getMtimeString();
					Date fileDate = formatDate(strFileDate);
					if (fileDate != null && fileDate.compareTo(fileProcessTime) > 0) {
						lst.add(e.getFilename());
						isFileExist = true;
					}

					// if(e.getFilename().contains(fDate))
					// lst.add(e.getFilename());run
				}
				sftpChannel.exit();
			} catch (JSchException e) {
				System.err.println("Error in SFTP :" + e.getMessage());
				System.out.println("Error in SFTP :" + e.getMessage());
			} catch (SftpException e) {
				System.err.println("Error in SFTP :" + e.getMessage());
				System.out.println("Error in SFTP :" + e.getMessage());
			} finally {
				session.disconnect();
			}
			//For restartability functionality (on the same day), This condition is added to skip for the files which is SUCCESS, 	 
		//	and check the existence of the file in the source and add in the lst.
			if (!(currentDate.compareTo(auditMaxDate) == 0 && status.equalsIgnoreCase("SUCCESS"))) {
				if (!isFileExist)
					lst.add(src.replace("*", " "));
			}
		} else {
			lst.add(src);
		}

		lst.sort(String::compareToIgnoreCase);
		String incremental = (String) file.get(SFTPFileConfig.incremental_p);
		List<String> sortedFileList = null;
		if (lst != null && lst.size() > 0 && incremental.equalsIgnoreCase("NO")) {
			String fileName = lst.get(lst.size() - 1);
			sortedFileList = new ArrayList<String>();
			sortedFileList.add(fileName);
		} else {
			sortedFileList = lst;
		}
		for (String x : sortedFileList) {

			SFTPFileConfig tc = new SFTPFileConfig();
			tc.setSftpSrcDir((String) file.get(SFTPFileConfig.sftpSrcDir_p));
			tc.setSftpSrcFile(x);
			tc.setHdfsTargetDir((String) file.get(SFTPFileConfig.hdfsTargetDir_p));
			tc.setIncremental((String) file.get(SFTPFileConfig.incremental_p));
			tc.setHiveScript(
					DataIngestDriver.scriptsDir + File.separator + (String) file.get(SFTPFileConfig.hiveScript_p));
			tc.setPreProcessScript((String) file.get(SFTPFileConfig.preProcessScript_p));
			tc.setTableName((String) file.get(SFTPFileConfig.tableName_p));
			tc.setFileType((String) file.get(SFTPFileConfig.fileType_p));
			tc.setIssueType((String) file.get(SFTPFileConfig.issueType_p));
			tc.setHdfsStageDir((String) file.get(SFTPFileConfig.hdfsStageDir_p));
			if (tc.getIncremental() == null) {
				tc.setIncremental("NO");
			}
			tc.setLocalDir((String) file.get(SFTPFileConfig.localDir_p));
			try {
				String s1 = (String) file.get(SFTPFileConfig.importSequence_p);
				tc.setImportSequence(Integer.parseInt(s1));

			} catch (NumberFormatException e) {
				tc.setImportSequence(9999);
			}
			tc.validateFileConfig();
			// System.out.println("Test Extracted Config > " + tc.toString());
			fileArray.add(tc);
		}
	}

	/**
	 * This method will receive the input parameters as sftp connection and
	 * SFTPFileConfig.
	 */
	private void buildSftpCommands() {
		// sqoopQueries = null;
		int i = 0;
		Iterator<SFTPFileConfig> it = fileArray.iterator();
		while (it.hasNext()) {
			SFTPFileConfig tc = it.next();
			// System.out.println("Original Sequence:" +
			// tc.getImportSequence());
			if (tc.isValidFileConfig())
				i++;
		}

		// System.out.println("Number of Valid Tables " + i);
		if (hdConfig.isValidHDConfig() && i > 0) {
			// sqoopQueries = new String[i];
			Comparator<SFTPFileConfig> comparator = new Comparator<SFTPFileConfig>() {
				public int compare(SFTPFileConfig obj1, SFTPFileConfig obj2) {
					return obj1.getImportSequence() - obj2.getImportSequence();
				}

			}; // Innner Class
			Collections.sort(fileArray, comparator);
			int j = 0;
			String conn = buildHDConnection();

			Iterator<SFTPFileConfig> it2 = fileArray.iterator();
			while (it2.hasNext()) {
				SFTPFileConfig tc2 = it2.next();
				// System.out.println("Sort Sequence :" +
				// tc2.getImportSequence());
				sftpCommands.add(buildSftpCommand(conn, tc2));
				j++;
			}

		}

	}// Method End

	private String buildHDConnection() {
		// This is NOT used because we are NOT running command line anymore
		StringBuffer connbfr = new StringBuffer();
		connbfr.append("sftp -C ");
		connbfr.append(hdConfig.getUserName() + "@" + hdConfig.getSftpURL());
		return connbfr.toString();

	}

	private String buildSftpCommand(String conn, SFTPFileConfig fl) {
		// This is NOT used because we are NOT running command line anymore but
		// it's required to populate SFTP file Config Values
		StringBuffer cmd = new StringBuffer(conn + ": ");

		if (fl.getSftpSrcDir().equalsIgnoreCase(File.separator)) {
			fl.setSftpSrcPath(fl.getSftpSrcDir() + fl.getSftpSrcFile());
			cmd.append(fl.getSftpSrcDir() + fl.getSftpSrcFile() + " ");
		} else {
			fl.setSftpSrcPath(fl.getSftpSrcDir() + File.separator + fl.getSftpSrcFile());
			cmd.append(fl.getSftpSrcDir() + File.separator + fl.getSftpSrcFile() + " ");
		}
		if (fl.getLocalDir().equalsIgnoreCase(File.separator)) {

			fl.setLocalSrcPath(fl.getLocalDir() + fl.getSftpSrcFile());
			cmd.append(fl.getLocalDir() + fl.getSftpSrcFile());
		} else {
			fl.setLocalSrcPath(fl.getLocalDir() + File.separator + fl.getSftpSrcFile());
			cmd.append(fl.getLocalDir() + File.separator + fl.getSftpSrcFile());
		}
		if (fl.getIncremental().equalsIgnoreCase("NO")) {

			fl.setTargetHDFSPath(fl.getHdfsTargetDir() + File.separator + DataIngestDriver.fullFileDir + File.separator
					+ fl.getSftpSrcFile());
		} else {
			fl.setTargetHDFSPath(fl.getHdfsTargetDir() + File.separator + DataIngestDriver.incFileDir + File.separator
					+ fl.getSftpSrcFile());
		}
		fl.setArchivePath(fl.getHdfsTargetDir() + File.separator + DataIngestDriver.arcFileDir + File.separator
				+ new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
		fl.setSftpCmd(cmd.toString());
		return cmd.toString();
		// System.out.println("Sqoop Query : " + cmd.toString() + "\n");

	} // End of Method

	public ArrayList<String> getSftpCommands() {
		return sftpCommands;
	}

	public ArrayList<SFTPFileConfig> getFileArrayList() {
		return fileArray;
	}

	public void printConfig() {
		Iterator it = configJson.entrySet().iterator();
		int i = 0;
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			if (configJson.get(pair.getKey()) instanceof JSONArray) {
				JSONArray jsonArray = (JSONArray) configJson.get(pair.getKey());
				System.out.println("Printing JSONArray : " + jsonArray + "\n");
				Iterator iterator = jsonArray.iterator();
				while (iterator.hasNext()) {
					i++;
					JSONObject table = (JSONObject) iterator.next();
					// System.out.println("Table" + i + ":" + table);
				}

			} else {
				System.out.println(pair.getKey() + " = " + pair.getValue());
			}

		}
	}

	public void printRunnable() {
		if (debug) {
			System.out.println("Printing Runnable Configurations : " + this.getClass().getName() + ":" + new Object() {
			}.getClass().getEnclosingMethod().getName() + "\n");
			for (SFTPFileConfig fl : fileArray) {
				System.out.println(fl.toString() + "\n");
			}
		} else {
			System.out.println("Please set tool.debug=true in confiuration properties to print runnables.");
		}
	}

	private BufferedReader getReader(String path, String fileName) throws Exception {
		return new BufferedReader(new FileReader(path + File.separator + fileName));
	}

	/**
	 * This method will read the new DataIngestStatus from audit folder
	 * location.
	 */
	public int run() {
		int statusF = 0;
		String lastFileProcessTime = null;
		DataIngestStatus newSts = new DataIngestStatus(this.templateType, this.auditFileName);
		boolean reRun = checkLastRun();
		if (reRun)
			newSts = loadStatusFromJSON(this.templateType, this.auditFileName);
		newSts.setLastSuccessAuditTime(this.lastSuccessAuditTime);
		Configuration config = new Configuration();
		config.addResource(new Path(DataIngestDriver.coreSite));
		config.addResource(new Path(DataIngestDriver.hdfsSite));
		config.addResource(new Path(DataIngestDriver.yarnSite));
		config.addResource(new Path(DataIngestDriver.mapredSite));
		// System.out.println("");
		// System.out.println( "Principal Authentication:");
		// System.out.println("");
		String user = DataIngestDriver.principalName;
		String keyPath = DataIngestDriver.keyTabFile;
		UserGroupInformation.setConfiguration(config);
		try {
			UserGroupInformation.loginUserFromKeytab(user, keyPath);
		} catch (Exception e) {
			System.out.println("Printing Stack Trace : " + e.getMessage());
		}
		for (SFTPFileConfig tbl : fileArray) {

			int status = 0;
			if (tbl.isValidFileConfig() && checkAuditStatus(tbl, newSts, DataIngestDriver.ING)) {

				if (debug) {
					System.out.println("Running Ingest for File : " + tbl.getSftpSrcFile() + "\n");
				}
				DataIngestStatus.IngestStatus st = newSts.new IngestStatus();
				st.entityName = tbl.getSftpSrcFile();
				st.tableName = tbl.getTableName();
				st.processingStep = DataIngestDriver.ING;
				st.targetHDFSPath = tbl.getTargetHDFSPath();
				st.incremental = tbl.getIncremental();

				st.startDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

				status = runSFTP(tbl, config, st);

				if (status != 0) {
					System.out.println("SFTP failed Returned Code : " + Integer.toString(status));
					System.out.println("Pre process failed Returned Code : " + Integer.toString(status));
				}

				JSONObject lastFileProcessTimeObject = (lastFileProcessTimeMap != null)
						? lastFileProcessTimeMap.get(tbl.getTableName()) : null;
				if (lastFileProcessTimeObject != null) {
					lastFileProcessTime = (String) lastFileProcessTimeObject.get("lastFileProcessTime");
				}
				if (status == 0) {
					st.setLastFileProcessTime(new Date().toString());
				} else if (status != 0 && lastFileProcessTime != null) {
					st.setLastFileProcessTime(lastFileProcessTime);
				} else {
					st.setLastFileProcessTime(new Date().toString());
				}

				st.statusDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
				st.returnCode = status;
				st.status = (status == 0) ? "SUCCESS" : "FAIL";
				st.statusDesc = (status == 0) ? "SFTP Ingest Successful." : "SFTP Ingest failed check log for detail.";
				newSts.addStatus(tbl.getSftpSrcFile() + st.processingStep, st);
			} else {

				if (debug) {
					System.out.println("Skipping Ingest for File  : " + tbl.getSftpSrcFile() + "\n");
				}
				if (!tbl.isValidFileConfig()) {
					DataIngestStatus.IngestStatus st = newSts.new IngestStatus();
					st.entityName = tbl.getSftpSrcFile();
					st.tableName = tbl.getTableName();
					st.processingStep = DataIngestDriver.ING;
					st.targetHDFSPath = tbl.getTargetHDFSPath();
					st.incremental = tbl.getIncremental();
					st.startDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
					status = 999;
					st.statusDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
					st.returnCode = status;
					st.status = "INVALID";
					st.statusDesc = "Invalid Configuration : " + tbl.getSftpSrcFile();
					newSts.addStatus(tbl.getSftpSrcFile() + st.processingStep, st);

				}
			}
		} // end for fileArray

		newSts.writeAuditToFile();
		reconcile(newSts);
		String statAuditFileName = auditFileName.substring(auditFileName.lastIndexOf(File.separator) + 1,
				auditFileName.length());
		Stats.generateStats(statAuditFileName);
		return statusF = newSts.getHeaderReturnCode();

	} // end of run method

	/**
	 * This method used to run the renconcile logic for delta loads.
	 * 
	 * @param stsObj
	 */
	private void reconcile(DataIngestStatus stsObj) {
		String lastFileProcessTime = null;
		Configuration config = new Configuration();
		config.addResource(new Path(DataIngestDriver.coreSite));
		config.addResource(new Path(DataIngestDriver.hdfsSite));
		config.addResource(new Path(DataIngestDriver.yarnSite));
		config.addResource(new Path(DataIngestDriver.mapredSite));
		// System.out.println("");
		// System.out.println( "Principal Authentication:");
		// System.out.println("");
		String user = DataIngestDriver.principalName;
		String keyPath = DataIngestDriver.keyTabFile;
		UserGroupInformation.setConfiguration(config);
		try {
			UserGroupInformation.loginUserFromKeytab(user, keyPath);
		} catch (Exception e) {
			System.out.println("Printing Stack Trace : " + e.getMessage());
		}

		for (SFTPFileConfig tbl : fileArray) {
			int status = 0;
			if (tbl.isValidFileConfig() && checkAuditStatus(tbl, stsObj, DataIngestDriver.REC)
					&& checkIngestStatus(tbl, stsObj, DataIngestDriver.ING)) {

				if (debug) {
					System.out.println("Running Reconciliation  for File : " + tbl.getSftpSrcFile() + "\n\n");
				}

				DataIngestStatus.IngestStatus st = stsObj.new IngestStatus();
				st.entityName = tbl.getSftpSrcFile();
				st.tableName = tbl.getTableName();
				st.processingStep = DataIngestDriver.REC;
				st.targetHDFSPath = tbl.getTargetHDFSPath();
				st.incremental = tbl.getIncremental();
				st.startDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

				if (status == 0 && !tbl.getPreProcessScript().equalsIgnoreCase("NONE")) {
					String fileType = tbl.getIncremental().equalsIgnoreCase("Yes") ? "incremental" : "input";
					status = executePreprocessScript(tbl.preProcessScript, tbl.getTableName(), tbl.getIssueType(),
							fileType, tbl.getSftpSrcFile());
				}

				/*
				 * if(!tbl.getPreProcessScript().equalsIgnoreCase("NONE"))
				 * status=copyFromStageToHdfsTarget(tbl, config);
				 */
				if (status == 0)
					status = runHive(tbl);

				if (status != 0) {
					System.out.println("Reconciliation failed Returned Code : " + Integer.toString(status));
				}

				JSONObject lastFileProcessTimeObject = (lastFileProcessTimeMap != null)
						? lastFileProcessTimeMap.get(tbl.getTableName()) : null;
				if (lastFileProcessTimeObject != null) {
					lastFileProcessTime = (String) lastFileProcessTimeObject.get("lastFileProcessTime");
				}

				if (status == 0) {
					st.setLastFileProcessTime(new Date().toString());
				} else if (status != 0 && lastFileProcessTime != null) {
					st.setLastFileProcessTime(lastFileProcessTime);
				} else {
					st.setLastFileProcessTime(new Date().toString());
				}

				st.statusDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
				st.returnCode = status;
				st.status = (status == 0) ? "SUCCESS" : "FAIL";
				st.statusDesc = (status == 0) ? "File Reconciliation Successful."
						: "File Recoinciliation failed check log for detail.";
				stsObj.addStatus(tbl.getSftpSrcFile() + st.processingStep, st);
			} else {

				if (debug) {
					System.out.println("Skipping Reconcialiation for File  : " + tbl.getSftpSrcFile() + "\n");
				}

			}
			archive(stsObj, tbl);
		}
		stsObj.writeAuditToFile();
		// archive(stsObj);
	}

	private void archive(DataIngestStatus stsObj, SFTPFileConfig tbl) {
		String lastFileProcessTime = null;
		Configuration config = new Configuration();
		config.addResource(new Path(DataIngestDriver.coreSite));
		config.addResource(new Path(DataIngestDriver.hdfsSite));
		config.addResource(new Path(DataIngestDriver.yarnSite));
		config.addResource(new Path(DataIngestDriver.mapredSite));
		// System.out.println("");
		// System.out.println( "Principal Authentication:");
		// System.out.println("");
		String user = DataIngestDriver.principalName;
		String keyPath = DataIngestDriver.keyTabFile;
		UserGroupInformation.setConfiguration(config);
		try {
			UserGroupInformation.loginUserFromKeytab(user, keyPath);
		} catch (Exception e) {
			System.out.println("Printing Stack Trace : " + e.getMessage());
		}

		// for (SFTPFileConfig tbl : fileArray) {
		int status = 0;
		if (tbl.isValidFileConfig() && checkAuditStatus(tbl, stsObj, DataIngestDriver.ARC)
				&& checkIngestStatus(tbl, stsObj, DataIngestDriver.REC)) {

			if (debug) {
				System.out.println("Running Archive for File : " + tbl.getSftpSrcFile() + "\n\n");
			}

			DataIngestStatus.IngestStatus st = stsObj.new IngestStatus();
			st.entityName = tbl.getSftpSrcFile();
			st.tableName = tbl.getTableName();
			st.processingStep = DataIngestDriver.ARC;
			st.targetHDFSPath = tbl.getTargetHDFSPath();
			st.incremental = tbl.getIncremental();
			st.startDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

			status = runArchive(tbl, config);

			if (status != 0) {
				System.out.println("Archive failed Returned Code : " + Integer.toString(status));
			}

			JSONObject lastFileProcessTimeObject = (lastFileProcessTimeMap != null)
					? lastFileProcessTimeMap.get(tbl.getTableName()) : null;
			if (lastFileProcessTimeObject != null) {
				lastFileProcessTime = (String) lastFileProcessTimeObject.get("lastFileProcessTime");
			}

			if (status == 0) {
				st.setLastFileProcessTime(new Date().toString());
			} else if (status != 0 && lastFileProcessTime != null) {
				st.setLastFileProcessTime(lastFileProcessTime);
			} else {
				st.setLastFileProcessTime(new Date().toString());
			}

			st.statusDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
			st.returnCode = status;
			st.status = (status == 0) ? "SUCCESS" : "FAIL";
			st.statusDesc = (status == 0) ? "File Archive Successful." : "File Archive failed check log for detail.";
			stsObj.addStatus(tbl.getSftpSrcFile() + st.processingStep, st);
		} else {
			if (debug) {
				System.out.println("Skipping Archive for File  : " + tbl.getSftpSrcFile() + "\n");
			}

		}
		// }
		stsObj.writeAuditToFile();

	}

	/**
	 * This method used to transfer the data to archive path.
	 * 
	 * @param file
	 * @param config
	 * @return
	 */
	private int runArchive(SFTPFileConfig file, Configuration config) {
		int status = 0;
		String fileName = file.getSftpSrcFile();
		String fileExtention = getFileNameExtension(fileName);
		int firstDotIndex = fileName.indexOf(".");
		if (firstDotIndex > -1) {
			int secondDotIndex = fileName.indexOf(".", fileName.indexOf(".") + 1);
			if (secondDotIndex == -1 && "Z".equalsIgnoreCase(fileExtention)) {
				fileName = fileName.substring(0, firstDotIndex);
			} else if (secondDotIndex > -1) {
				fileName = fileName.substring(0, fileName.indexOf(".", firstDotIndex + 1));
			}
		}
		String src = null;
		String dst = file.getArchivePath() + File.separator + fileName;
		if (file.getIncremental().equalsIgnoreCase("NO")) {
			src = file.getHdfsTargetDir() + File.separator + DataIngestDriver.fullFileDir + File.separator + fileName;
		} else {
			src = file.getHdfsTargetDir() + File.separator + DataIngestDriver.incFileDir + File.separator + fileName;
		}

		if (debug)
			System.out.println("Copy from : " + src);
		if (debug)
			System.out.println("Copy to : " + dst);

		FileSystem fileSystem = null;
		try {
			fileSystem = FileSystem.get(config);
			Path srcPath = new Path(src);
			Path dstPath = new Path(dst);
			boolean sts = FileUtil.copy(fileSystem, srcPath, fileSystem, dstPath, true, true, config);
			if (debug)
				System.out.println("File " + file.getSftpSrcFile() + " archived  to " + dst + " : " + sts + "\n");
			if (!sts) {
				status = -1;
			}
		} catch (Exception e) {
			status = -1;
			System.out.println("Exception caught! :" + e + "\n");
		} finally {
			try {
				if (fileSystem != null)
					fileSystem.close();
			} catch (Exception e) {
				;
			}
		}
		return status;
	}

	/**
	 * By executing hive script Data will be loaded into hive table
	 * 
	 * @param file
	 * @return status
	 */

	private int runHive(SFTPFileConfig file) {
		int status = -1;
		String hiveScript = file.getHiveScript();
		try {
			Class.forName("org.apache.hive.jdbc.HiveDriver");
			Connection con = DriverManager.getConnection(hdConfig.getHiveURL());
			Statement stmt = con.createStatement();
			String content = new Scanner(new File(hiveScript)).useDelimiter("\\Z").next().trim();
			String[] commands = content.split(";");
			for (String command : commands) {
				if (command.trim() != "") {
					if (debug)
						System.out.println("running command: " + command);
					stmt.execute(command);
				}
			}
			status = 0;
			con.close();
		} catch (Exception e) {
			System.out.println("Reconcile Hive Script Failed : " + e.getMessage());
		}
		return status;
	}

	/**
	 * Fetching files from sftp server and loading into hdfs file system
	 * 
	 * @param f1
	 * @param config
	 * @return status
	 */

	private boolean checkIngestStatus(SFTPFileConfig tbl, DataIngestStatus old, String step) {
		boolean runIT = false;
		if (old != null) {
			DataIngestStatus.IngestStatus ingest = old.getStatus(tbl.getSftpSrcFile() + step);
			if (ingest != null && ingest.returnCode == 0) {
				runIT = true;
			}
		}
		return runIT;
	}

	/**
	 * Fetching files from sftp server and loading into hdfs file system
	 * 
	 * @param f1
	 * @param config
	 * @return status
	 */

	private int runSFTP(SFTPFileConfig fl, Configuration config, DataIngestStatus.IngestStatus st) {
		int status = 0;

		String srcFile = fl.getSftpSrcPath();
		String localFile = fl.getLocalSrcPath();
		JSch jsch = new JSch();
		Session session = null;
		String sshPath = null;
		try {
			sshPath = DataIngestDriver.sshDir;
			jsch.addIdentity(sshPath);
			session = jsch.getSession(hdConfig.getUserName(), hdConfig.getSftpURL());
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();

			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;

			SftpATTRS sftpAttr = sftpChannel.lstat(srcFile);
			String fileSize = String.valueOf(sftpAttr.getSize());
			st.fileSize = fileSize + " bytes";

			sftpChannel.get(srcFile, localFile);
			sftpChannel.exit();
			session.disconnect();
			if (debug)
				System.out.println("Source File " + srcFile + " successfully Copied to " + localFile + "\n");
		} catch (JSchException e) {
			status = -1;
			System.out.println("Copy from SFTP to Local Failed : " + e.getMessage() + "\n");
			System.out.println("Copy from SFTP to Local Failed : " + e.getMessage() + "\n");
		} catch (SftpException e) {
			status = -2;
			System.out.println("Copy from SFTP to Local Failed : " + e.getMessage() + srcFile + "\n");
			System.out.println("Copy from SFTP to Local Failed : " + e.getMessage() + srcFile + "\n");
		} finally {
			try {
				session.disconnect();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (status == 0) {
			String src = fl.getLocalSrcPath();
			String dst = null;
			if (fl.getPreProcessScript().equalsIgnoreCase("NONE")) {
				dst = fl.getTargetHDFSPath();
			} else {
				dst = fl.getHdfsStageDir() + File.separator + fl.getSftpSrcFile();
			}
			FileSystem fileSystem = null;
			try {
				fileSystem = FileSystem.get(config);
				Path srcPath = new Path(src);
				Path dstPath = new Path(dst);
				// Check if the file already exists
				if (fileSystem.exists(dstPath)) {
					System.out.println("File " + dstPath + " already exists , will be overridden. \n");
				}
				// Get the filename out of the file path
				String filename = src.substring(src.lastIndexOf('/') + 1, src.length());

				// fileSystem.copyFromLocalFile(srcPath, dstPath);
				fileSystem.copyFromLocalFile(true, true, srcPath, dstPath);
				if (debug)
					System.out.println("File " + filename + " Copied to " + dst + "\n");
			} catch (Exception e) {
				status = -3;
				System.out.println("Exception caught! :" + e + "\n");
			} finally {
				try {
					if (fileSystem != null)
						fileSystem.close();
				} catch (Exception e) {
					;
				}
			}
		}
		return status;
	}

	/**
	 * Checking json template ingestion is successfull or not
	 * 
	 * @param f1
	 * @param old
	 * @param step
	 * @return runIT
	 */
	private boolean checkAuditStatus(SFTPFileConfig tbl, DataIngestStatus old, String step) {
		boolean runIT = true;
		if (old != null) {
			DataIngestStatus.IngestStatus ingest = old.getStatus(tbl.getSftpSrcFile() + step);
			if (ingest != null && ingest.returnCode == 0) {
				runIT = false;
			}
		}
		return runIT;
	}

	private DataIngestStatus.IngestStatus getOLDStatus(SFTPFileConfig tbl, DataIngestStatus old, String step) {
		DataIngestStatus.IngestStatus ingest = null;

		if (old != null)
			ingest = old.getStatus(tbl.getSftpSrcFile() + step);
		if (ingest == null) {
			DataIngestStatus.IngestStatus st = new DataIngestStatus().new IngestStatus();
			st.entityName = tbl.getSftpSrcFile();
			st.processingStep = step;
			st.targetHDFSPath = tbl.getTargetHDFSPath();
			st.incremental = tbl.getIncremental();
			st.startDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
			st.statusDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
			st.returnCode = 998;
			st.status = "INVALID";
			st.statusDesc = "Configuration NOT found for : " + tbl.getSftpSrcFile();
			ingest = st;
		}
		return ingest;
	}

	/**
	 * This method is used to check the json that ran current day
	 * 
	 * @return runflag
	 */
	private boolean checkLastRun() {
		boolean runFlag = false;
		File f = new File(this.auditFileName);
		if (f.exists() && !f.isDirectory()) {
			runFlag = true;
		}
		if (debug)
			System.out.println("\nFile " + this.auditFileName + " exists ? " + runFlag);
		return runFlag;
	}

	/**
	 * Loading status from json to DataIngestStatus
	 * 
	 * @param tType
	 * @param auditFile
	 * @return ingObj
	 */
	private DataIngestStatus loadStatusFromJSON(String tType, String auditFile) {
		DataIngestStatus ingObj = null;
		try {
			ingObj = new DataIngestStatus().loadStatusFromJSON(tType, auditFile);
		} catch (DataIngestException e) {
			if (debug)
				System.out.println("Error in loadStatusFromJSON : " + e.getMessage());
		}
		return ingObj;
	}

	/**
	 * This method is used to execute preprocess shell script which will do the
	 * additional validation(unzip files,convert to ASCII format..etc)
	 * 
	 * @param preprocessScript
	 * @param tableName
	 * @param issueType
	 * @return
	 */
	private int executePreprocessScript(String preprocessScript, String tableName, String issueType, String fileType,
			String fileName) {
		int status = 0;
		try {
			Runtime runTime = Runtime.getRuntime();
			if (debug)
				System.out.println("Preprocess  Script:" + preprocessScript + " ,Table Name: " + tableName
						+ " ,Issue Type: " + issueType + " File Type: " + fileType + "File Name: " + fileName);
			String cmd[] = { preprocessScript, tableName, issueType, fileType, fileName };
			Process process = runTime.exec(cmd);
			process.waitFor();
			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

			String line = null;
			StringBuilder cmdOutput = new StringBuilder();
			while ((line = reader.readLine()) != null) {
				cmdOutput.append(line + "\n");
			}
			System.out.println(cmdOutput);
		} catch (Exception e) {
			status = -3;
			System.out.println("Exception caught! :" + e + "\n");
		}
		return status;
	}

	/**
	 * Converting string date to Util date
	 * 
	 * @param strDate
	 * @return date
	 */
	private Date formatDate(String strDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
		Date date = null;
		try {
			date = sdf.parse(strDate);
		} catch (java.text.ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	private void setConnectionProperties(String fileName) {
		Properties prop = null;
		FileInputStream fileInputStream = null;
		String connectionPath;
		try {
			connectionPath = DataIngestDriver.connDir + File.separator + fileName;
			fileInputStream = new FileInputStream(connectionPath);
			prop = new Properties();
			// load a properties file
			prop.load(fileInputStream);
			hdConfig.setUserName(prop.getProperty("username"));
			// String password = prop.getProperty("password");
			// if (password != null) {
			// hdConfig.setPassword(DataIngestDriver.decryptPwd(password));
			// }
			hdConfig.setSftpURL(prop.getProperty("sftpURL"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Date getAuditMaxDate(String jsonFileName) {
		Date currentDate = null;
		Calendar calendarInstance = null;
		String strCurrentDate = null;
		String auditDir = null;
		try {
			// calendarInstance = Calendar.getInstance();
			// currentDate = calendarInstance.getTime();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			// strCurrentDate = sdf.format(currentDate);
			auditDir = DataIngestDriver.auditDir;
			File auditFile = new File(auditDir);
			if (!auditFile.exists())
				if (debug)
					System.out.println(auditDir + " Directory doesn't exists");
			File[] listFiles = auditFile.listFiles(new MyFileNameFilter(jsonFileName));
			if (debug)
				System.out.println(" Number of the files in directory " + listFiles.length);
			if (listFiles.length == 0) {
				System.out.println(auditDir + "doesn't have any file with extension " + jsonFileName);
			} else {
				Date maxDate = null;
				String fileName = null;
				for (File file : listFiles) {
					fileName = file.getName();
					Date date = sdf.parse(fileName.substring(6, 16));
					if (maxDate == null)
						maxDate = date;
					else if (date.compareTo(maxDate) > 0)
						maxDate = date;
				}
				if (debug)
					System.out.println("Latest File date to process : " + sdf.format(maxDate));
				return maxDate;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (debug)
			System.out.println("returning Date value is: " + strCurrentDate);
		return currentDate;
	}

	public static class MyFileNameFilter implements FilenameFilter {
		private String jsonFileName;

		public MyFileNameFilter(String jsonFileName) {
			this.jsonFileName = jsonFileName.toLowerCase();
		}

		public boolean accept(File dir, String name) {
			return name.toLowerCase().endsWith(jsonFileName);
		}
	}

	private String getStrDate(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(date);
	}

	private Date getDate(String strDate) {
		Date date = null;
		try {
			date = gregorainSdf.parse(strDate);
		} catch (ParseException e) {
		}
		return date;
	}

	private Date getLastSuccessAuditTime(String auditDir, String jsonFileName) throws DataIngestException, IOException {
		Date lastSuccessAuditTime = null;
		JSONParser parser = null;
		JSONObject template = null;
		BufferedReader brd = null;
		try {
			parser = new JSONParser();
			brd = getReader(auditDir, jsonFileName);
			template = (JSONObject) parser.parse(brd);
			String date = (String) template.get("lastSuccessAuditTime");
			System.out.println("getLastSuccessAuditTime" + date);
			if (debug)
				System.out.println("Last Success Audit Time: " + date);
			lastSuccessAuditTime = (date == null) ? new Date() : getDate(date);
		} catch (Exception e) {
			throw new DataIngestException("(Error):", e);
		} finally {
			if (brd != null)
				brd.close();
		}
		return lastSuccessAuditTime;
	}

	private void setLastFileProcessTime(String auditDir, String jsonFileName) throws DataIngestException, IOException {
		Date lastSuccessAuditTime = null;
		JSONParser parser = null;
		JSONObject template = null;
		BufferedReader brd = null;
		int i = 0;
		try {
			parser = new JSONParser();
			brd = getReader(auditDir, jsonFileName);
			template = (JSONObject) parser.parse(brd);
			lastFileProcessTimeMap = new HashMap<String, JSONObject>();
			Iterator it = template.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry) it.next();
				if (template.get(pair.getKey()) instanceof JSONArray) {
					JSONArray jsonArray = (JSONArray) template.get(pair.getKey());
					Iterator iterator = jsonArray.iterator();
					while (iterator.hasNext()) {
						i++;
						JSONArray array = (JSONArray) iterator.next();
						Iterator itr = array.iterator();
						while (itr.hasNext()) {
							JSONObject entity = (JSONObject) itr.next();
							String tableName = (String) entity.get("tableName");
							// String lastFileProcessTime=(String)
							// entity.get("lastFileProcessTime");
							lastFileProcessTimeMap.put(tableName, entity);
						}
					}

				}
			}
		} catch (Exception e) {
			throw new DataIngestException("(Error):", e);
		} finally {
			if (brd != null)
				brd.close();
		}
	}

	private Date convertDate(String strDate) {
		Date date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			date = sdf.parse(strDate);
		} catch (ParseException e) {
		}
		return date;

	}

	public String getFileNameExtension(String fileName) {
		int firstDotIndex = fileName.indexOf(".");
		return fileName.substring(firstDotIndex + 1, fileName.length());
	}
	// End Of Class
}
