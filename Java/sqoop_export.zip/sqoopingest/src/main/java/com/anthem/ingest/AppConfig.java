package com.anthem.ingest;

import java.util.Map;

public class AppConfig {

	private Map<String, Map<String, Map<String, String>>> dv;
	private Map<String, Map<String, Map<String, String>>> ts;
	private Map<String, Map<String, Map<String, String>>> pr;
	
	
	public Map<String, Map<String, Map<String, String>>> getDv() {
		return dv;
	}
	public void setDv(Map<String, Map<String, Map<String, String>>> dv) {
		this.dv = dv;
	}
	public Map<String, Map<String, Map<String, String>>> getTs() {
		return ts;
	}
	public void setTs(Map<String, Map<String, Map<String, String>>> ts) {
		this.ts = ts;
	}
	public Map<String, Map<String, Map<String, String>>> getPr() {
		return pr;
	}
	public void setPr(Map<String, Map<String, Map<String, String>>> pr) {
		this.pr = pr;
	}
}
