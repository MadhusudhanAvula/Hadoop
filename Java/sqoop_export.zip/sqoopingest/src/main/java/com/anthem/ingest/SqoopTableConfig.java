
package com.anthem.ingest;
 /**
  *  This class is a place holder for import table parameters in a java object
  */
public class SqoopTableConfig {
	
	//  IMPORTANT ::: Please make sure to match the keys from json to the one mentioned here!
	public static final String tableName_p = "tablename"; // --table
	public static final String columns_p = "columns"; // --columns
	public static final String maxtimecolumnname_p = "maxtimecolumnname"; // --maxtimecolumnname
	public static final String mapcolumntojavatype_p = "mapcolumntojavatype";
	public static final String hdfsTargetDir_p = "hdfstargetdir"; // --target-dir
	public static final String incremental_p = "incremental"; // --incremental
	public static final String nbrOfMappers_p = "nbrofmappers"; // "nbrofmappers"
	public static final String splitBy_p = "splitby"; // --split-by
	public static final String importSequence_p = "importsequence";
	public static final String dateFormat_p = "dateformat";
	public static final String primarykeys_p = "primarykeys";
	public static final String selectquery_p = "selectquery";
	public static final String resourceid_p = "resourceId";
	
	String tableName = null;
	String columns = null;
	String maxtimecolumnname = null;
	String mapcolumntojavatype = null;
	String hdfsTargetDir = null;
	String incremental = null;
	int nbrOfMappers = 1;
	String splitBy = null;
	int importSequence = 9999;
	String[] sqoopQuery = null;
	String targetHDFSPath = null;
	//String archivePath = null;
	String dateFormat = null;
	String primaryKeys = null;
	String selectQuery=null;
	String resourceId = null;
	
	boolean validTableConfig = false;
	

	SqoopTableConfig() {
		super();
	}

	SqoopTableConfig(String tableName, String columns, String maxtimecolumnname,
			String mapcolumntojavatype, String hdfsTargetDir, String incremental, int nbrOfMappers, String splitBy,
			int importSequence,String dateFormat,String primaryKeys,String selectQuery,String resourceId) {
		this.tableName = tableName;
		this.columns = columns;
		this.maxtimecolumnname = maxtimecolumnname;
		this.mapcolumntojavatype = mapcolumntojavatype;
		this.hdfsTargetDir = hdfsTargetDir;
		this.incremental = incremental;
		this.nbrOfMappers = nbrOfMappers;
		this.splitBy = splitBy;
		this.importSequence = importSequence;
		this.dateFormat = dateFormat;
		this.primaryKeys = primaryKeys;
		this.selectQuery=selectQuery;
		this.resourceId=resourceId;
		
	}

	SqoopTableConfig(String tableName, String columns, String maxtimecolumnname,
			String mapcolumntojavatype, String hdfsTargetDir, String incremental, String splitBy,String dateFormat,String primaryKeys,String selectQuery,String resourceId) {
		this.tableName = tableName;
		this.columns = columns;
		this.maxtimecolumnname = maxtimecolumnname;
		this.mapcolumntojavatype = mapcolumntojavatype;
		this.hdfsTargetDir = hdfsTargetDir;
		this.incremental = incremental;
		this.nbrOfMappers = 1;
		this.splitBy = splitBy;
		this.importSequence = 9999;
		this.dateFormat = dateFormat;
		this.primaryKeys = primaryKeys;
		this.selectQuery=selectQuery;
		this.resourceId=resourceId;
		
		
	}

	/*public String getArchivePath() {
		return this.archivePath;
	}

	public void setArchivePath(String p) {
		this.archivePath = p;
	}*/

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getTableName() {
		return this.tableName;
	}

	public void setColumns(String columns) {
		this.columns = columns;
	}

	public String getColumns() {
		return this.columns;
	}

	public void setMaxTimeColumnName(String maxtimecolumnname) {
		this.maxtimecolumnname = maxtimecolumnname;
	}

	public String getMaxTimeColumnName() {
		return this.maxtimecolumnname;
	}

	public void setMapColumnJava(String mapcolumntojavatype) {
		this.mapcolumntojavatype = mapcolumntojavatype;
	}

	public String getMapColumnJava() {
		return this.mapcolumntojavatype;
	}

	public void setHdfsTargetDir(String hdfsTargetDir) {
		this.hdfsTargetDir = hdfsTargetDir;
	}

	public String getHdfsTargetDir() {
		return this.hdfsTargetDir;
	}

	public void setIncremental(String incremental) {
		this.incremental = incremental;
	}

	public String getIncremental() {
		return this.incremental;
	}

	public void setNbrOfMappers(int nbrOfMappers) {
		this.nbrOfMappers = nbrOfMappers;
	}

	public int getNbrOfMappers() {
		return this.nbrOfMappers;
	}

	public void setSplitBy(String splitBy) {
		this.splitBy = splitBy;
	}

	public String getSplitBy() {
		return this.splitBy;
	}
	public void setImportSequence(int importSequence) {
		this.importSequence = importSequence;
	}

	public int getImportSequence() {
		return this.importSequence;
	}

	public boolean getValidTableConfig() {
		return this.validTableConfig;
	}

	public void setValidTableConfig(boolean validTableConfig) {
		this.validTableConfig = validTableConfig;
	}

	public String[] getSqoopQuery() {
		return this.sqoopQuery;
	}

	public void setSqoopQuery(String[] queryString) {
		this.sqoopQuery = queryString;
	}

	public void setTargetHDFSPath(String s) {
		this.targetHDFSPath = s;
	}

	public String getTargetHDFSPath() {
		return this.targetHDFSPath;
	}

	public boolean isValidTableConfig() {
		validateTableConfig();
		return validTableConfig;
	}
	
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public String getDateFormat() {
		return this.dateFormat;
	}
	public void setPrimaryKey(String primaryKeys) {
		this.primaryKeys = primaryKeys;
	}

	public String getPrimaryKey() {
		return this.primaryKeys;
	}
	public String getSelectQuery() {
		return selectQuery;
	}

	public void setSelectQuery(String selectQuery) {
		this.selectQuery = selectQuery;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public void validateTableConfig() {
		if (tableName == null || columns == null
				|| maxtimecolumnname == null || mapcolumntojavatype == null || hdfsTargetDir == null
				|| incremental == null || splitBy == null||dateFormat==null||primaryKeys==null||selectQuery==null) {
			validTableConfig = false;
		} else
			validTableConfig = true;

	}

	public String toString() {
		StringBuffer tbl = new StringBuffer();
		tbl.append(tableName_p + " : " + tableName + "\n");
		tbl.append(columns_p + " : " + columns + "\n");
		tbl.append(maxtimecolumnname_p + " : " + maxtimecolumnname + "\n");
		tbl.append(mapcolumntojavatype_p + " : " + mapcolumntojavatype + "\n");
		tbl.append(hdfsTargetDir_p + " : " + hdfsTargetDir + "\n");
		tbl.append(incremental_p + " : " + incremental + "\n");
		tbl.append(nbrOfMappers_p + " : " + nbrOfMappers + "\n");
		tbl.append(splitBy_p + " : " + splitBy + "\n");
		tbl.append(importSequence_p + " : " + importSequence + "\n");
		tbl.append("sqoopQuery : " + builder(sqoopQuery) + "\n");
		tbl.append("Target HDFS Path : " + targetHDFSPath + "\n");
		//tbl.append("Archive Path : " + archivePath + "\n");
		tbl.append(dateFormat_p + " : " + dateFormat + "\n");
		tbl.append(primarykeys_p + " : " + primaryKeys + "\n");
		tbl.append(selectquery_p + " : " + selectQuery + "\n");
		tbl.append(resourceid_p + " : "+ resourceId + "\n");
		tbl.append("Valid Table Config" + " : " + validTableConfig);
		
		return tbl.toString();
	}

	private String builder(String[] arr) {
		StringBuffer bfr = new StringBuffer();
		boolean skip = false;
		for (String s : arr) {
			if (!skip)
				bfr.append(s + " ");
			else {
				bfr.append("XXXXXXXX ");
				skip = false;
			}
			/*
			 * if (s.toLowerCase().contains("password")) skip = true;
			 */
			if (s.toLowerCase().equalsIgnoreCase("--password"))
				skip = true;
		}
		return bfr.toString();
	}
} // End of Class
