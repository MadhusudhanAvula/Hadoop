package com.anthem.ingest;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.ContentSummary;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.apache.sqoop.Sqoop;
import com.google.common.base.Strings;


public class TdchIngest implements DataIngest {

	public static final boolean debug = DataIngestDriver.debug;
	JSONObject configJson;
	ArrayList<TdchTableConfig> tableArray = new ArrayList<TdchTableConfig>();
	TdchDBConfig dbConfig = new TdchDBConfig();
	ArrayList<ArrayList<String>> tdchQueries = new ArrayList<ArrayList<String>>();
	String jsonFileName = null;
	String templateType = null;
	String auditFileName = null;
	String loadTimeStamp =  new SimpleDateFormat("dd-MMM-yyyy HH.mm.ss").format(new java.util.Date());
	static String user;
	static String keyPath;
	static Configuration config = new Configuration();
	static{		
		config.addResource(new Path(DataIngestDriver.coreSite));
		config.addResource(new Path(DataIngestDriver.hdfsSite));
		config.addResource(new Path(DataIngestDriver.mapredSite));
		config.addResource(new Path(DataIngestDriver.yarnSite));
		user = DataIngestDriver.principalName;
		keyPath = DataIngestDriver.keyTabFile;
		UserGroupInformation.setConfiguration(config);
	}

	TdchIngest() {
		super();
	}

	public void setConfigJson(JSONObject configJson) {
		this.configJson = configJson;
	}

	public JSONObject getConfigJson() {
		return this.configJson;
	}

	public void setJsonFileName(String fileName) {
		this.jsonFileName = fileName;
	}

	public String getJsonFileName() {
		return this.jsonFileName;
	}

	public void setTemplateType(String tType) {
		this.templateType = tType;
	}

	public String getTemplateType() {
		return this.templateType;
	}


	public void loadConfig(String fileName) throws DataIngestException, Exception {
		this.jsonFileName = fileName;
		Date date = new Date();
		String yymmddDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		this.auditFileName = DataIngestDriver.auditDir + File.separator + "audit_" + yymmddDate + "_" + jsonFileName;
		// System.out.println("\n" + "AuditFile Name : " + auditFileName);
		JSONParser parser = new JSONParser();
		JSONObject template = null;
		BufferedReader brd = null;

		try {
			brd = getReader(DataIngestDriver.jsonDir, jsonFileName);
			template = (JSONObject) parser.parse(brd);
		} catch (Exception e) {
			throw new DataIngestException("(Error):", e);
		} finally {
			if (brd != null)
				brd.close();
		}

		loadConfig(template);
	}

	/*
	 * Validate that All required key=value configurations are present in the
	 * JSONObject to perform a tdch -import
	 */
	private void loadConfig(JSONObject obj) throws DataIngestException {
		this.setConfigJson(obj);
		int i = 0;
		Iterator it = configJson.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			if (configJson.get(pair.getKey()) instanceof JSONArray) {
				JSONArray jsonArray = (JSONArray) configJson.get(pair.getKey());
				Iterator iterator = jsonArray.iterator();
				while (iterator.hasNext()) {
					i++;
					JSONObject table = (JSONObject) iterator.next();
					// System.out.println("Extracting Properties from Table > "
					// + i + " "+ table);
					tableArray.add(getTableProperties(table));
				}

			} else {
				// System.out.println(pair.getKey() + " = " + pair.getValue());
				getDBProperty(pair);
			}

		}
		// dbConfig.validateDBConfig();
		if (!dbConfig.isValidDBConfig()) {
			throw new DataIngestException(
					"Database Connection Configuration Error > (DB Config) " + dbConfig.toString());
		}
		buildTdchQueries();
		// System.out.println("Data Base Config: " + dbConfig.toString());
	}

	private void getDBProperty(Map.Entry pair) {
		String key = (String) pair.getKey();
		String value = (String) pair.getValue();
		switch (key) {
		case TdchDBConfig.templateType_p:
			dbConfig.setTemplateType(value);
			this.setTemplateType(value);
			// System.out.println(key + " = " + value);
			break;
		case TdchDBConfig.userName_p:
			dbConfig.setUserName(value);
			// System.out.println(key + " = " + value);
			break;
			/*case TdchDBConfig.password_p:
			dbConfig.setPassword(value);
			if (value != null) {
				dbConfig.setPassword(DataIngestDriver.decryptPwd(value));
			}
			// System.out.println(key + " = " + value);
			break;*/
		case TdchDBConfig.connection_p:
			if (value != null) {
				setConnectionProperties(value);
				dbConfig.setConnectionFile(value);
			}
			// System.out.println(key + " = " + value);
			break;
		case TdchDBConfig.jdbcURL_p:
			dbConfig.setJdbcURL(value);
			// System.out.println(key + " = " + value);
			break;
		case TdchDBConfig.database_p:
			dbConfig.setDatabase(value);
			// System.out.println(key + " = " + value);
			break;
		case TdchDBConfig.connectionManager_p:
			dbConfig.setConnectionManager(value);
			// System.out.println(key + " = " + value);
			break;
		case TdchDBConfig.driver_p:
			dbConfig.setDriver(value);
			// System.out.println(key + " = " + value);
			break;
		case TdchDBConfig.license_p:
			dbConfig.setLicense(value);
			// System.out.println(key + " = " + value);
			break;
		case TdchDBConfig.hiveURL_p:
			dbConfig.setHiveURL(value);
			// System.out.println(key + " = " + value);
			break;
		default:
			// System.out.println("Did Not Match Ignore");
			break;
		}
	}

	private ArrayList<String> buildDBConnection() {
		ArrayList<String> connbfr = new ArrayList<String>();
		connbfr.add("export HADOOP_CLASSPATH=$HADOOP_CLASSPATH:/opt/cloudera/parcels/CDH/jars/* && ");
		connbfr.add("hadoop");
		connbfr.add("jar");
		connbfr.add(DataIngestDriver.homeDir+"/teradata-connector.jar");
		connbfr.add("com.teradata.connector.common.tool.ConnectorImportTool");
		
		connbfr.add("-Dmapreduce.job.queuename=bdf_yarn");
		
		String libJars = DataIngestDriver.homeDir+"/"+"parquet-hadoop-bundle.jar";

		if (!dbConfig.getLicense().equalsIgnoreCase("NONE")) {
			libJars += ";" + dbConfig.getLicense();
		}
		else{
			libJars += ";" + DataIngestDriver.homeDir+"/"+"sqoopingest-1.0-jar-with-dependencies.jar";
		}
		
		connbfr.add("-libjars");
		System.out.println("libJars == " + libJars);
		connbfr.add(libJars);

		if (!dbConfig.getDriver().equalsIgnoreCase("NONE")) {
			connbfr.add("-classname");
			connbfr.add(dbConfig.getDriver());
		}

		connbfr.add("-url");
		connbfr.add(dbConfig.getJdbcURL());

		connbfr.add("-username");
		connbfr.add(dbConfig.getUserName()); 

		connbfr.add("-password");
		connbfr.add("'$tdwallet("+dbConfig.getTdchwalletpwd()+")'");

		connbfr.add("-jobtype");
		connbfr.add("hdfs");

		return connbfr;

	}

	private ArrayList<String> buildTdchQuery(ArrayList<String> conn, TdchTableConfig tbl) {
		ArrayList<String> cmd = new ArrayList<String>();
		String methodTech="SplitByPartition";
		for (String obj : conn) {
			cmd.add(obj);
		}

		if (!tbl.getTableName().equalsIgnoreCase("NONE")&& !tbl.getColumns().equalsIgnoreCase("NONE") &&tbl.getSelectQuery().equalsIgnoreCase("NONE")) {
			cmd.add("-sourcetable");
			cmd.add(tbl.getTableName());
			cmd.add("-sourcefieldnames");
			cmd.add(tbl.getColumns());
			methodTech="fastexport";
		}

		if (!tbl.getTableName().equalsIgnoreCase("NONE") && tbl.getColumns().equalsIgnoreCase("NONE") && tbl.getSelectQuery().equalsIgnoreCase("NONE")){
			cmd.add("-sourcetable");
			cmd.add(tbl.getTableName());
			methodTech="fastexport";
		}

		String maxDate = null;
		if (tbl.getIncremental().equalsIgnoreCase("YES")) {
			maxDate = readLastUpdDate(DataIngestDriver.hdfstargetdir + File.separator + DataIngestDriver.category.toLowerCase()+"_"+DataIngestDriver.source.toLowerCase()+"_"+tbl.getTableName().toLowerCase()+File.separator+"lastLoadTime.txt");
		}

		if (!tbl.getSelectQuery().equalsIgnoreCase("NONE")) {
			cmd.add("-sourcequery");
			if (maxDate != null && tbl.getIncremental().equalsIgnoreCase("YES")) {
				String selectQuery = "\""+tbl.getSelectQuery()
				+ " AND cast(substr(cast("+tbl.getMaxTimeColumnName()+" as char(26)),1,19) as TIMESTAMP) (TIMESTAMP,FORMAT '"+tbl.getDateFormat()+"') (char(25)) >='" + maxDate.toString()+"'"
				+ " AND cast(substr(cast("+tbl.getMaxTimeColumnName()+" as char(26)),1,19) as TIMESTAMP) (TIMESTAMP,FORMAT '"+tbl.getDateFormat()+"') (char(25)) <'" + loadTimeStamp.toString()+"'"+"\"";
				selectQuery = selectQuery.replace("\\n", "");
				cmd.add(selectQuery);
			} else {
				cmd.add("\""+tbl.getSelectQuery()+"\"");
			}
		}

		cmd.add("-targetpaths");
		String bPath = null;

		bPath = DataIngestDriver.hdfstargetdir + File.separator + DataIngestDriver.category.toLowerCase()+"_"+DataIngestDriver.source.toLowerCase()+"_"+tbl.getTableName().toLowerCase() + File.separator+ DataIngestDriver.fullFileDir;

		tbl.setTargetHDFSPath(bPath);
		cmd.add(bPath);

		if (!tbl.getSplitBy().equalsIgnoreCase("NONE")) {
			cmd.add("-splitbycolumn");
			cmd.add(tbl.getSplitBy());
		}
		cmd.add("-nummappers");
		cmd.add(String.valueOf(tbl.getNbrOfMappers()));
		cmd.add("-method");
		cmd.add(DataIngestDriver.tdchmethod);
		cmd.add("-fileformat");
		cmd.add("avrofile");
		cmd.add("-queryband");
		if(String.valueOf(tbl.getNbrOfMappers()).equals("80")){
			cmd.add("'ApplicationName=BDF_"+DataIngestDriver.category+"_"+DataIngestDriver.source+";MapNum="+tbl.getNbrOfMappers()+";JobType=TDCH;JobOptions="+methodTech+";Frequency=AdHoc;UtilityDataSize=large;'");
		}
		else{
			cmd.add("'ApplicationName=BDF_"+DataIngestDriver.category+"_"+DataIngestDriver.source+";MapNum="+tbl.getNbrOfMappers()+";JobType=TDCH;JobOptions="+methodTech+";Frequency=AdHoc;'");	
		}
		
		cmd.add("-avroschemafile");
		cmd.add(DataIngestDriver.hdfstargetdir+"/"+tbl.getTableName().toLowerCase()+"_meta/"+tbl.getTableName().toLowerCase()+".avsc");
		tbl.setTdchQuery(cmd.toArray(new String[cmd.size()]));

		return cmd;
	}
	private void buildTdchQueries() {

		int i = 0;
		Iterator<TdchTableConfig> it = tableArray.iterator();
		while (it.hasNext()) {
			TdchTableConfig tc = it.next();
			// System.out.println("Original Sequence:" +
			// tc.getImportSequence());
			if (tc.isValidTableConfig())
				i++;
		}

		// System.out.println("Number of Valid Tables " + i);
		if (dbConfig.isValidDBConfig() && i > 0) {

			Comparator<TdchTableConfig> comparator = new Comparator<TdchTableConfig>() {
				public int compare(TdchTableConfig obj1, TdchTableConfig obj2) {
					return obj1.getImportSequence() - obj2.getImportSequence();
				}

			}; // Innner Class
			Collections.sort(tableArray, comparator);
			int j = 0;
			ArrayList<String> conn = buildDBConnection();

			Iterator<TdchTableConfig> it2 = tableArray.iterator();
			while (it2.hasNext()) {
				TdchTableConfig tc2 = it2.next();
				// System.out.println("Sort Sequence :" +
				// tc2.getImportSequence());
				tdchQueries.add(buildTdchQuery(conn, tc2));
				j++;
			}

		}

	}// Method End

	/**
	 * This method contains all the table properties.
	 * @param table
	 * @return
	 */
	private TdchTableConfig getTableProperties(JSONObject table) {
		TdchTableConfig tc = new TdchTableConfig();
		tc.setTableName((String) table.get(TdchTableConfig.tableName_p));
		tc.setColumns((String) table.get(TdchTableConfig.columns_p));
		tc.setMaxTimeColumnName((String) table.get(TdchTableConfig.maxtimecolumnname_p));
		tc.setMapColumnJava((String) table.get(TdchTableConfig.mapcolumntojavatype_p));
		tc.setHdfsTargetDir((String) table.get(TdchTableConfig.hdfsTargetDir_p));
		tc.setIncremental((String) table.get(TdchTableConfig.incremental_p));
		if (tc.getIncremental() == null) {
			tc.setIncremental("NO");
		}
		try {
			String s = (String) table.get(TdchTableConfig.nbrOfMappers_p);
			tc.setNbrOfMappers(Integer.parseInt(s));
		} catch (NumberFormatException e) {
			tc.setNbrOfMappers(1);
		}
		tc.setSplitBy((String) table.get(TdchTableConfig.splitBy_p));
		tc.setDateFormat((String) table.get(TdchTableConfig.dateFormat_p));
		tc.setPrimaryKey((String) table.get(TdchTableConfig.primarykeys_p));
		tc.setSelectQuery((String) table.get(TdchTableConfig.selectquery_p));
		try {
			String s1 = (String) table.get(TdchTableConfig.importSequence_p);
			tc.setImportSequence(Integer.parseInt(s1));

		} catch (NumberFormatException e) {
			tc.setImportSequence(9999);
		}

		tc.validateTableConfig();
		// System.out.println("Extracted Table Config > " + tc.toString());
		return tc;

	}

	public int run() {
		int statusF = 0;
		DataIngestStatus newSts = new DataIngestStatus(this.templateType, this.auditFileName);
		StringBuilder tableStatus = new StringBuilder();
		String inboundHome=null;


		for (TdchTableConfig tbl : tableArray) {
			int status = 0;
			//creating paths for schema and audit file creation
			String schmeFilePathFull=tbl.getTargetHDFSPath();
			int index1=schmeFilePathFull.lastIndexOf('/');			
			String schemaPathTruncate1 = schmeFilePathFull.substring(0,index1);
			int index2=schemaPathTruncate1.lastIndexOf('/');
			String schemaPathTruncate = schemaPathTruncate1.substring(0,index2)+"/"+tbl.getTableName().toLowerCase()+"_meta";	

			//Setting table status path 
			if(Strings.isNullOrEmpty(inboundHome)) {
				inboundHome = schemaPathTruncate1.substring(0,index2);

			}
			if (tbl.isValidTableConfig()) {

				if (debug) {
					System.out.println("Running TDCH Import for Table : " + tbl.getTableName() + "\n");
				}
				DataIngestStatus.IngestStatus st = newSts.new IngestStatus();
				st.entityName = tbl.getTableName();
				st.processingStep = DataIngestDriver.ING;
				st.targetHDFSPath = tbl.getTargetHDFSPath();
				st.incremental = tbl.getIncremental();
				st.startDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
				String[] sqoopQueryArray=null;
				int sqoopStatus;

				
				if (DataIngestDriver.schemaEvolution.equalsIgnoreCase("true")){
					if (!tbl.mapcolumntojavatype.equalsIgnoreCase("NONE") && !tbl.getSelectQuery().equalsIgnoreCase("NONE")){
						sqoopQueryArray = new String[]{"import","-Dmapreduce.job.queuename=bdf_yarn","-Dhadoop.security.credential.provider.path="+dbConfig.getJcekslocation(),"--libjars",DataIngestDriver.homeDir+"/tdgssconfig.jar,"+DataIngestDriver.homeDir+"/terajdbc4.jar","--driver","com.teradata.jdbc.TeraDriver","--connect",dbConfig.getJdbcURL(),"--username",dbConfig.getUserName(),"--password-alias",dbConfig.getJceksalias(),"--map-column-java",tbl.mapcolumntojavatype,"--query","SELECT TOP 100* from (" +tbl.getSelectQuery() +") t where $CONDITIONS" 
								,"--target-dir",tbl.getTargetHDFSPath(),"--num-mappers","1","--as-avrodatafile","--delete-target-dir","--outdir",DataIngestDriver.generatedJavaSrc+"/"+tbl.getTableName().toLowerCase()};

					}
					else if (!tbl.mapcolumntojavatype.equalsIgnoreCase("NONE") && tbl.getSelectQuery().equalsIgnoreCase("NONE")){
						sqoopQueryArray = new String[]{"import","-Dmapreduce.job.queuename=bdf_yarn","-Dhadoop.security.credential.provider.path="+dbConfig.getJcekslocation(),"--libjars",DataIngestDriver.homeDir+"/tdgssconfig.jar,"+DataIngestDriver.homeDir+"/terajdbc4.jar","--driver","com.teradata.jdbc.TeraDriver","--connect",dbConfig.getJdbcURL(),"--username",dbConfig.getUserName(),"--password-alias",dbConfig.getJceksalias(),"--map-column-java",tbl.mapcolumntojavatype,"--query","SELECT TOP 100* from " +tbl.getTableName() + " where $CONDITIONS"  
								,"--target-dir",tbl.getTargetHDFSPath(),"--num-mappers","1","--as-avrodatafile","--delete-target-dir","--outdir",DataIngestDriver.generatedJavaSrc+"/"+tbl.getTableName().toLowerCase()};
					}

					else if (tbl.mapcolumntojavatype.equalsIgnoreCase("NONE") && !tbl.getSelectQuery().equalsIgnoreCase("NONE")){
						sqoopQueryArray = new String[]{"import","-Dmapreduce.job.queuename=bdf_yarn","-Dhadoop.security.credential.provider.path="+dbConfig.getJcekslocation(),"--libjars",DataIngestDriver.homeDir+"/tdgssconfig.jar,"+DataIngestDriver.homeDir+"/terajdbc4.jar","--driver","com.teradata.jdbc.TeraDriver","--connect",dbConfig.getJdbcURL(),"--username",dbConfig.getUserName(),"--password-alias",dbConfig.getJceksalias(),"--query","SELECT TOP 100* from (" +tbl.getSelectQuery() +") t where $CONDITIONS" 
								,"--target-dir",tbl.getTargetHDFSPath(),"--num-mappers","1","--as-avrodatafile","--delete-target-dir","--outdir",DataIngestDriver.generatedJavaSrc+"/"+tbl.getTableName().toLowerCase()};

					}
					else{
						sqoopQueryArray = new String[]{"import","-Dmapreduce.job.queuename=bdf_yarn","-Dhadoop.security.credential.provider.path="+dbConfig.getJcekslocation(),"--libjars",DataIngestDriver.homeDir+"/tdgssconfig.jar,"+DataIngestDriver.homeDir+"/terajdbc4.jar","--driver","com.teradata.jdbc.TeraDriver","--connect",dbConfig.getJdbcURL(),"--username",dbConfig.getUserName(),"--password-alias",dbConfig.getJceksalias(),"--query","SELECT TOP 100* from " +tbl.getTableName() +" where $CONDITIONS"
								,"--target-dir",tbl.getTargetHDFSPath(),"--num-mappers","1","--as-avrodatafile","--delete-target-dir","--outdir",DataIngestDriver.generatedJavaSrc+"/"+tbl.getTableName().toLowerCase()};

					}

					System.out.println("SQOOP HDFS Target=======>" +tbl.getTargetHDFSPath() );
					
					//Delete the old Avro schema file for SQOOP to generate the updated schema file
					String delAVSCOld = "rm "+DataIngestDriver.generatedJavaSrc+"/"+tbl.getTableName().toLowerCase()+"/QueryResult.avsc";
					
					System.out.println("Deleted the old avro schema: "+delAVSCOld);
					try {
						Runtime.getRuntime().exec(delAVSCOld);
					} catch (IOException e) {
						e.printStackTrace();
					}
								
					
					sqoopStatus = Sqoop.runTool(sqoopQueryArray, config);
					String sqoopQueryArrayString = Arrays.toString(sqoopQueryArray);
					System.out.println("Sqoop Query -- >" + sqoopQueryArrayString);
					
					System.out.println("Sqoop Status == "+ sqoopStatus);
					if (sqoopStatus!=0){
						System.out.println("Error in SQOOP import for AVSC schema");
					}
					getAVSCFileToHDFS(DataIngestDriver.generatedJavaSrc+"/"+tbl.getTableName().toLowerCase()+"/"+"QueryResult.avsc",schemaPathTruncate,tbl.getTableName().toLowerCase());

				}


				try {


					FileSystem fileSystem = FileSystem.get(config);
					if ( fileSystem.exists( new Path(tbl.getTargetHDFSPath()))) 
					{ 
						fileSystem.delete( new Path(tbl.getTargetHDFSPath()),true);
						System.out.println("Sqoop import data deleted ");


					}

					List<String> list = Arrays.asList(tbl.getTdchQuery());
					String TDCHQuery = String.join(" ", list);
					//String logFileName = DataIngestDriver.templateFileName+ "_" + new SimpleDateFormat("yyyy-MM-dd").format(new Date());
					System.out.println("TDCH query-->"+TDCHQuery);
					status  = runCommand(TDCHQuery+" &>> "+DataIngestDriver.logDir+"/"+DataIngestDriver.logFileName+".log");

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				//Get load log key from map file and collecting the table status to HDFS for data warehouse to read
				String LoadlogKey = DataIngestDriver.loadLogKey;
				String loadType;
				if(tbl.getIncremental().equalsIgnoreCase("YES")){
					loadType="I";
				}
				else{
					loadType="H";
				}
				tableStatus.append(tbl.getTableName().toString().toLowerCase()+"|"+status+"|"+LoadlogKey+"|"+loadType+"|"+tbl.getPrimaryKey().replaceAll(";", ",")+"\n");

				if(status == 0) {
					String fileSize = getFileSize(tbl.getTargetHDFSPath(),config);							
					writeDataToHDFS(schemaPathTruncate1+"/lastLoadTime.txt",tbl.getTableName().toLowerCase()+"|"+loadTimeStamp);

					if (debug) {
						System.out.println("FileSize: "+fileSize+" bytes");
					}
					st.fileSize=fileSize+" bytes";

				}
				else {
					System.out.println("TDCH failed Returned Code : " + Integer.toString(status));
				}

				st.statusDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
				st.returnCode = status;
				st.status = (status == 0) ? "SUCCESS" : "FAIL";
				st.statusDesc = (status == 0) ? "TDCH Import Successful."
						: "TDCH Import failed check log for detail.";
				newSts.addStatus(tbl.getTableName() + st.processingStep, st);
			} else {

				if (debug) {
					System.out.println("Skipping Import for Table  : " + tbl.getTableName() + "\n");
				}
				if (!tbl.isValidTableConfig()) {
					DataIngestStatus.IngestStatus st = newSts.new IngestStatus();
					st.entityName = tbl.getTableName();
					st.processingStep = DataIngestDriver.ING;
					st.targetHDFSPath = tbl.getTargetHDFSPath();
					st.incremental = tbl.getIncremental();
					st.startDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
					status = 999;
					st.statusDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
					st.returnCode = status;
					st.status = "INVALID";
					st.statusDesc = "Invalid Configuration : " + tbl.getTableName();
					newSts.addStatus(tbl.getTableName() + st.processingStep, st);

				}
			}
		} // end for tableArray

		// Writing the table status to file in HDFS
		writeDataToHDFS(inboundHome+"/tableStatus/"+DataIngestDriver.templateFileName.replace(".json", ".txt"),tableStatus.toString());
		//archive(newSts);
		return statusF = newSts.getHeaderReturnCode();
	}

	private String getFileSize(String filePath,Configuration config) {
		long size=0;
		String fileSize = null;
		Path path =null;
		FileSystem hdfs=null;
		try {
			path = new Path(filePath);
			hdfs = path.getFileSystem(config);
			ContentSummary summary = hdfs.getContentSummary(path);
			size = (summary!=null)?summary.getLength():0;
			fileSize = String.valueOf(size);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return fileSize;
	}

	private void writeDataToHDFS(String auditFilePath,String auditContent){
		BufferedWriter br=null;
		FileSystem fileSystem=null;
		try {
			fileSystem = FileSystem.get(config);			
			Path file = new Path(auditFilePath);			
			if ( fileSystem.exists( file )) 
			{ 
				fileSystem.delete( file, true ); 
			} 
			OutputStream os = fileSystem.create(file);
			br = new BufferedWriter( new OutputStreamWriter( os, "UTF-8" ) );
			br.write(auditContent);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				br.close();
				fileSystem.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}
	}

	private String readLastUpdDate(String auditFilePath){
		FileSystem fileSystem=null;
		String lastModified=null;
		try {
			Path path = new Path(auditFilePath);			
			fileSystem = path.getFileSystem(config);
			FSDataInputStream inputStream = fileSystem.open(path);
			String inputData = IOUtils.toString(inputStream); 
			System.out.println("Reading the last date modified");


			String[] splitArray = inputData.split("\\|");
			lastModified= splitArray[1];

			//System.out.println("lastModified --> "+lastModified);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("Printing Stack Trace : " + e.getMessage());
		}
		finally{
			try {
				fileSystem.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		return lastModified;

	}

	public void printRunnable() {
		if (debug) {
			System.out.println("Printing Runnable Configurations : " + this.getClass().getName() + ":" + new Object() {
			}.getClass().getEnclosingMethod().getName() + "\n");
			for (TdchTableConfig tbl : tableArray) {
				System.out.println(tbl.toString() + "\n");
			}
		} else {
			System.out.println("Please set tool.debug=true in confiuration properties to print runnables.");
		}
	}

	private BufferedReader getReader(String path, String fileName) throws Exception {
		return new BufferedReader(new FileReader(path + File.separator + fileName));
	}

	/*private void setConnectionProperties(String fileName) {
		Properties prop = null;
		FileInputStream fileInputStream = null;
		String connectionPath;
		try {			
			// load a properties file
			connectionPath = DataIngestDriver.connDir + File.separator + fileName;
			fileInputStream = new FileInputStream(connectionPath);
			prop = new Properties();
			prop.load(fileInputStream);
			dbConfig.setUserName(prop.getProperty("username"));
			String password = prop.getProperty("password");
			System.out.println("password is +"+ password);
			if (password != null) {
				dbConfig.setPassword(DataIngestDriver.decryptPwd(password));
			}
			dbConfig.setJdbcURL(prop.getProperty("jdbcurl") + dbConfig.getDatabase());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/

	private void setConnectionProperties(String fileName) {
		try {			
			// load a properties file
			dbConfig.setUserName(DataIngestDriver.dbUserName);
			dbConfig.setJceksalias(DataIngestDriver.pwdAlias);
			dbConfig.setJcekslocation(DataIngestDriver.jceksFileLocation);
			dbConfig.setJdbcURL(DataIngestDriver.jdbcURL +"/" +DataIngestDriver.sourcedbname);
			dbConfig.setTdchwalletpwd(DataIngestDriver.tdwalletpwd);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void getAVSCFileToHDFS(String src, String dst,String tblName) {		
		try {
			FileSystem fileSystem = FileSystem.get(config);
			if(!fileSystem.exists(new Path(dst))){
				fileSystem.mkdirs(new Path(dst)); 	
			}

			if(fileSystem.exists(new Path(dst+"/"+tblName.toLowerCase()+".avsc"))){
				fileSystem.delete(new Path(dst+"/"+tblName.toLowerCase()+".avsc"), false);
				System.out.println("Old Schema file deleted");

			}

			fileSystem.copyFromLocalFile(new Path(src), new Path(dst));
			System.out.println("Schema file copied from local to HDFS");

			fileSystem.rename(new Path(dst+"/QueryResult.avsc"), new Path(dst+"/"+tblName.toLowerCase()+".avsc"));
			System.out.println("Schema file renamed");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int runCommand(String command) throws IOException
	{
		int returnValue = -1;
		try {

			Process process=Runtime.getRuntime().exec(new String[] { "bash", "-c", command });
			//Process process = Runtime.getRuntime().exec(command );
			process.waitFor();    
			returnValue = process.exitValue();

			if (returnValue == 0)
				System.out.println("Successfully executed the command: " + command);
			else {
				System.out.println("Failed to execute the following command: " + command + " due to the following error(s):");
				BufferedReader b = new BufferedReader(new InputStreamReader(process.getErrorStream())); 
				String line=null;
				if ((line = b.readLine()) != null)
					System.out.println(line);
			}   


		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return returnValue;
	}


}