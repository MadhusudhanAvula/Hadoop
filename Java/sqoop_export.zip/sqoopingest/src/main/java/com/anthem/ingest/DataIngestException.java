
package com.anthem.ingest;
/**
 * This class defines all the exception thrown during 
 * data ingestion.
 */
public class DataIngestException extends Exception {

	private static final long serialVersionUID = 2017753363232807009L;

	public DataIngestException() {
		super();
	}

	public DataIngestException(String message) {
		super(message);
	}

	public DataIngestException(Throwable cause) {
		super(cause);
	}

	public DataIngestException(String message, Throwable cause) {
		super(message, cause);
	}

	public DataIngestException(String message, Throwable cause, boolean enableSuppression, 
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

} // End of Class
