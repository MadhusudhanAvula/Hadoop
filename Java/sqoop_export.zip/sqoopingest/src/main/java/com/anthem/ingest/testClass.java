package com.anthem.ingest;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.IOUtils;

import au.com.bytecode.opencsv.CSVReader;



public class testClass {
	public static Properties prop = null;
	public static boolean debug = false;
	public static String coreSite = null;
	public static String hdfsSite = null;
	public static String yarnSite = null;
	public static String mapredSite = null;

	public static void main(String[] args) throws IOException, ParseException{


		/*	String lastModified= "20-Oct-2017 16.48.47 PM";

	    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy HH.mm.ss aa");
	    Date parsedDate = dateFormat.parse(lastModified);

	    Timestamp lastModifiedtimestamp = new Timestamp(parsedDate.getTime());
	    SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy HH.mm.ss aa");
	    System.out.println("lastModified --> "+outputFormat.format(lastModifiedtimestamp));*/
		Map<String, String> tableLlkmap = new HashMap<String, String>();
		
		/*CSVReader fileReader =null;
		try {
			FileInputStream fisTargetFile = new FileInputStream(new File("C:/Users/AF53384/Desktop/TableLLKPairMap.csv"));
			String targetFileStr = IOUtils.toString(fisTargetFile, "UTF-8");	
			//setting key-value map
			String[] mapPairs = targetFileStr.split("\\r?\\n");

			for (String pair:mapPairs){
				String[] keyValue = pair.split(",");
				tableLlkmap.put(keyValue[0], keyValue[1]);
				System.out.println("");
			}

			String value = (String) tableLlkmap.get("SPSOWNER.GRPG_BP_PRCSG_MODE");

			System.out.println("the value ------>" +value);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Map-File does not exist!");
			e.printStackTrace();
		}*/
		String loadTimeStamp =  new SimpleDateFormat("yyyyMMdd").format(new java.util.Date());
		System.out.println("loadTimeStamp --> "+ loadTimeStamp);
		System.out.println("-D mapred.child.java.opts=\"\\-Djava.security.egd=file:/dev/../dev/urandom\"+");
		
	}
}
