package com.anthem.ingest;

public class TdchDBConfig {
	
	
	public static final String templateType_p = "templatetype";
	public static final String jdbcURL_p = "jdbcURL"; // jdbc url
	public static final String database_p = "database"; // database
	public static final String connection_p = "connectionfile";
	public static final String userName_p = "username"; // user
	// password in plain text?
	//public static final String password_p = "password"; 
	public static final String connectionManager_p = "connectionManager";
	public static final String driver_p = "driver";
	public static final String license_p = "license";
	//public static final String jarlocation_p = "jarlocation";
	public static final String hiveURL_p = "hiveURL";
	public static final String tdchWalletPwd_p = "tdchwalletpwd";
	public static final String jceksalias_p = "jceksalias";
	public static final String jcekslocation_p = "jcekslocation";
	
	
	
	

	String templateType = null;
	String jdbcURL = null;
	String database = null;
	String connectionFile = null;
	String userName = null;
	//String password = null;
	String connectionManager = null;
	String driver = null;
	String license = null;
	//String jarlocation=null;
	String hiveURL = null;
	String tdchwalletpwd = null;
	String jceksalias = null;
	String jcekslocation = null;

	boolean validDBConfig = false;

	TdchDBConfig() {
		super();
	}

	TdchDBConfig(String template, String url, String database, String connFile, String user, String pwd,
			String connMgr, String driver, String license,  String hvURL,String jcksalias,String jceksloc) {
		this.templateType = template;
		this.jdbcURL = url;
		this.database = database;
		this.connectionFile = connFile;
		this.userName = user;
		this.tdchwalletpwd = pwd;
		this.connectionManager = connMgr;
		this.driver = driver;
		this.license = license;
		this.hiveURL = hvURL;
		this.jceksalias=jcksalias;
		this.jcekslocation = jceksloc;
		this.validDBConfig = false;
	}

	public void setHiveURL(String hvURL) {
		this.hiveURL = hvURL;
	}

	public String getHiveURL() {
		return this.hiveURL;
	}

	public void setTemplateType(String template) {
		this.templateType = template;
	}

	public String getTemplateType() {
		return this.templateType;
	}

	public void setJdbcURL(String url) {
		this.jdbcURL = url;
	}

	public String getJdbcURL() {
		return this.jdbcURL;
	}

	public void setDatabase(String database) {
		this.database = database;
	}

	public String getDatabase() {
		return this.database;
	}

	public void setConnectionFile(String connFile) {
		this.connectionFile = connFile;
	}

	public String getConnectionFile() {
		return this.connectionFile;
	}

	public void setUserName(String usr) {
		this.userName = usr;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setValidDBConfig(boolean validDB) {
		this.validDBConfig = validDB;
	}

	public boolean getValidDBConfig() {
		return this.validDBConfig;
	}

	public void setConnectionManager(String connMgr) {
		this.connectionManager = connMgr;
	}

	public String getConnectionManager() {
		return this.connectionManager;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getDriver() {
		return this.driver;
	}

	public void setLicense(String license) {
		this.license = license;
	}

	public String getLicense() {
		return this.license;
	}

	public String getTdchwalletpwd() {
		return tdchwalletpwd;
	}

	public void setTdchwalletpwd(String tdchwalletpwd) {
		this.tdchwalletpwd = tdchwalletpwd;
	}
	public String getJceksalias() {
		return jceksalias;
	}

	public void setJceksalias(String jceksalias) {
		this.jceksalias = jceksalias;
	}

	public String getJcekslocation() {
		return jcekslocation;
	}

	public void setJcekslocation(String jcekslocation) {
		this.jcekslocation = jcekslocation;
	}
	public boolean isValidDBConfig() {
		validateDBConfig();
		return validDBConfig;
	}
	

	private void validateDBConfig() {
		if (templateType == null || jdbcURL == null || database == null || connectionFile == null || userName == null
				|| tdchwalletpwd == null || connectionManager == null || driver == null || hiveURL == null
				|| license == null||jcekslocation==null || jceksalias==null) {
			validDBConfig = false;
		} else
			validDBConfig = true;

	}

	public String toString() {
		StringBuffer db = new StringBuffer();
		db.append(templateType_p + " : " + templateType + "\n");
		db.append(jdbcURL_p + " : " + jdbcURL + "\n");
		db.append(database_p + ": " + database + "\n");
		db.append(connection_p + ": " + connectionFile + "\n");
		db.append(userName_p + " : " + userName + "\n");
		db.append(tdchWalletPwd_p + " : " + "*******" + "\n");
		db.append(connectionManager_p + " : " + connectionManager + "\n");
		db.append(driver_p + " : " + driver + "\n");
		db.append(license_p + " : " + license + "\n");
		db.append(hiveURL_p + " : " + hiveURL + "\n");
		db.append(jceksalias_p + " : " + jceksalias + "\n");
		db.append(jcekslocation_p + " : " + jcekslocation + "\n");
		db.append("Valid DB Config" + " : " + validDBConfig);
		return db.toString();
	}

}
