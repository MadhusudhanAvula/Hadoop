package com.anthem.ingest;

public interface DataIngest {

	// method signatures
	void loadConfig(String jsonFileName) throws DataIngestException, Exception;

	int run() throws DataIngestException;

	void printRunnable();
}
