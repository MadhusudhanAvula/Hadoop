package com.anthem.ingest;
/**
 * This class define whether the data ingestion is by sqoop
 * or sftp.
 *
 */
public class DataIngestFactory {

	/**
	 *  This method on receiving the object type decides whether
	 *   the job is SFTP or SQOOP
	 *  @param objType
	 *  @return null
	 */
	public DataIngest getIngestObj(String objType) {

		if (objType == null) {
			//System.out.println("Checkpoint obj type null");
			return null;			
		} else if (objType.equalsIgnoreCase("sqoop")) {
			//System.out.println("Checkpoint obj type sqoop");
			return new SqoopIngest();
		} else if (objType.equalsIgnoreCase("sftp")) {
			//System.out.println("Checkpoint obj type sftp");
			return new SFTPIngest();
		} else if (objType.equalsIgnoreCase("tdch")) {
			//System.out.println("Checkpoint obj type sftp");
			return new TdchIngest();
		}
		return null;
	}
}
