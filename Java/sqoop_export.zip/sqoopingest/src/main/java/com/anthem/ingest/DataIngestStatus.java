package com.anthem.ingest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
/**
 * This class is a place holder for maintaining the data
 * ingest status fields in java object form.
 *
 */
public class DataIngestStatus {
	public static final boolean debug = DataIngestDriver.debug;
	public static String SUCCESS = "ALL Entities are Ingested Successfully.";
	public static String FAILURE = "ALL or SOME Entities encountered error during Ingestion.";
	String templateType = null;
	String processingStep = null;
	String auditFileName = null;
	String headerStatus = null; // SUCCES/FAILED
	String headerStatusDesc = null;
	Date lastSuccessAuditTime=null;
	int headerReturnCode = 1; // 0 means success else error
	Map<String, IngestStatus> statusMap = new HashMap<String, IngestStatus>();
	Map<String, ArrayList<IngestStatus>> acMap = new HashMap<String, ArrayList<IngestStatus>>();

	DataIngestStatus() {
		super();
	}

	DataIngestStatus(String tType, String auditFile) {
		this.templateType = tType;
		this.auditFileName = auditFile;
	}

	public void setTemplateType(String tType) {
		this.templateType = tType;
	}

	public String getTemplateType() {
		return this.templateType;
	}

	public void setAuditFileName(String auditFile) {
		this.auditFileName = auditFileName;
	}

	public String getAuditFileName() {
		return this.auditFileName;
	}

	public void setHeaderStatus(String sts) {
		this.headerStatus = sts;
	}

	public String getHeaderStatus() {
		return this.headerStatus;
	}

	public void setHeaderStatusDesc(String des) {
		this.headerStatusDesc = des;
	}

	public String getHeaderStatusDesc() {
		return this.headerStatusDesc;
	}

	public void setHeaderReturnCode(int i) {
		this.headerReturnCode = i;
	}

	public int getHeaderReturnCode() {
		return this.headerReturnCode;
	}
	
	public void setLastSuccessAuditTime(Date date) {
		this.lastSuccessAuditTime = date;
	}

	public Date getLastSuccessAuditTime() {
		return this.lastSuccessAuditTime;
	}

	public Map<String, IngestStatus> getStatusMap() {
		return this.statusMap;
	}

	public void setStausMap(Map<String, IngestStatus> mp) {
		this.statusMap = mp;
	}

	public void addStatus(String key, IngestStatus value) {
		this.statusMap.put(key, value);
	}

	public IngestStatus getStatus(String key) {
		IngestStatus iStatus = null;
		if (this.statusMap.containsKey(key)) {
			iStatus = this.statusMap.get(key);
		}
		return iStatus;
	}

	private void addAcMap(String key, IngestStatus value) {

		if (this.acMap.containsKey(key)) {
			ArrayList<IngestStatus> ar = this.acMap.get(key);
			ar.add(value);
		} else {
			ArrayList<IngestStatus> ar = new ArrayList<IngestStatus>();
			ar.add(value);
			this.acMap.put(key, ar);
		}

	}

	/**
     * This method is used to get the status messages from 
     * ingest status class and ingest status object will 
     * export the data ingest status fields to json file.
     */
	public void writeAuditToFile() {

		JSONObject obj = new JSONObject();
		obj.put("templateType", getTemplateType());
		String filePath = getAuditFileName();
		String fileName = filePath.substring(filePath.lastIndexOf(File.separator) + 1, filePath.length());
		obj.put("auditFileName", fileName);

		int hdStatus = 0;
		acMap = new HashMap<String, ArrayList<IngestStatus>>();

		Map<String, IngestStatus> map = getStatusMap();
		for (Map.Entry<String, IngestStatus> entry : map.entrySet()) {
			String key = entry.getKey();
			IngestStatus value = entry.getValue();
			addAcMap(value.entityName, value);

			// if(debug) System.out.println("\nIngest Status Audit :\n" +
			// value.toString());
			if (hdStatus == 0)
				hdStatus = value.returnCode;
		}
		setHeaderReturnCode(hdStatus);
		if (getHeaderReturnCode() == 0) {
			setHeaderStatus("SUCCESS");
			setHeaderStatusDesc(SUCCESS);
		} else {
			setHeaderStatus("FAILED");
			setHeaderStatusDesc(FAILURE);
		}
		obj.put("headerStatus", getHeaderStatus());
		obj.put("headerStatusDesc", getHeaderStatusDesc());
		obj.put("headerReturnCode", getHeaderReturnCode());
		if(("sftp").equalsIgnoreCase(getTemplateType()))
		obj.put("lastSuccessAuditTime", (hdStatus==0)?new Date().toString():getLastSuccessAuditTime().toString());

		JSONArray entities = new JSONArray();
		// map = getStatusMap();
		for (Map.Entry<String, ArrayList<IngestStatus>> entry : acMap.entrySet()) {

			ArrayList<IngestStatus> ar = entry.getValue();
			JSONArray arObj = new JSONArray();
			for (IngestStatus value : ar) {

				JSONObject nw = new JSONObject();
				nw.put("entityName", value.entityName);
				nw.put("startDateTime", value.startDateTime);
				nw.put("status", value.status);
				nw.put("statusDesc", value.statusDesc);
				if(("sftp").equalsIgnoreCase(getTemplateType())){
					nw.put("tableName", value.tableName);
					nw.put("lastFileProcessTime", value.lastFileProcessTime);
				}	
				nw.put("returnCode", value.returnCode);
				nw.put("targetHDFSPath", value.targetHDFSPath);
				nw.put("incremental", value.incremental);
				nw.put("processingStep", value.processingStep);
				if(DataIngestDriver.ING.equals(value.processingStep))
					nw.put("fileSize", value.fileSize);
				nw.put("statusDateTime", value.statusDateTime);
				arObj.add(nw);
			}
			entities.add(arObj);

			// entities.add(value.toString());
		}
		obj.put("Entities", entities);

		try (FileWriter file = new FileWriter(auditFileName, false)) {
			file.write(obj.toJSONString());
			if (debug) {
				// System.out.println("\nSuccessfully Copied JSON Object to
				// File...");
				// System.out.println("\nJSON Object: " + obj);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public DataIngestStatus loadStatusFromJSON(String tType, String jFileName) throws DataIngestException {

		if (this.templateType == null)
			this.templateType = tType;
		if (this.auditFileName == null)
			this.auditFileName = jFileName;
		JSONParser parser = new JSONParser();
		JSONObject template = null;
		BufferedReader brd = null;
		try {
			brd = getReader(auditFileName);
			template = (JSONObject) parser.parse(brd);
		} catch (Exception e) {
			throw new DataIngestException("(Error):", e);
		} finally {
			try {
				if (brd != null)
					brd.close();
			} catch (Exception ex) {
				if (debug)
					System.out.println("Error in closing reader : " + ex.getMessage());
			}
		}
		loadAudit(template);
		return this;
	}

	/*
	 * load audit object
	 */
	private void loadAudit(JSONObject auditJson) throws DataIngestException {
		int i = 0;
		Iterator it = auditJson.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			if (auditJson.get(pair.getKey()) instanceof JSONArray) {
				JSONArray jsonArray = (JSONArray) auditJson.get(pair.getKey());
				Iterator iterator = jsonArray.iterator();
				while (iterator.hasNext()) {
					i++;
					JSONArray entity = (JSONArray) iterator.next();
					// System.out.println("Extracting Properties from Entity > "
					// + i + " "+ entity);
					setEntityProperties(entity);
				}

			} else {
				// System.out.println(pair.getKey() + " = " + pair.getValue());
				setHDProperty(pair);
			}
		}
	}

	private void setEntityProperties(JSONArray jsonArray) {

		Iterator iterator = jsonArray.iterator();

		while (iterator.hasNext()) {
			JSONObject entity = (JSONObject) iterator.next();
			String entityName=(String) entity.get("entityName");
			if(entityName!=null &&!entityName.contains(" ")){
				IngestStatus et = new IngestStatus();
				et.entityName = (String) entity.get("entityName");
				et.startDateTime = (String) entity.get("startDateTime");
				et.status = (String) entity.get("status");
				et.statusDesc = (String) entity.get("statusDesc");
				et.targetHDFSPath = (String) entity.get("targetHDFSPath");
				et.incremental = (String) entity.get("incremental");
				et.processingStep = (String) entity.get("processingStep");
				et.tableName = (String) entity.get("tableName");
				
				if(this.templateType!=null && "sftp".equalsIgnoreCase(this.templateType))
					et.lastFileProcessTime = (String) entity.get("lastFileProcessTime");
				
				if(DataIngestDriver.ING.equals(et.processingStep))
					et.fileSize=(String) entity.get("fileSize");
				try {
					String s = String.valueOf(entity.get("returnCode"));
					et.returnCode = Integer.parseInt(s);
				} catch (NumberFormatException e) {
					et.returnCode = 1;
				}
				et.statusDateTime = (String) entity.get("statusDateTime");
				addStatus(et.entityName + et.processingStep, et);
			}
		}

	}
    /**
     * Based on the headerReturnCode case, the headerReturnCode
     * is set into class data ingests status class variables.
     * @param pair
     */
	private void setHDProperty(Map.Entry pair) {
		String value;
		String key = (String) pair.getKey();
		if (key.equalsIgnoreCase("headerReturnCode")) {
			value = String.valueOf(pair.getValue());
		} else {
			value = (String) pair.getValue();
		}
		switch (key) {
		case "headerStatus":
			this.setHeaderStatus(value);
			if (debug)
				System.out.println(key + " = " + value);
			break;
		case "headerStatusDesc":
			this.setHeaderStatusDesc(value);
			if (debug)
				System.out.println(key + " = " + value);
			break;
		case "headerReturnCode":
			try {
				this.setHeaderReturnCode(Integer.parseInt(value));
			} catch (NumberFormatException e) {
				this.setHeaderReturnCode(1);
			}
			if (debug)
				System.out.println(key + " = " + value);
			break;
		default:
			if (debug)
				System.out.println("Ignore Match : " + key + " = " + value);
			break;
		}
	}

	private BufferedReader getReader(String fileName) throws Exception {
		return new BufferedReader(new FileReader(fileName));
	}

	private BufferedWriter getWriter(String fileName) throws Exception {
		return new BufferedWriter(new FileWriter(fileName));
	}

	// inner class
	public class IngestStatus {
		String entityName = null;
		String startDateTime = null;
		String status = null;
		String statusDesc = null;
		int returnCode = 1;
		String statusDateTime = null;
		String targetHDFSPath = null;
		String incremental = null;
		String processingStep = null;
		String fileSize = null;
		String tableName=null;
		String lastFileProcessTime=null;

		IngestStatus() {
			super();
		}

		IngestStatus(String name, String startDt, String sts, String stsDesc, int rCode, String stsDt, String tgt,
				String inc, String step, String size,String tableName,String lastFileProcessTime) {
			this.entityName = name;
			this.startDateTime = startDt;
			this.status = sts;
			this.statusDesc = stsDesc;
			this.returnCode = rCode;
			this.statusDateTime = stsDt;
			this.targetHDFSPath = tgt;
			this.incremental = inc;
			this.processingStep = step;
			this.fileSize = size;
			this.tableName=tableName;
			this.lastFileProcessTime= lastFileProcessTime;
		}
		
		public void setReturnCode(int rCode) {
			this.returnCode = rCode;
		}

		public int getReturnCode() {
			return this.returnCode;
		}

		public void setStatusDesc(String stsDesc) {
			this.statusDesc = stsDesc;
		}

		public String getStatusDesc() {
			return this.statusDesc;
		}

		public void setStatus(String sts) {
			this.status = sts;
		}

		public String getStatus() {
			return this.status;
		}

		public void setStatusDateTime(String stsDt) {
			this.statusDateTime = stsDt;
		}

		public String getStatusDateTime() {
			return this.statusDateTime;
		}

		public void setTargetHDFSPath(String tgt) {
			this.targetHDFSPath = tgt;
		}

		public String getTargetHDFSPath() {
			return this.targetHDFSPath;
		}

		public void setStartDateTime(String startDt) {
			this.startDateTime = startDt;
		}

		public String getStartDateTime() {
			return this.startDateTime;
		}

		public void setEntityName(String name) {
			this.entityName = name;
		}

		public String getEntityName() {
			return this.entityName;
		}

		public void setIncremental(String inc) {
			this.incremental = inc;
		}

		public String getIncremental() {
			return this.incremental;
		}

		public void setProcessingStep(String s) {
			this.processingStep = s;
		}

		public String getProcessingStep() {
			return this.processingStep;
		}
		
		public void setFileSize(String size) {
			this.fileSize = size;
		}

		public String getFileSize() {
			return this.fileSize;
		}

		public String getTableName() {
			return tableName;
		}

		public void setTableName(String tableName) {
			this.tableName = tableName;
		}

		public String getLastFileProcessTime() {
			return lastFileProcessTime;
		}

		public void setLastFileProcessTime(String lastFileProcessTime) {
			this.lastFileProcessTime = lastFileProcessTime;
		}

		public String toString() {
			StringBuffer bf = new StringBuffer();
			bf.append("entityName: " + entityName + "\n");
			bf.append("targetHDFSPath: " + targetHDFSPath + "\n");
			bf.append("incremental: " + incremental + "\n");
			bf.append("startDateTime: " + startDateTime + "\n");
			bf.append("status: " + status + "\n");
			bf.append("statusDesc: " + statusDesc + "\n");
			bf.append("returnCode: " + returnCode + "\n");
			bf.append("processingStep: " + processingStep + "\n");
			bf.append("fileSize: "+fileSize+"\n");
			bf.append("statusDateTime: " + statusDateTime);
			bf.append("lastFileProcessTime: " + lastFileProcessTime);
			bf.append("tableName: " + tableName);
			return bf.toString();
		}

	} // end of inner class

} // End of Class
